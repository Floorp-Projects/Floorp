dump(">>>>>>>>>>>>>>>> App script.js!!!!\n");
// App manifest `redirect` property only replace URL when the request has
// been redirected remotely. So it won't catch redirect-source request,
// but it's redirection being made by httpd. i.e. the request to
// `redirection-target.html`
var xhr = new XMLHttpRequest({
  mozSystem: true
});
xhr.open("GET", "http://localhost:4444/redirection-source.html", false);
let content = xhr.send(null);

// Pipe back the content to the unit test via httpd
var xhr2 = new XMLHttpRequest({
  mozSystem: true
});
xhr2.open("POST", "http://localhost:4444/result/", false);
xhr2.send(content);

# 01. 現行ビルド構成と変更境界

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

## 観測したソース

Floorp `013bb6c9ed19250592898ec8fbc8d7d24aa847be`（#2886）、Floorp-Runtime `c74fe1a545d275cdd710ab44701c1ee0dd6b0eae` を基準とする。今回、両 branch の head、Runtime setup/daily-build、Floorp deno tasks と packaging の tests 設定を再確認した。その他の既存契約は、同じ head を読んだ本会話の前回調査を引き継ぐ。出典 ID は [09-sources](09-sources.md) を参照。CI 成功や effective configure 結果を確認したという意味ではない。

## Runtime の構成

`daily-build.yml` → OS wrapper → `common-build.yml` → `setup-floorp.sh` / `build-and-package.sh` が主経路。DEBUG と PGO は独立入力であり、手動実行の既定値は両方 true。Linux ARM の呼び出しは `pgo:false` である。[R1–R3]

| Runtime mozconfig | active な `--disable-tests` | 読み取れる範囲 |
|---|---|---|
| Windows x86_64 | コメントアウト | 当該 template では tests を禁止していない |
| Linux x86_64 / aarch64 | コメントアウト | 同上 |
| macOS x86_64 / aarch64 | 有効 | 当該 template では無効化している |

この表は template の観測であり、生成後の config や全 native test の実行可否を証明しない。[R4]

setup は DEBUG に対して debug patch、debug branding、`--enable-debug` を追加する。macOS Debug では `MOZ_DISABLE_CONTENT_SANDBOX=1` を mozconfig の export に加える処理もある。実際の test process の環境・prefs を観測し、通常の製品 sandbox と同等だと解釈しない。[R2]

build-and-package は `mach configure/build/package` を行い、既存 primary artifact を構成する。`mach package` は広域 suite を実行したという意味ではなく、必要な test archives が upload されたとも限らない。テスト資材は実 build output を検査して保持する。[R3][M1]

## 二つの Runtime 選択経路

| 用途 | 既存の正本 | 新 QA の扱い |
|---|---|---|
| 開発・通常 colocated CI | `floorp-runtime.lock.json` | 引き続き既存の開発 Runtime と upstream subset を識別 |
| 本番 stable-v2 | 認証済み daily-build run / manifest / artifact | exact Runtime の native identity を継承 |
| 新規 Debug L1 | 認証済み Debug build / test-support / suite producer | 独立した DebugRuntimeSubject。製品 Subject に変換しない |

Runtime repo head、実コンパイル upstream commit、native patch、debug-only patch、Floorp overlay head は別情報として保持する。新しい Debug の BuildID は自身の run のものを使い、製品版に合わせて偽装しない。[F2][R1][R5]

## Floorp packaging

`package.yml` の workspace root は Runtime、`noraneko/` が Floorp。既存 native artifact を認証して staging し、Floorp の before-mach、`MOZ_ARTIFACT_FILE=... ./mach build`、after-mach/injection を通す。生成 mozconfig は `--enable-release --disable-tests --enable-artifact-builds` と artifact 用 objdir を使用する。[F1–F3]

**今回の採用方針では、本番 packaging の tests フラグは維持する。** Gecko のテストビルド能力と、配布物を外部から検査する Floorp L2 の能力は別である。C++/Rust の変更は Runtime の native build に反映しなければならない。[F1][M1]

primary Runtime artifact のトップレベル要素は既存の検証対象である。test-support を同じ archive に追加せず別 artifact にする。macOS の installer/MAR は `macos-ticket-verify` を優先する最終 workflow outputs を使う。[F2]

## ４ package と５ native execution target

| target key | package artifact（production） | 方針 |
|---|---|---|
| `windows/x86_64` | `noraneko-windows-x86_64-installer` | Windows native L2 |
| `linux/x86_64` | `noraneko-linux-x86_64-installer` | Linux x64 L2 |
| `linuxAarch64/aarch64` | `noraneko-linux-aarch64-installer` | 非 PGO でも製品 L2 |
| `mac/x86_64` | `noraneko-mac-universal-installer` | Intel native L2 |
| `mac/aarch64` | 同上 | Apple Silicon native L2 |

同じ universal archive に対する２つの native 実行結果は統合しない。ビルド用 Linux worker に Windows/macOS GUI の実行能力があるとは仮定しない。[F2–F4]

## 公開経路の現状

`native verification → assemble release bundle → draft → protected approval → public release/update/portable/PPA` が既存の依存関係。#2886 の別 workflow は公開承認待機の前後を read-only で検査できるが、publisher の必須 dependency や lock ではない。[F3–F7]

新設の正式 gate は [11-ci-topology](11-ci-topology.md) の target DAG に従う。旧 helper の `pendingDeployments` 条件を、まだ承認待機へ到達していない新しい inline job にそのまま使わない。source/artifact の検証を弱めず、実行フェーズごとの validator を区別する。

## 既存資産の再利用

Deno host/smoke/docs/tooling tests、実ブラウザー内の colocated tests、Firefox 互換 subset、Marionette、UA probe、Fluent/Flasco probe、macOS native GUI probe を残す。`deno task test` は browser-integrated runner であってソースだけのテストではない。`test:integration` はそれと OS API 検査を結合しているため、共通 host job に無検査で移さない。[F1][F8–F11]

UA probe は実 HTTP、Fluent probe は内部 popup/catalog/fixture 操作を含む。これをすべて純 black-box / native right-click と呼び替えない。各 test の操作方式と oracle を記録する。

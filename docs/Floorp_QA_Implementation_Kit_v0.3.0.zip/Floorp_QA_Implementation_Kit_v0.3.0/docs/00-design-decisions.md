# 00. 採用方針と変更決定

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

## 採用した構成

**Debug Runtime でテストをビルドし、Mozilla の上流テストを実行する。PGO/製品 Runtime の生成経路は維持し、Floorp を組み立てるリリース工程で Floorp 独自のテストを実行する。Agent は未知の不具合を探し、固定テストへ還元する。**

「３層」はテストの責務、「Debug / PGO / Package」は実行対象とタイミングである。３層と３種類のビルドを１対１に対応させない。

| 決定 ID | 採用内容 | しないこと |
|---|---|---|
| ADR-01 | 標準 Debug QA は `debug=true, pgo=false`。Runtime の最終 effective config で tests を有効化する | PGO generate/use の設定をまとめて書き換えない |
| ADR-02 | Debug の native build から対応する test archives / helper / symbols を別 artifact として保持し、native worker で L1 を実行する | `--enable-tests` や `mach package` の成功をテスト成功と数えない |
| ADR-03 | PGO generate/profile collection/use と既存 native verification を維持。新しい広域 L1 は通常の PGO build に追加しない | テスト用コンパイルを一律 disable にしない。PGO の profiling workload も削らない |
| ADR-04 | Floorp ソースだけの検査は package orchestration 内の共通ジョブで１回。ブラウザー依存テストはここに混ぜない | 各 package target で同じ platform-independent source suite を繰り返さない |
| ADR-05 | `before-mach → mach build → after-mach → package/署名・公証` を維持し、最終 artifact を対象 OS で L2 検証する | HMR / dev Runtime の PASS を実配布物の PASS に読み替えない |
| ADR-06 | 本番 packaging の `--disable-tests` は初期導入で維持。外部 L2 runner を接続する | Floorp の TypeScript テストを動かすためだけに Gecko tests を有効化しない |
| ADR-07 | Debug L1 は Runtime のソース適格性、製品 L2 は exact artifact の動作証拠として別 Subject にする | 異なる BuildID/バイナリを同じ対象として結合しない |
| ADR-08 | native / provenance / 署名・公証 / 手動承認は既存のまま。将来の公開必須化は publisher 側で認証済み QA sidecar を検証する | QA worker に公開権限を渡さない |
| ADR-09 | PGO を使わない製品版も `production-opt` として L2 必須に含める | `pgo == true` だけを条件にして Linux ARM 等を取り落とさない |
| ADR-10 | L3 は初期 advisory。確かな crash 等の一次証拠は別途重大 finding として扱う | Agent の正常宣言や API 障害を L1/L2 の合否に混ぜない |

## 「１回」の定義

共通の source suite は **同一の検査入力キーにつき１回の初回評価**、packaged suite は **最終成果物 × native target × 承認済みシナリオにつき１回の初回評価** とする。１シナリオ内で右クリックを反復する、同一 profile で再起動する、といった仕様上の操作は重複検査ではない。

当初は package run 内で source job を１個に集約する。別 run の結果を再利用する場合は Floorp SHA だけでなく lock、toolchain、OS、policy、suite、fixture、producer を一致させる。再試行は初回失敗を消さない。source job が失敗した場合、package job は開始しない。

## 保証範囲

Debug PASS は PGO 最適化固有の回帰、署名、通常起動を保証しない。そのため製品 L2 を省略しない。L2 も Gecko 内部全経路を保証しない。Runtime 更新候補の追加 opt/sanitizer 試験はリスクに応じた別 campaign とし、通常 PGO build に全 suite を戻さない。

この版で実装済みなのは旧 CLI の限定機能と改訂した設計契約の検査である。新たな Debug CI、Runtime test archive 生成、全 Floorp colocated tests の packaged 実行、正式 publisher gate は作業票で実装する。全体実装済みと表示しない。

## 文書の優先順位

本書 → [10-build-profiles](10-build-profiles.md) / [11-ci-topology](11-ci-topology.md) / [12-evidence-contracts](12-evidence-contracts.md) → 詳細設計 → 作業票。機械可読の `qa/design/build-policy.json` と `ci-graph.json` はこの方針の整合検査用であり、実 workflow を変更する設定ファイルではない。

前版 0.1 / キット 0.2.0 の「PGO リリースごとに別の test-enabled build を必ず作り直す」「製品 Subject に L1 全 suite をぶら下げる」という読み方は廃止する。[13-migration](13-migration.md) に変更範囲を記録した。

# 07. 検証報告 / 0.3.0

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

## 実施結果

この作成環境で **114件のPython unittestが成功**。失敗0、error0、skip0。旧75件を改訂後のキットで再実行し、設計/計画分離に関する39件を追加した。検証用データはsyntheticで、実Floorpの試験結果ではない。

| 検査 | 実施結果 |
|---|---|
| `python3 -m unittest discover -s tools/qa/tests -v` |114件成功 |
| `python3 tools/qa/design_contract.py` |DESIGN_VALID。ビルド/CI/公開の副作用なし |
| Python compileall |tools/qa と install.py の構文検査成功 |
| JSON Schema Draft 2020-12 |10定義を検査。設計2モデル、baseline、3profile計画も適合 |
| host-only workflow YAML |構文読取成功。GitHub Actionsとしての実行ではない |
| CLI help/version |起動成功、0.3.0を表示 |
| installer |既存テスト内でdry-run/新規追加/上書き拒否を検証 |

環境: Python 3.13.5 / container。JSON Schema/YAML検査はこの作成環境のvalidatorを使い、CLIの実行時依存に追加していない。生ログは`validation/unittest.log`、要約は`validation/host-validation.json`、設計結果は`validation/design-contract.json`。

## 新しい負例

Debugでtests無効/PGO有効、productionでtests設定を強制変更、PGO profiling削除、product packageのtests有効化、source browser依存/重複、Linux ARM欠落、Debug/製品BuildID同一視、test-supportのprimary混入、manual approval省略、assemble↔QA循環、unknown edge、Agent blocking化、ProductSubjectへのL1/mozilla-harness誤投入、unsigned production計画を拒否するテストを追加した。

旧readiness aliasと新profileが同じL2ケースを持ち別plan IDを持つこと、旧既存probeの互換性、未実装caseは引き続きBLOCK、local publicationAuthorized=falseも確認した。

## 実装が変わった範囲

README/既存01～09の改訂、新00/10～13、設計JSON/schema、design checker/tests、baseline policy、CLI/profile enum、製品Subjectで上流evidenceを拒否するcore検査を変更。Runtime/Floorpの実リポジトリ、GitHubのworkflow、protected environment、署名/公開設定は変更していない。

## 未実施

Runtimeの実configure/build、tests-enabled Debugの生成、test archivesの実生成、Mozilla標準suiteの実行、PGO profiling、最終Floorpのnative GUI、Deno、全colocated testsのpackaged移行、外部LLM、GitHub Actions、publisherのpublic mutation阻止は、この環境では未実施。

full checkoutに対する`git apply --check`は未実施。`propose_integration.py`の変換単体テストが成功していても、現在のfull checkoutで適用・build成功したとはしない。CLIのprocess/driver機能は既存のpilotであり、実機での安全性・全OS対応の認定ではない。

## 納品物の整合

文書リンク、バージョン、policyとDAG、チェックサムは梱包時に検査する。`MANIFEST.sha256`は各ファイルのbytesを識別するもので、署名や信頼済みproducerの認証ではない。

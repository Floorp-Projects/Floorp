# 12. 証拠・再利用・Debug と製品のリンク契約

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

## 1. Subject の分離

| モデル | 同一性の主要入力 | この版の実装状態 |
|---|---|---|
| `DebugRuntimeSubject` | repo head、compiled upstream/patch、debug-only patch、effective config、toolchain、target、BuildID、binary/test-supportのdigest、build producer | 設計済み、producer/validator は未実装 |
| `SourceQASubject` | Floorp SHA、locks、suite/policy/fixture、toolchain、runner、generator入力 | 設計済み、CI producer は未実装 |
| `ProductSubject` | exact package/native record/source run/target/version/BuildID/署名状態 | 既存 `Subject v1` の adapter を維持 |
| `RuntimeQualification` | DebugRuntimeSubject ID、L1 plan/result、適用するsource/patch/target/環境制約、producer、失効条件 | 設計済み、正式認証は未実装 |
| `ReleaseQASidecar` | source証拠、適用資格、全製品target結果、exact bundle、trusted policy/producer、finding判断 | 設計済み、publisher verifier は未実装 |

既存 v1 ProductSubject と v2 native/release record の schema は無断に拡張しない。新モデルは別version/schemaとして実装する。機械可読設計 JSON は実 evidence そのものではない。

## 2. Runtime qualification の適用

DebugとPGO/optのバイナリdigestとBuildIDは違ってよい。一致を要求するのは「同じartifact」ではなく、対象の試験契約に関わる compiled upstream revision とproduction適用native patch集合、および承認済みの比較条件である。

| 項目 | 取り扱い |
|---|---|
| compiled upstream commit | 完全一致。表示versionだけでは不可 |
| productionに適用するnative patch identity | 同じ内容と順序/最終tree identity。unknown差分は拒否 |
| Runtime orchestration head | 両方記録。差分のcompiled-source非影響が認証できなければ資格を再取得 |
| Debug-only patch/config | 差分と影響suiteをレビュー。無条件に除外しない |
| target/arch | 同一を原則。別archのPASSで代用しない |
| compiler/SDK/runtime依存 | 差分を保持。許容ポリシー未定なら再検証 |
| BuildID/binary/test-support | Debug内部では厳格に結合。製品とは異なるIDのまま |
| sandbox/loader | 実プロセスの設定を保持。Debugの緩和環境で製品privacy/通常起動を適格化しない |
| Floorp overlay | Runtime-only資格には含めない。overlay試験はFloorp/testbundle/prefsもキーに含める |

source qualification は「このソース系列のDebug条件でL1が成功した」証拠であり、PGO実行経路の証明ではない。製品L2と既存native verificationは常に別に必要。

## 3. 資格の取得・失効

Runtime変更ではqualificationを更新する。Floorp-only変更はRuntime-only資格を再利用できるが、browser UI/actors/prefs/bootstrap/native patchesに触るとoverlay関連資格と製品suiteの影響を再評価する。

qualified subset、policy、harness、fixture、対象OSの互換条件が変わった場合は再取得/明示レビュー。新しい重大finding、revoked build、artifact取り違え、期限超過でも失効する。expiryは環境/運用policyで明記し、未測定の一律時間を既存仕様として創作しない。

署名/issuerだけで試験が十分であるとみなさず、expected manifests/test IDsと完了、rawログ、canary、実artifactを照合する。read-only APIで得たproducer情報と自己申告JSONを区別する。

## 4. 「１回」再利用キー

Source QA のキーは `H(FloorpSHA, lock digests, source suite+policy, fixture/generator inputs, toolchain, runner image)`。ブラウザー依存を含めるならRuntime identityも必要になるため、初期source jobには含めない。

Packaged QA のキーは `H(ProductSubject, final package/member digest, native target, suite+policy+test-bundle, fixture, runner/display, sandbox/automation mode)`。同じcommitから再packしてdigestが変われば再検証する。mac universalはtargetが違うため別キー。

再利用できるのはverified producerの完全な初回評価と履歴を持つ証拠だけ。cache、job名、branch名、PRの緑表示だけでは不可。別run/attemptの再利用は明示的evidence edgeで関連づけ、現在runで実行したように書かない。

## 5. Release sidecar

入力: exact bundle ID/digest/source run/attempt、FloorpSHA、Runtime production manifest/各artifact、qualified Debug references、SourceQA reference、各target ProductResult reference、policy/trusted tool revision、finding/waiver判断。

public verifier はschema、producer、signature/attestationを採用する場合そのissuer、expected subject、target集合、初回/再試行履歴、全必須case、digest、失効/waiverを検査する。必須検証が足りない場合は BLOCK。

既存 manual approval を通過しても最後に同じ sidecar と bundle を再検証する。QA中に署名し直した、archiveを置換した、再buildした、別attemptの結果を混ぜた場合は新artifactとして扱う。自動approval、公開トークンを持つAgent、任意callerのPASS JSONの信頼は禁止。

## 6. 状態モデル

`NOT_PLANNED / NOT_ONBOARDED / BUILT / DISCOVERED / RUNNING / PASS / FAIL / CRASH / TIMEOUT / SKIP_APPROVED / INCOMPLETE / ENVIRONMENT_ERROR` を意味上区別する。既存CLIの列挙値に直ちに追加するのではなく、新adapterのスキーマで対応する。型名の似たstatusを無検査で変換しない。

source scope PASS、Debug scope PASS、product target scope PASS、release authorizationは別判定。現行 `gate` の `publicationAuthorized:false` を変更しない。JSONL/画像/プロファイル差分/minidumpに秘密情報を含めず、必要最小限のsynthetic dataと保持期間を使う。

## 7. 最小負例

Debugの結果を製品Subjectとして渡す、PGOに古いDebug資格を貼る、Linux x64のPASSをLinux ARMへ貼る、Test supportとDebug buildのBuildID不一致、dev-loader起動、unsigned→production誤用、source lock差分、欠落case、FAIL後のPASSのみ提出、公開直前のbundle差替えをすべて拒否する。

## 8. Linux と署名モードの用語

既存recordの`unsigned:false`は本番pipeline側のartifactモードを表す。Linuxのtar.xz自体がWindows/macOSと同じコード署名証明書を持つという意味ではない。`signedOnly`という既存CLI名は互換上維持するが、production各targetに必要な真正性・署名/公証要件はそのOSの既存validatorで検証する。

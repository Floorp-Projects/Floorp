# 11. CI・公開ゲートの依存関係

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

## 1. 方針

Runtime の L1 は Debug build に集約する。PGO/production-opt は既存 build と native verification を維持する。Floorp の package orchestration は source QA を１共通ジョブに集約し、その後４ package / ５ native QA を行う。

**ジョブ名は以下すべて新設提案。接続済み workflow ではない。** `qa/design/ci-graph.json` は依存関係の静的検査用であり、GitHub Actions YAML として投入しない。図は UML-like の依存フロー。テキスト/依存表も添え、画像閲覧に依存しない。

## 2. Runtime Debug QA

| job | needs | 責務 |
|---|---|---|
| `resolve-debug-qa` | なし | source/pin/patch/DEBUG/PGO/test plan を固定 |
| `build-debug-runtime` | resolve | native tests enabled build と対応 test assets を生成 |
| `run-debug-upstream` | build | 各 native worker の選定 L1、raw log、planned ID 照合 |
| `qualify-debug-runtime` | run | RuntimeQualification sidecar。PGO製品のPASSではない |

最初は Linux x64。残る target は未導入であることを明示し、ready と見せない。Debug daily-build が production build-manifest を生成しない条件でも、Debug専用 sidecar によって producer/build/test を識別する。製品 manifest を流用/偽造しない。[R1]

## 3. 製品 Runtime

PGO generate → profileserver workload → profile-use → native verification の既存構成を維持する。[R1–R3][M5] 非 PGO opt target も製品として扱う。Debug suite と PGO の間にはバイナリ共有ではなく、source qualification の参照がある。

Runtime 更新候補では、対応する Debug L1 がない場合に qualified としない。通常 Floorp-only release は source/patch/条件が適合する既存 qualification を参照してよく、毎回 Debug Runtime を再ビルドしない。真正性、適用範囲、失効は 12 の条件を満たす。

## 4. Floorp の目標 DAG

```text
source-qa-once --------------------------+
                                       v
resolve-product-runtime -----------> package-[4 targets]
                                       |
                          final signed/notarized outputs
                                       v
                            native-verify-[5 targets]
                                       |
                                       v
                         assemble exact existing v2 bundle
                              /                    \
                   draft staging             package-qa-[5 targets]
                              \                    /
Debug RuntimeQualification ---> aggregate authenticated QA sidecar
source-qa evidence ------------>          |
                                            v
                                 protected manual approval
                                            |
                                 revalidate QA + exact bundle
                                            |
                                public release / distribution
```

`package-qa` は assembled bundle の exact outputs を読み、各 artifact/target で１度だけ決定的 suite を実行する。現行 release-bundle-v2 の closed schema を変更せず、QA sidecar を別 artifact にする。draft は公開前の staging に限定し、公開版と区別する。

この版では「QA のために bundle が必要なのに、bundle が QA 成功を待つ」という循環を避けるため、**assemble→QA sidecar→public gate** を標準とする。既存 native verification は assemble の前提として残す。署名・公証を package から全面分離する改造は不要。

## 5. source job の配置

source-qa-once は同一 Floorp checkout/lock/policy で実行し、OS別 package jobs の needs とする。host subset を固定し、以下の既存 command は適用候補として既存呼び出しを確認する。[F11]

```bash
deno task test:smoke
deno task test:host
deno task test:firefox-tests
deno task test:docs-pipeline
python3 -m unittest discover -s tools/qa/tests -v
```

`test:firefox-tests` はこの指定では収集/互換ツールの host tests であり、Mozilla の上流 suite を再実行する指示ではない。`deno task test` と `test:integration` はブラウザーを起動するためこの一覧に入れない。source-only と称した job 内で別 Runtime をダウンロード/起動しないことを監査する。

## 6. packaged runner の新しい契約

入力は exact package ID/digest/member digest、authenticated native record、Floorp SHA、test bundle SHA、policy、suite、target。出力は actual binary/profile/process identity、loader/sandbox observation、各 case/attempt と raw evidence。

`--browser` の指定を無視して既存 `_dist/bin` を起動する fallback を禁止。production bootstrap を使用し、外部 test bundle は製品コードを再ビルドしない。tests の origin と executionKind を固定する。Floorp固有 suite の全量 discovery と実行予定の差を公開する。

runtime outside の host/native wrapper tests と Mozilla-engine tests は区別する。既存 native verification まで削ることを「Runtime 外だけ」の意味にしない。

## 7. #2886 からの移行

**Shadow 段階:** 現行 `pre_publication` の read-only workflow を維持し、共通 evidence を追加。今ある手動承認前後のチェックは残す。source/PGO/最終QAが未接続なら未導入として表示する。[F6][F7]

**Required 段階:** 新しい pipeline では QA が approval より前に位置する。既存 helper の「既に pending deployment がある」条件をそのまま呼ぶと成立しないため、独立の `pre-approval` intake を設ける。canonical source run、各先行 package/native/assemble job と exact artifactを検証し、親 run 全体の completed/success を要求しない。

required mode で追加 QA を `continue-on-error` にしない。publisher は approval 後、public mutation の直前に QA producer/status/policy/source/run/attempt/target/sidecar/bundle を再検証する。manual approval は残し、QA の成功だけで承認しない。mutableな「latest PASS」検索ではなく指定 artifact ID を渡す。

## 8. 頻度・選定

| trigger | Debug L1 | source | packaged L2 | Agent |
|---|---|---|---|---|
| Floorp PR | 通常は既存開発CIと影響選定 | 変更入力で実行 | high-risk候補/信頼済みartifact | 任意 |
| Debug schedule | 選定suite + 計画的広域shard | 必要時のみ | Debug overlay診断は別 | 診断のみ別Subject |
| Runtime candidate | 対応sourceのqualification必須化を段階導入 | Floorp candidateで１共通job | 全target重要subset | 任意重点探索 |
| Floorp product package | 適合する既存qualification参照 | run内１回 | 各final artifact/targetで１初回評価 | 別advisory |
| Nightly exploration | 必要に応じ台帳拡張 | 既存証拠を厳格再利用 | 高リスク組合せ/長期遷移 | budget付き |

## 9. 失敗とキャンセル

planned shard の未開始/未完了、timeout、artifact未取得、capability不足は gate を止める。source failure は新規 packageを開始しない。必須 L1 qualification欠落は opt Runtime のbuildを止める必要はないが、required phaseで新Runtimeのpromotion/publicationを止める。

retry/rehydrationは別attemptを記録。失敗したsuiteだけの再実行で過去失敗が消えた成功記録を作らない。緊急時waiverはowner、理由、期間、対象evidence、代替検証を別承認し、identity/署名/provenance不一致にはwaiverを許可しない。

# 05. 受け入れ基準・導入状態

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

## 状態の読み方

設計済み、コードあり、synthetic unit test成功、native実行成功、required CI導入、public gate enforcementは別状態。以下の「未実施」は実機実行/CI接続の未実施を指す。書類の完成と運用の完成を混同しない。

| 能力 | 設計/納品コード | 実機/CI受け入れ |
|---|---|---|
| Debug非PGOだけtests有効化 | 設計契約・負例検査 | Runtime変更/実configure未実施 |
| Debug test-support生成 | 旧`pack-test-bundle`補助、producerは設計 | native build/実archive未実施 |
| Debug L1 / qualification | mozlog単一cycle checker、identity仕様 | suite/資格認証未実装 |
| source jobを１回集約 | 命令/needs/再利用仕様 | Deno/Actions接続未実施 |
| 既存UA/Fluent-Flasco | 旧adapter/CLI/取り込み | 本作成環境の実browser未実施 |
| 全Floorp testsのpackaged化 | origin・runner仕様 | 移行実装/全case未実施 |
| ５target native L2 | matrixと負例仕様 | Windows等の追加backend未実装 |
| L3 | 制限付きpilotとreplay | LLM/全feature/縮約未実装 |
| publisher gate | sidecar/DAG/失敗条件の設計 | public enforcement未実装 |

## Profile × target

全製品target集合は windows/x86_64、linux/x86_64、linuxAarch64/aarch64、mac/x86_64、mac/aarch64。Debug側の同等native集合を段階整備する。Linux ARM非PGOを製品matrixから除外しない。mac universalは２実行target。

| case ID | 受け入れ操作/条件 | 失敗の検出 |
|---|---|---|
| A01 | Debug非PGOを生成してeffective tests=true | templateだけ変更、実config falseを拒否 |
| A02 | production-PGO generate/useを同じ入力で比較 | tests/PGO/LTO設定の意図しない変化を検出 |
| A03 | legacy Debug+PGO入力 | canonical Debug QAへ誤分類しない |
| A04 | Debug buildとsupportを結合 | 異なるBuildID/arch/sourceを拒否 |
| A05 | supportが別artifact | primaryへの余計な追加は既存validatorで拒否 |
| A06 | Runtime-only標準ハーネス実行 | 空discovery/ログ欠落/canary FAILを捕捉 |
| A07 | Debug overlay suite | feature未初期化/別loaderではoverlay成功にしない |
| A08 | source jobを１回配置 | browser起動/４回重複/空suiteを検出 |
| A09 | source evidence再利用 | 同じSHAでもlock/toolchain/policy差を拒否 |
| A10 | packaged runnerが明示binaryを起動 | `_dist/bin`/別PGO/Debug/DEVへのfallback拒否 |
| A11 | 最終mac artifact | 公証前/再署名copyをproduction結果にしない |
| A12 |５target全体 | Linux ARM/mac Intel等の欠落を拒否 |
| A13 | runtime/floorp/test origins | unknown originを計画エラー、上流suiteを製品へ混入させない |
| A14 |正常終了・再起動 | owned PID外へのkill、cleanup失敗を捕捉 |
| A15 | UIでworkspace作成→保存→再起動 |消失/選択/所属の仕様違反を検出 |
| A16 | UA設定変更→HTTP観測 |実header不一致、通常tabへの漏出を検出 |
| A17 | native右クリック反復 | OS入力失敗/crash、DOMだけの代用を拒否 |
| A18 |元版→先版の実update | profileを開くだけの証拠では代用不可 |
| A19 | Debug資格→製品sourceリンク | Debug binaryを製品と同一視しない |
| A20 | Debug資格の失効 | native patch差/target差/期限切れを拒否 |
| A21 |通常初回FAIL、retry PASS |初回FAILを残しclean PASS禁止 |
| A22 | pre-approval公開DAG |親run完了/既にpendingを要求する循環を拒否 |
| A23 | public mutation直前の再照合 |bundle変更/不正producer/sidecar欠落で停止 |
| A24 | Agent actions→fixed replay |任意shell/eval/URL拒否、LLM正常宣言をPASSにしない |

A01～A24は実CIの受け入れ仕様。全件実施済みではない。今回の設計checkerや既存unit testsと名前/件数を混ぜない。検証報告07に実行済みの範囲を記す。

## 完了の定義

最初の運用完成は、明示した必須subset/targetのDebug L1、source-once、exact product L2が証拠で繋がり、失敗/未実行/誤artifactが公開を止めること。全Firefox testsの全量実行や全機能coverage 100%とは異なる。

Coverageは全inventoryのonboarding、eligibleのexecution、critical scenario×target完了、state transition、known-bad検出の分母を分ける。未導入を減らして見かけの成功率を上げない。

# 06. セキュリティ・障害・継続運用

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

## 信頼境界

Build、test、model、reporter、publisherを分離する。buildに必要な鍵をtest workerへ継承しない。test workerはdedicated profileとfixtureを使い、実ユーザーのログイン済みbrowser、SSH agent、cloud credential、通常HOMEを持ち込まない。fork PRを永続self-hosted環境で無承認実行しない。[M8]

QA policy、expected test set、producerの認証は候補コードだけで書き換えられない位置から供給する。test log、DOM、Issue、LLM出力はデータであり、実行権限や期待値の承認として扱わない。

## Debug の隔離

macOS Debugのconfigにはsandbox overrideがあるため、実行環境を記録し製品sandbox/通常起動証拠へ流用しない。[R2] 本方針で既存debug overrideを勝手に本番へ展開しない。安全性比較が必要なら通常sandboxの別Debug条件を設計し、対象suiteの実行可否を検証する。

tests-enabled Debug binary/helperは通常配布物ではない。test-supportとsymbolsは別artifactに保存する。privacy/network/crashreporterの実capabilityを記録し、dumpが取れないことを隠さない。

## GUI worker

１desktop/sessionに同時１GUI試験。並列化はVM/独立display/別sessionで行う。Windows desktop、macOS input/screen permissions、Linux X11/Wayland、native archをprobeする。権限不足はenvironment errorであってPASSではない。[M2]

各runにprofile/ports/downloads/outputを割当。process PIDだけでなく開始時刻/executable/profileを照合する。browser名の一括kill禁止。timeout時に子process/LaunchServicesが残る可能性はowned workerの廃棄と証拠で管理し、異なる利用者processへ信号を送らない。

## 通信とデータ

fixture serverと承認済み推論endpointへの通信に限定する。loopbackだけを安全境界にしない。外部LLMのAPI keyはcontrollerに置き、browser workerへ渡さない。download/clipboard/file-picker/update endpointはfixture経路で制限する。

synthetic profileは正常終了後に複製する。SQLite/WAL途中コピーを正常baselineにしない。profile内容全体や認証情報を無差別uploadしない。成功/失敗/release evidenceのretentionは別に定め、必要期間を超えるcrash dumpや通信本文を保持しない。

## Evidence と再試行

immutable/new-output-only、digest/size/path、target/source/run/attempt、producerを照合する。再実行は新directory/attempt。FAILからPASSになった事実も残す。helperの終了コード0だけ、モデルの感想だけ、署名だけ、artifact名だけで合格しない。

RuntimeQualificationの失効はsource/patch/target/policy/重大findingに基づく。PGO生成ジョブを毎回強制再buildするのでなく、必要な資格と製品検証を再取得する。発見されたcrashの再現率が低くても一次証拠を削除しない。

## Failure handling

| 症状 | 対応 | 禁止 |
|---|---|---|
| Debug tests compile失敗 | target/config/helperの依存を修正、未完了表示 |tests=falseへ戻してL1成功と表示 |
| PGO profile失敗 |既存generate/collect/useを診断 |profiling workloadの削除 |
| source QA失敗 | package前に停止 |別SHAの緑チェックへ差替え |
| product E2E失敗 | exact artifactとraw logで再現 |同じSHAで再packした別artifactへ黙って交換 |
| Agent/API停止 |探索未完了、L1/L2は独立 |モデル障害を製品PASS/FAILに偽装 |
| publisher証拠不一致 |public mutation前に停止 |manual approvalを理由に無視 |

## Required と shadow

shadowは計測/適応用であり、既存必須gateを弱めない。重大findingはshadowでも人間へ提出する。requiredへ昇格したcaseの失敗/欠落にcontinue-on-errorを使わない。

quarantineはowner/Issue/理由/期限/代替検査を必要とする。critical問題の免責をAgentに承認させない。緊急waiverは限定scopeの人間承認であり、wrong artifact、改変provenance、署名不一致の迂回には使わない。

## コストと保守

重いL1はDebug更新時/定期shard、sourceは共通１回、製品L2はtarget別１初回評価、Agentはbudget制約で運用する。p50/p95時間、CPU/RAM/storage、GUI占有、flake率、test-support容量、確認済みfindingあたり推論費用を測る。

ツール、モデル、prompt、harness、policy更新時にはknown-bad/fixed corpusと失敗canaryを再実行する。週次監視などは運用設計であり、この納品で通知や定期タスクは設定しない。

# 13. 0.2.0 からの変更・移行手順

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

## 変更の要点

| 旧設計/旧実装 | 0.3.0 |
|---|---|
| release候補ごとに別test-capable Runtimeを作ると読める | Debug native buildにL1を集約。適合するqualificationを製品releaseから再利用 |
| release-readinessのProductSubjectにL1 browser-chrome/xpcshell/WPTを混載 | 製品readinessはL2のみ。Debug L1は別Subject/qualificationへ移動 |
| sourceとbrowser testsの１回実行の境界が曖昧 | source-onlyはrun内１共通job、browser/nativeはfinal artifact×target |
| tests-enabled artifact buildが中心と読める |本番package flagsは維持し、外部packaged runnerを接続 |
| QA-01/02中心の着手 |Runtime Debugフラグとsource QA集約を最初に着手 |
| PGO版だけの製品条件 | production-opt（Linux ARM等）も対象 |
| read-only pre-publicationとrequired gateが混ざりやすい | legacy hold検査と新pre-approval intake/public verifierを分離 |

## 互換性

既存 `existing-final` profileとその２probe adapterは維持する。`release-readiness` は後方互換のCLI名として残すが、scopeを `production-package-readiness` に改める。新しい同名profile `production-package-readiness` を推奨し、両方は同じL2計画を作る。plan IDはprofile名も含むためalias同士で異なる。旧plan/result/subjectを無検査で新planへ転用しない。

L1を製品計画から外すのは試験削除の免責ではなく、別Debug資格へ置き換える責務分離。新しいqualification verifierが未実装の間は全体release-readyを表示しない。既存local gateは引き続き `publicationAuthorized:false`。

native record v2 / release bundle v2 / ProductSubject v1 は維持。新Debug/Source/Qualification/ReleaseSidecar evidenceの実validatorは作業票で追加する。`qa/design/*.json`は設計契約であって、実CI適用済みの証拠ではない。

## 新しいファイル

00/10/11/12/13の文書、`qa/design/build-policy.json`、`qa/design/ci-graph.json`、それらの設計用schema、`tools/qa/design_contract.py` と整合テストを追加。README、既存01～09、integrations/schema案内、baseline policy、CLI profile表示と製品L1誤用拒否、検証報告を更新した。

## 作業票の対応

| 旧 | 新 |
|---|---|
| QA-01 共通CLI | QA3-04/05 |
| QA-02 final probes | QA3-05 |
| QA-03/04 Runtime bundle/harness | QA3-01/02/03/08 |
| QA-05/06 native/feature | QA3-06/07 |
| QA-07 Agent | QA3-10 |
| QA-08 publisher | QA3-09 |
| QA-09/10 運用 | QA3-11 |

## 既存checkoutへの導入

未導入checkoutは `install.py --repo PATH` でdry-runし、明示的applyで新規追加できる。0.2.0を既に導入済みならinstall.pyは上書き拒否する。別worktreeで比較して、変更したdocs/qaと関連tool/policyをレビューして取り込む。新規性を偽るため旧ファイルを一括削除しない。

`propose_integration.py` は従来どおり既存２probeのadvisory接続差分を生成する補助であり、新Debug profile、source-once、packaged全suite、正式publisherを自動実装しない。この位置づけを変更しない。生成差分を適用する前にexactソースpinとgit apply --checkを実checkoutで確認する。

## 受け入れとrollback

新しい設計checker、旧unit tests、新profile計画、unsigned拒否、ProductSubjectへのL1誤投入拒否、ドキュメントリンクとchecksumを確認する。本環境の結果は07に記載。

実CIのrollbackは新規shadow接続単位で行い、既存native/provenance/manual approvalを消さない。required gateを戻す場合は明示承認・期間・代替検査を残す。旧release-readiness JSONを戻してL1を製品に混載する方法では戻さない。

# 08. 実装 Agent への引き継ぎ — Debug / 製品分離

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

## 共通指示（そのまま渡す文章）

> Floorp QA設計0.3.0の00/01/02/10/11/12/04/07を読み、対象checkoutの最新sourceと既存testsを確認する。方針はDebug Runtime（debug=true,pgo=false）でtests有効化とMozilla L1実行、PGO/production-optの生成設定は維持、Floorp source-only QAはpackage runの共通jobで１回、Floorp browser/native testsは最終製品artifact×native targetで１初回評価。製品packagingの--disable-testsは初期導入で維持する。Runtime/provenance/署名・公証/native verification/手動承認を弱めない。指示された作業票だけを実装し、公開・署名鍵操作・workflow本番起動は別途許可がない限り行わない。

## 最初の実装

> QA3-01とQA3-04を別PRとして進める。Runtimeはsetupの最終generated configでDebug非PGOだけtestsを有効化し、effective configure結果とPGO generate/use不変を検査する。templateのdisable-testsを全OS/全profileで無条件削除しない。legacy Debug+PGOをcanonical QAと誤分類しない。Floorpはsource-only test catalogを固定し、source jobを各package jobのneedsにする。deno task test/test:integrationをソース専用jobに混ぜない。新packaged runnerは別作業なので、source testsの成功を実製品の成功と報告しない。

## Runtimeテストの実装

> QA3-02/03を行う。同じDebug native buildから実ハーネスが必要とするtest archives/helper/configを別artifactに保持する。primary Runtime artifactとproduction v2 manifestは変更しない。Linux x64の実在manifestでRuntime-only L1を最初に実証し、empty discovery/意図的FAIL/欠落ログを拒否する。Floorp overlayが必要なsuiteは別evidenceとしてsentinelを追加し、overlay adapter未完成を理由にRuntime-only全体を止めない。Debugの成功をPGO binaryに直接付けない。

## 製品テストの実装

> QA3-05/06/07を行う。最終workflow outputs、公証後のmacOS artifact、認証済みnative recordに結合する。元colocated testsをorigin=floorp/mozilla-imported/toolingとexecutionKindで台帳化し、Floorpのpackaged-compatibleケースを移す。unknownや未移行を黙ってskipしない。dev Runtimeへfallbackせず、実行binary/head/build/loaderを検査する。Linux ARMは非PGOでも含め、mac universalはIntelとARMの別native runにする。既存内部probeとOS right-clickを混同しない。

## 資格・公開ゲートの実装

> QA3-08/09は12の別Subject/再利用契約と11の非循環DAGを実装する。Debug qualificationはsource/patch/target/config差分に対する資格で、製品そのもののPASSではない。assembleの後にexact bundleからQAし、sidecarを別artifactとして認証する。QA前に既にpending deploymentがあることや親run全体の完了を要求する古いhelperを新inline経路にそのまま使わない。manual approval後、public mutation直前にtrusted policy/producer/sidecar/bundleを再確認する。publicationAuthorized:falseの既存local gateを単独の公開許可へ変更しない。

## 探索の拡張

> QA3-10は１featureから開始。model controllerとbrowser workerを分離し、任意shell/eval/URLを与えない。Budget、固定observer/oracle、JSONL、LLMなしreplay、bad/fixed検査を追加する。Debugのみの再現をPGO問題の修正確認に使わない。回帰テストと期待値には人間レビューを要求する。

## 各PRの提出形式

対象source SHA、作業票ID、変更一覧、実行したcommands、実際のartifact/run/target、PASS/FAIL/未実施、負例の検出、未移行/未対応、設計からの差分を記載する。生成コードと実環境での検証を区別する。現行pinのdriftがあれば差分を読んでレビューし、自動で「新しいからOK」にしない。

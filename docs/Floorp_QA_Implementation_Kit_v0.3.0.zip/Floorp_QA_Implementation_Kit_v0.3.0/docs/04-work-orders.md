# 04. 実装作業票 — 新方針への置換

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

## 運用

ID を `QA3-*` に改め、旧 QA-01～10 をそのまま別内容で使い回さない。担当者は未割当。設計の採用はユーザー確認済みだが、各 feature の期待値と CI 必須化の承認は別。実装・実機検証・公開設定変更の権限も別とする。

| ID | 主担当 repository / 範囲 | 依存 | 完了成果物 |
|---|---|---|---|
| QA3-01 | Runtime / profile resolver・setup | なし | Debug非PGOだけtests enabled、PGO不変の負例付き |
| QA3-02 | Runtime / test-support生成・保存 | 01 | 同じDebug buildの別artifactとprovenance |
| QA3-03 | Runtime / L1 native worker | 02 | Linux x64の標準ハーネス実証とqualified subset |
| QA3-04 | Floorp / 共通source QA | なし | package前の１共通jobとテストorigin台帳 |
| QA3-05 | Floorp / 既存final probes・共通CLI | 04 | 現行３targetのadvisory取り込み |
| QA3-06 | Floorp / packaged colocated runner | 05 | 最終製品に対するFloorp固有suite |
| QA3-07 | 両repo / native target拡張 | 03,06 | Debug L1と製品L2の５target対応 |
| QA3-08 | 両repo / qualification・再利用 | 03,04 | Debug→製品source適格性の別Subject接続 |
| QA3-09 | Floorp / release sidecar・publisher | 05,06,07,08 | required公開gate・手動承認維持 |
| QA3-10 | Floorp / L3 model adapter・探索 | 06 | 限定探索→固定再現→回帰候補 |
| QA3-11 | 両repo / 広域選定・運用 | 07,08 | manifest被覆、コスト測定、復旧手順 |

## QA3-01: Debug tests フラグ

対象: Runtime `daily-build.yml`、wrappers、`common-build.yml`、`setup-floorp.sh`、mozconfigs。最初はprofile mappingと最終generated configの変更だけに限定する。標準Debug QA入力は`debug=true,pgo=false`。legacy debug+PGOはcanonical QAから除外するが、既存実験workflowの廃止は別判断。

受け入れ: 実configureでDebug/tests/native buildが有効、PGOが無効。５targetの設定生成を検査し、PGO generate/useとproduction-optの既存tests/profiling設定が不変。source templateにenable/disableが両方残る、unknownフラグ、PGO mode不整合を検出する。macOS compile可否は実buildで確認し、未実施ならそのまま記録する。

禁止: 本番packageの`--disable-tests`を同時に削除しない。sandboxを本番へ緩和しない。フラグを変えただけで「上流テスト成功」と報告しない。

## QA3-02: Debug test-support

対象: Runtime `build-and-package.sh`、build leaf、artifact outputs/sidecar。実revisionが持つMozillaテスト生成・パッケージ手順を確認し、native buildを１度だけ行ってその結果からsupportを生成する。arch別helperとtest extensionsを含む必要ファイルをinventoryする。

受け入れ: BuildID/source/config/targetがDebug binaryと一致。supportを誤った版と交換すると拒否。primary Runtime artifactの要素・既存manifest契約は変わらない。Debug成果物の認証はproduction-only manifestに依存しない。空archive、不可視helper、architecture違いを検出する。

## QA3-03: Runtime-only L1 と overlay の分離

最初はLinux x64のRuntime-only browser-chrome/xpcshell代表manifest。元のhead/support/IPC依存を含む実在パスを採用し、意図的FAIL canary、exact resolved IDs、raw log、exit codeを検証する。テスト有効化、discovery、実行、成功を別fieldにする。

受け入れ: 空discovery、startのみ、終了欠落、unexpected crash、未対応ログをPASSにしない。DebugRuntimeSubjectとRuntimeQualificationのスコープが明確。overlay統合は後続サブタスクにし、必要なsuiteにのみFloorp bootstrap sentinelを要求する。素のRuntimeでの成功をoverlay成功にしない。

## QA3-04: 共通 source QA

対象: Floorp `deno.json`、release orchestrator、既存smoke/host/tooling tests、新CLI selftest。候補suiteをsource-only、browser-integrated、OS-native、mozilla-importedで分類する。Host側のFirefoxテスト収集ツール自体の検査はsource QAに残せる。

受け入れ: package run内に１共通job、４package jobsが成功をneedsで要求。source jobでブラウザーを起動しない。empty/reduced/unknown-origin suiteを拒否。code/lock/toolchain/policyの差で同じ結果を使い回さない。初期は別run間dedupなし。

禁止: `deno task test`や`test:integration`をhost jobとして一括実行して「PGO製品を検査済み」としない。

## QA3-05: 既存 package probes と集計

対象: UA/Fluent・Flasco/既存native helper、`validate-final-package-qa.yml`。旧CLIのbind/plan/collect/gateを使用し、versionの固定文字列を認証済みmetadataへ汎用化する。差分生成器はadvisory用であり、この作業だけで公開gate完成とはしない。

受け入れ: Linux x64/mac Intel/mac ARMの許可済みfinal artifactsで実行。別artifact/record、sandbox無効、dev loader、wrong PID/cleanupを拒否。mac native probeも従来どおり実行。`existing-final`は２probeのsubsetと表示する。

## QA3-06: Floorp tests を packaged candidate で実行

対象: colocated runner/adapters、test bundle、feature contracts。production artifactを再build/改変せず、テストコードのみを外部から供給する。browser testsのoriginを明示し、通常package suiteにMozilla L1を混ぜない。

受け入れ: 既存Floorp testsのinventoryと移行表を提出。test runnerがexact browserを起動し、Floorp head/buildID2/native BuildID/loaderを照合。dev固有ケースを未移行と可視化。パス不明時に別binaryへfallbackしない。タブ/ワークスペース/再起動の固定caseと故障注入を含む。内部関数直呼びのケースはintegrationと表示する。

## QA3-07: 全５ target

Windows backend、Linux ARM、macOS arch別worker、OS input/display permissionsとprocess cleanupを整備。Debug L1と製品L2は異なるbinary/configで検証する。

受け入れ: native targetの実行証拠、owned PID/開始時刻/executable/profile、timeoutと子process、default launch、native右クリック。cross compileをnative実行に数えない。macOS Debugのsandbox overrideをprod workerへ継承しない。未対応targetを計画から黙って削らない。

## QA3-08: qualification と再利用

12 の別Subjectと適用条件を実装。Runtime-only qualificationをFloorp-only releaseで再利用可能にする。ただしsource/patch/toolchain/target/policy/失効を認証する。Debugと製品のBuildID一致を強制しない。

受け入れ: 同じsourceの適合例、異なるpatch/target/期限/producerの拒否例、debug-only差分未レビューの拒否例。L1が落ちてもPGO buildそのものを必要以上に再実行しないが、required phaseのpromotionを止める。source QAのcross-run再利用は別の厳格キーで評価する。

## QA3-09: 正式公開 gate

assemble→QA sidecar→manual approval→public verifier の非循環経路を構築。新pre-approval intakeは既存pending-deployment用helperと区別し、canonical source/artifact認証は維持する。closed v2 bundleは無変更で参照する。

受け入れ: 全target/result/qualification/sourceの欠落、旧attempt、wrong digest、unsigned、trustのないPASS JSON、期限切れ、QA後の差替えでpublic mutationが発生しない。manual approvalを省略できない。publisherのpolicyは候補PRから勝手に縮小できない。validation-onlyはproduction承認を得ない。

## QA3-10: L3

最初は１featureのregistered actionsと独立oracleを追加。model/controllerとbrowser workerを分離。known-bad/fixedで発見・fixed replay・回帰候補を評価する。操作数/時間/token/ディスクの上限を守る。

受け入れ: model障害を製品PASSにしない。権限逸脱拒否、固定replay、同じsignatureを維持した縮約。PGO問題をDebugだけの再現でfixed扱いしない。自動merge/quarantine/expectation変更/公開承認は禁止。

## QA3-11: 継続運用

eligible manifestの広域shard、変更影響選定、pairwiseと高リスク明示組合せ、quarantine owner/Issue/期限、retention、事故再現訓練を整備する。walltime/CPU/RAM/GUI占有/推論費用の実測で調整し、未測定の全量完走時間を約束しない。

着手順: **QA3-01 と QA3-04 → QA3-02/03 と QA3-05/06 → QA3-07/08 → QA3-09 → QA3-10/11**。独立作業は並行可能だが、受け入れ完了前にrequired化しない。

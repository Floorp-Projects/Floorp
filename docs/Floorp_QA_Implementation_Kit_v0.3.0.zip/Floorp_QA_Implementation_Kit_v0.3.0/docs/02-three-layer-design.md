# 02. ３層 QA 詳細設計 — Debug / 製品 Package 分離

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

## 1. 目標と責務

Desktop の主要操作、設定の組み合わせ、保存・復元、更新、OS 統合について、どのソース・成果物・環境・仕様を検査したかを追跡する。テスト完了・成功・期待された除外・未対応・未実行を分離する。

| 層 | 主な実行場所 | テスト対象 | 結果の主張 |
|---|---|---|---|
| L1: Upstream regression | Debug Runtime QA | tests-enabled native Debug build | 指定 Runtime source/config での Firefox 由来の契約 |
| L2: Floorp deterministic | 共通 source QA + 製品 package QA | Floorp tooling / 実際の製品 artifact | Floorp の仕様と統合後の動作 |
| L3: Agent exploration | Nightly/信頼済み候補の隔離 worker | 原則 packaged product、診断用 Debug は別 Subject | 未知の finding、再現列、固定テスト候補 |

L2 の source QA はブラウザーを必要としない検査だけを１回集約する。browser-integrated / native の部分は各対応対象で実行する。L1 の既存 compat subset は開発 CI に残してよいが、標準ハーネスと coverage を混同しない。

## 2. 共通制御

Planner が policy と対象を固定し、worker がテストを実行し、collector が証拠を保存し、trusted evaluator が予定と実行を照合する。実行器まで全て統一せず、Mozilla runner、Floorp colocated runner、Python native probe を薄い adapter で接続する。

```text
Debug Runtime build -> Debug test support -> Mozilla suites -> Runtime qualification
                                                                  |
Floorp source QA -> Product package -> Native verification -> Product L2
                                                                  |
                                              authenticated QA sidecar
                                                                  |
                                             manual approval + public gate

Product candidate -> Agent exploration -> captured finding -> fixed replay -> reviewed L1/L2
```

上図は採用する責務の図で、現行 workflow がすでに全経路を持つという表示ではない。正確なジョブ依存は 11、証拠の結び付けは 12 に定義する。

## 3. L1 — Debug Runtime で上流資産を実行

### ビルドと実行の分離

標準 profile は `debug=true, pgo=false, tests=enabled`。tests flag を最終 generated mozconfig で正規化し、configure 後の出力で確認する。PGO generate/use の既存フラグを変えない。test-support は同じ Debug build から生成し、必要な helper binary、test extensions、manifest、head/support files、generated assets、prefs、toolchain、symbols/capability を対応づける。

`mach package` のみでは test archives の完備を仮定しない。対象 revision の package-tests ターゲットや実ハーネスが必要とする生成手順を確認し、実在と native 実行まで受け入れる。`MOZ_ARTIFACT_FILE` は sibling test artifacts を自動供給しない。[M1]

### スイートの優先度

最初は Linux x64 の browser-chrome と xpcshell の代表群。次に macOS/Windows/Linux ARM へ native worker を拡張する。WPT、reftest/crashtest、gtest/低レベルテストは、必要な build capability と影響領域に応じて追加する。[M2–M4]

元の assertion、manifest 条件、SpecialPowers、ContentTask、head/support の意味を維持する。shim の no-op や未対応 API の黙示的 PASS は禁止。正規表現 triage は候補分類であって意味論の同等性証明ではない。

### 素の Runtime と overlay 統合を区別

Runtime 内部テストは Floorp overlay のない素の Debug Runtime で実行してよい。それを `runtime-only` と明記する。Floorp と上流 UI の相互作用を調べる suite は Debug と対応したテスト用 overlay で `overlay-loaded` sentinel を要求し、別 job / evidence kind とする。

**素の Runtime L1 を始めるために Floorp overlay adapter の完成を待たない。** 逆に素の Runtime の成功を Floorp 統合検証と表示しない。overlay build は Debug 試験対象に合わせ、Debug と release の binary/resources を混ぜない。

### 台帳と適格性

全 manifest を `discovered / eligible / upstream-disabled / approved-product-difference / harness-unsupported / quarantined / not-onboarded` で管理する。実行予定 ID は対応ハーネスの resolver から取得する。manifest/fixture lifetime を壊す分割はしない。

Debug L1 の成功から `RuntimeQualification` を作り、製品 build の upstream source と native patch 系列にリンクする。Debug と製品の BuildID/digest は異なる。qualification は製品バイナリの検査を代替しない。仕様と適用条件は 12。

## 4. L2 — ソース検査を集約し、製品を target ごとに検証

### Source QA

型/静的検査、Deno host tests、docs/tooling、QA 自身の unit tests 等の platform-independent subset を１共通 job に集約する。採用対象はテスト台帳で固定し、ブラウザーを起動するテストや OS 固有 helper テストは除いて別 job に配置する。既存 command の名称からブラウザー非依存と推測せず、内部呼び出しも確認する。

最初は同一 package run で１回。cross-run reuse は source SHA、dependency locks、policy、suite IDs、Deno/Node/Python、runner image 等の同一性と trusted producer を確認できた場合だけ導入する。単なる cache hit や main の緑チェックで代用しない。

### Packaged Floorp tests

既存の順序で build/inject/package し、署名・公証がある OS はそれらを終えた最終 artifact を対象にする。本番 packaging の `--disable-tests` は維持できる。L2 の test driver/bundle は配布物外にあり、製品ローダーを使用した本体を操作する。

Floorp colocated tests は `origin=floorp` と `executionKind` を台帳に付け、packaged-compatible なケースを受け入れながら移す。`origin=mozilla-imported` は通常の製品 package suite から除外する。ただし parser/wrapper 自体を試す host test は Floorp tooling なので残す。未分類 origin はスキップせず計画エラーにする。

現在の `deno task test` をそのまま最終 artifact の証拠としない。新しい packaged runner が必要なケースを明記する。runner が `_dist/bin` の別 Runtime を起動したら拒否し、HTTP dev loader/HMR の利用も拒否する。[F1][F11]

### Fixture / action / oracle

起動時の prefs による fixture 設定と、検証対象の UI 操作を区別する。E2E の状態変更は UI 相当入力で行う。内部 read は fixed observer、期待値は承認済み仕様から独立に定義する。本体の getter/serializer をそのまま正解にしない。

| 領域 | 初期の必須 postcondition |
|---|---|
| 起動/終了 | fresh/synthetic-existing profile、製品 loader、owned PID、終了と次回起動 |
| tabs/workspaces | 操作後のタブ集合・選択・所属が仕様どおり。保存・再起動で保持 |
| Web Panel | server で見た HTTP UA、切替/reload/navigation、通常 tab への非漏出 |
| context menu/Flasco | Fluent 欠損キーで停止しない。参加/離脱/失効で controller と保存レイアウトが正しく扱われる |
| native GUI/PWA | OS 右クリック、表示/dismiss/再表示、フォーカスと window lifecycle |
| Split View | 作成/解除/片側 close/別 workspace との組合せ |
| update/migration | 元版→先版の実 updater と synthetic profile 保持。profile を開くだけの検査は別 |
| privacy | 対象 store ごとの private/container lifetime。OS 全体の痕跡ゼロとは主張しない |

global pins、複数 window の workspace、private scope は仕様未決のまま invariant にしない。native MouseEvent と OS 入力を区別する。条件待ちは operation 前に登録し、timeout と未達状態を残す。固定 sleep だけに依存しない。

## 5. L3 — 探索、再現、固定テスト化

既定対象は L2 と同じ packaged product。Debug 上の診断探索は別 Subject とし、PGO での再現結果を別途保存する。特定の LLM/provider は必須にしない。Agent は source/feature contracts/観測状態を読み、許可済み action を提案する。

API は登録済み click/key/type/navigation/wait/observe/restart のみに段階拡張する。任意 shell、privileged eval、外部 URL、任意 selector は公開しない。固定 observer が内部状態を読み、既知の invariant はコードで判定する。未知の視覚的問題は review finding に留める。

`finding -> raw evidence -> fixed replay -> reduction -> bad/fixed test -> human review -> L1/L2`。同じ artifact、fixture、操作列、oracle、環境を保持する。縮約は fresh fixture と同じ failure signature を要求し、低再現率なら元の証拠も残す。Agent が製品と oracle を同時に書き換えて自己承認しない。

操作数、実時間、token/API、再起動、保存容量の budget を固定する。pilot の実装範囲は counter fixture と限定 click/observe/navigation、JSONL と replay であり、LLM adapter/全機能探索/縮約は未実装。モデル障害と budget 終了は製品 PASS ではない。

## 6. 共通の判定規則

FAIL、CRASH、TIMEOUT、missing shard、空計画、未対応、証拠改変、wrong artifact、未承認 SKIP、初回失敗後の retry PASS は clean PASS にしない。SKIP は policy と一致しても成功件数に加えない。test enabled / archive generated / discovered / executed / passed を別々に記録する。

予期した crash recovery の故障注入と unexpected crash を test ID と終了理由で区別する。ハーネス内がハングしても supervisor は外部から timeout と cleanup を管理する。minidump が無い場合も process exit/OS log/last heartbeat 等を残し、未取得能力を隠さない。

現行 CLI の `gate` は per-target のローカル判定で、常に `publicationAuthorized:false`。全体 release verifier の実装は 11/12 の作業。Debug/Source/Package の結果をすべて同じ Subject の `results.json` に押し込まない。

## 7. 段階導入

Debug の tests 有効化と最小 L1、source QA 集約を先に進める。既存 product probes の取り込みと全 Floorp tests の packaged 移行を並行して増やし、native target を揃えて正式公開 gate に接続する。最後に探索を拡大する。各段階の実装状態・未検証・対象外は台帳に残す。

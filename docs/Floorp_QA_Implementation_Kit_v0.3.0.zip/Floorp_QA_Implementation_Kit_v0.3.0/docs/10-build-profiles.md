# 10. ビルドプロファイル・フラグ仕様

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

## 入力と解決

既存 `debug` / `pgo` / `pgo_mode` は初期導入で維持する。新しい `debug-qa` は policy 上の profile 名で、既存 workflow にその入力があるという意味ではない。`debug=true,pgo=false` の組をこの profile として扱う。将来 enum 入力へ移す場合は既存呼び出しとの mapping を別 PR で追加する。[R1–R3]

| profile | DEBUG | PGO / mode | tests compile | 新規広域 L1 | Floorp L2 |
|---|---|---|---|---|---|
| `debug-qa` | true | false / empty | 明示 enable | 必須範囲を native worker で実行 | debug overlay 診断は任意/別証拠 |
| `production-pgo-generate` | false | true / generate | 既存を維持 | 通常は追加しない | profiling workload は維持 |
| `production-pgo-use` | false | true / use | 既存を維持 | 通常は追加しない | 最終製品 package で実行 |
| `production-opt` | false | false / empty | 既存を維持 | 通常は追加しない | 最終製品 package で実行 |
| `product-package` | false相当の製品対象 | 選択済み Runtime を継承 | artifact packaging は disable を維持 | 実行しない | source１回 + native対象別 |
| legacy `debug=true,pgo=true` | true | true | 既存実験の扱いを維持 | canonical Debug QA として受理しない | 製品 release の資格にも流用しない |

Linux ARM は現在 PGO false のため `production-opt` に対応する。OS 全体を「PGO版」の一言で抽出しない。[R1]

## フラグ変更点

Runtime `setup-floorp.sh` の config 生成で `debug && !pgo` の場合のみ tests を有効化する。各 template の既存 `--disable-tests` をグローバル削除しない。PGO generate/use の設定、profile collection の依存、LTO、Rust 最適化、release/native verification を維持する。

実装は最終 config 生成後に tests options の単一正本を作る方式を推奨する。単純な `echo --enable-tests` の追加だけで「最後が勝つ」と仮定しない。include/source された設定や複数行指定、矛盾した enable/disable を処理し、configure 後の結果を assertion する。

```text
resolve input and profile
  if debug-qa:
    reject nonempty PGO mode
    remove only active tests directives in controlled generated config
    add one enable-tests directive
    reject contradictory/generated unknown directives
  else:
    preserve effective tests setting and PGO pipeline
configure
  verify DEBUG / ENABLE_TESTS / artifact-build / profiling fields
  capture complete effective configuration and its source references
```

この擬似コードは実装仕様。任意 mozconfig の shell を安全に解析する完成コードではない。`config.status` 等の実出力フィールドは選定 Runtime の configure 実装から確認する。

## acceptance assertions

Debug QA では native compile environment、Debug 有効、tests 有効、PGO disabled、PGO generate/use disabled を確認する。テスト helper の実ファイル、architecture、BuildID、依存ライブラリ、対応 test archives を確認する。compile 成功だけで suite status を PASS にしない。

PGO/production-opt では変更前後の effective tests setting と profiling/LTO/最適化設定が不必要に変わっていないことを比較する。PGO generate は profile 取得用であり製品 artifact として QA/公開しない。fresh source で Debug flag を有効化しただけの古い binary は拒否する。

## Debug の test artifacts

同じ build で生成した binary と test-support を別 artifact に保持する。support の header は source/build/target/toolchain/mozconfig/harness/producer に紐づける。macOS は arch ごとの helper/test-support を universal app と混同しない。cross compile worker では generate だけ行い、実行は対応 native OS/arch へ渡す。

既存 `build-and-package.sh` が browser package を移動する時点より前後どちらで test archives を作るべきか、実ターゲットの依存を確認する。native build を同じ run で二度作り直す設計にはしない。packaged support に必要な `_tests`/生成環境の欠落をチェックする。

## Debug/製品間の差

Debug branding、debug patches、flat chrome、sandbox override、crashreporter capability を記録する。差分を全て「DEBUGだから」で許可せず、影響する suite と比較可能な契約を明示する。特に macOS の sandbox 設定を製品 QA へ継承しない。[R2]

PGO 固有の miscompile/最適化差は Debug L1 で網羅できない。製品 L2、既存 native probes、変更リスクに応じた別 opt/sanitizer campaign を補助とする。製品 performance の比較は同条件の製品 build 同士で行い、Debug の速度から合否閾値を作らない。[M5][M6]

## 本番 Package のフラグ

`--disable-tests --enable-artifact-builds` は初期導入で維持する。[F2] Floorp の test harness は外部から接続し、本番 assets / omni.ja / signatures は不変。旧 colocated tests が dev globals を要求する場合は packaged adapter を作るか、未移行ケースとして明示する。tests フラグを変えて自動的に全 colocated test が動くとは仮定しない。

# 03. 導入・実行 Runbook — 新方針

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

## 0. この版の実行範囲

最初に00/10/11/12を読む。本書のCLIは限定的な既存実装を動かす手順であり、DebugのCI変更や全packaged runnerを自動導入するものではない。新しい順序はQA3-01/04から。実CIへの接続方法は11と作業票04を正とする。

```bash
# キットrootで設計契約を検査する。ビルドやCI起動はしない。
python3 tools/qa/design_contract.py
```

`release-readiness`は旧名互換の製品L2-only計画。新規には`--profile production-package-readiness`を使う。Debug L1は別producer/Subjectであり、製品planへ追加しない。全体release gateは未実装で、ローカルgateは公開許可を返さない。

## 1. 作業の前提

別 worktree／ブランチを使います。Python 3.12+ と Git が必要です。ブラウザー起動には credential-free の専用 GUI worker、ネイティブ権限、対象 architecture、既存 Floorp helper が必要です。`QA_DISPOSABLE_WORKER=1` は環境を隔離する機能ではなく、整備済み worker を明示する確認フラグです。

キット root と Floorp checkout root は別です。`install.py` の適用後は Floorp root から同じ CLI を呼べます。以下のプレースホルダーは実際のローカルパスに置き換えてください。

## 2. オフライン検証と追加

```bash
cd /path/to/Floorp_QA_Implementation_Kit_v0.3.0
python3 -m unittest discover -s tools/qa/tests -v
python3 install.py --repo /path/to/Floorp
python3 install.py --repo /path/to/Floorp --apply
cd /path/to/Floorp
python3 tools/qa/qa.py doctor --repo . --out /tmp/qa-source-audit.json
```

doctor が REVIEW_REQUIRED の場合、どの blob が変わったかを読む。自動で pin を更新しない。Git の CRLF checkout 差も drift に含むため、Windows では Git object と worktree の差をレビューする。diagnostic は coverage／build 成功の証拠ではない。

## 3. 既存 QA 接続のレビュー用 patch

```bash
python3 tools/qa/propose_integration.py --repo . --out /tmp/qa-advisory.patch
git apply --check /tmp/qa-advisory.patch
# 内容をレビューした後、明示的に実行する。
# git apply /tmp/qa-advisory.patch
```

生成差分は deno task の入口追加、既存２ probe のバージョン固定値の汎用化、final QA の subject/plan/collect/gate の追加です。実行ブラウザーと認証済み record の version 比較は残します。既存の `validateFinalPackageSource`、５ native gate、pre-publication の再確認、署名設定、公開承認は変更しません。

追加集計は `continue-on-error:true` の advisory ですが、**既存の実 probe の失敗は従来どおり失敗**です。advisory と書かれているのを理由に重大な finding を無視しません。公開必須化は別 work order です。

この作成環境では full checkout に対する実 `git apply --check` は実施していません。生成器は対象 blob が一致したときだけ差分を出すため、古いソースへ無検査で適用する危険を避けます。

## 4. 既存 final QA の途中に接続する

接続位置は **既存 workflow が GitHub run/artifact の認証と native record 抽出を終えた後**です。`package.zip` と `record.zip` は同 workflow がダウンロードして API digest を確認した ZIP をそのまま使います。

```bash
qa="$RUNNER_TEMP/final-package-qa"
python3 tools/qa/qa.py bind-final \
  --input "$qa/input.json" \
  --native-record "$qa/native-verification.json" \
  --package-zip "$RUNNER_TEMP/package.zip" \
  --record-zip "$RUNNER_TEMP/record.zip" \
  --out "$qa/qa-subject.json"

python3 tools/qa/qa.py plan \
  --subject "$qa/qa-subject.json" \
  --profile existing-final \
  --out "$qa/qa-plan.json"
```

`bind-final` に自作 JSON を渡しても producer の認証にはなりません。従来の source intake を省略する使い方は禁止です。subject は `sourceEligibility` と `probeHead` を読取コンテキストとして保存しますが、その前後の GitHub 再確認は既存 helper に任せます。

既存の UA／Fluent-Flasco／mac native probe を従来どおり実行後、次を追加します。

```bash
python3 tools/qa/qa.py collect-final \
  --plan "$qa/qa-plan.json" --subject "$qa/qa-subject.json" \
  --native-record "$qa/native-verification.json" \
  --qa-root "$qa" --evidence-root "$qa" \
  --out "$qa/qa-results.json"

python3 tools/qa/qa.py gate \
  --plan "$qa/qa-plan.json" --subject "$qa/qa-subject.json" \
  --results "$qa/qa-results.json" --evidence-root "$qa" \
  --out "$qa/qa-verdict.json"
```

既存と同じ `web-panel-ua/run-*/report.json`、`fluent-flasco/run-*/report.json` を読みます。各 case が複数見つかれば ambiguous として停止します。再実行のログを同じ directory に混ぜず、attempt ごとに別 evidence root を使ってください。collector の初期実装は attempt=1。将来の retry collector は元失敗を保存して attempt を連番化する必要があります。

レポート内容と対象、sandbox／loader、PID／終了状態を検査します。gate が PASS でも既存２ case の scoped PASS であり、全機能の公開判定にはなりません。

## 5. 既存 probe のローカル実行補助

承認済みの staging 手順で exact package から配置した browser と、認証済み native record を使います。任意 browser path が同じ version を返すだけでは archive との同一性の証明になりません。

```bash
export QA_DISPOSABLE_WORKER=1
python3 tools/qa/qa.py run-probe --repo . \
  --case l2.web-panel-http \
  --browser /isolated/staged/floorp \
  --native-record /isolated/evidence/native-verification.json \
  --floorp-version 12.20.1 \
  --timeout 600 --out /isolated/runs/ua-attempt-001
```

上の version は確認 baseline の例。通常は認証済み `input.json` の `floorpVersion` を使います。macOS は `.app` path。`run-probe` の process-result は終了コードの観測であり、これだけで QA 成功にしません。詳細結果は `out/raw/run-*/report.json` にあります。

既存 workflow の folder 配置と standalone runner の `raw/` 配置は異なります。standalone はファイルを移動せず、専用の `collect-probe` で process 終了と詳細 report を一緒に取り込みます。

```bash
python3 tools/qa/qa.py collect-probe \
  --plan /isolated/qa-plan.json --subject /isolated/qa-subject.json \
  --native-record /isolated/evidence/native-verification.json \
  --case l2.web-panel-http --run-dir /isolated/runs/ua-attempt-001 \
  --evidence-root /isolated --out /isolated/ua-results.json
```

複数 case の結果は gate の `--results` に複数ファイルを渡します。同じ case の同一 attempt を重複提出しません。

## 6. Debug L1 の台帳・資材・ログ検査

```bash
python3 tools/qa/qa.py inventory-runtime \
  --runtime-dir /path/to/Runtime-test-checkout \
  --out /isolated/inventory.json
```

inventory は条件未評価の台帳です。`eligibleCount:null` を 0 や総 test 件数と誤読しません。

`debug=true,pgo=false` の genuine native tests-enabled Debug build で作成した support archives を別 artifact にまとめる例：

```bash
python3 tools/qa/qa.py pack-test-bundle \
  --runtime-dir /path/to/Runtime-test-checkout \
  --runtime-sha "$VERIFIED_TEST_SOURCE_SHA" \
  --target linux/x86_64 --build-id "$VERIFIED_TEST_BUILD_ID" \
  --mozconfig /path/to/test.mozconfig \
  --application-ini /path/to/test-obj/dist/bin/application.ini \
  --materials /path/to/test-obj/dist \
  --file common.tests.zip --file mochitest.tests.zip \
  --out /isolated/runtime-test-support.zip
```

ファイル名は例であり、実 build の生成物を inventory して指定します。`--disable-tests` や `--enable-artifact-builds` を含む config は拒否します。別ファイルの source／条件分岐を含む effective config の完全検証は Runtime 側で実施してください。

Mozilla 本来の実行は、対応する test build／overlay／manifest が揃った worker で行います。公式に記載された browser-chrome と raw log の組み合わせ例：

```bash
# Runtime の対応する Debug native build checkout で実行する。配布 packaging の objdir ではない。
./mach mochitest -f browser --log-raw=/isolated/raw-mozlog.jsonl \
  path/to/reviewed/browser.toml
```

このコマンドを実行する前に、対象 manifest が現 checkout に存在し、必要な support を検証してください。Runtime-only L1にはoverlayは必須ではありません。overlay統合suiteとして実行する場合にだけ対応するFloorp bootstrap sentinelを要求します。ハーネスの終了コードを CI supervisor が保存し、同じハーネスが解決した exact ID の JSON 配列を次に渡します。

```bash
python3 /path/to/Floorp/tools/qa/qa.py check-mozlog \
  --raw /isolated/raw-mozlog.jsonl \
  --tests /isolated/resolved-test-ids.json \
  --exit-code "$HARNESS_EXIT_CODE" \
  --evidence-root /isolated \
  --out /isolated/mozlog-verdict.json
```

`--verify`／repeat の結果を単一 cycle として取り込まない。threshold 診断が出た場合は upstream の意味論を保持した adapter が必要です。このログ検査は runtime source authentication や overlay sentinel の代わりではありません。

## 7. Agent pilot と固定リプレイ

```bash
# ポリシー検査のみ。ブラウザーは起動しない。
python3 tools/qa/qa.py check-actions \
  --actions qa/scenarios/counter-actions.json --out /isolated/actions-checked.json

# Linux/macOS の専用 GUI worker。署名済み production subject が必要。
QA_DISPOSABLE_WORKER=1 python3 tools/qa/qa.py replay \
  --repo . --browser /isolated/staged/Floorp.app \
  --subject /isolated/qa-subject.json \
  --actions qa/scenarios/counter-actions.json \
  --max-actions 50 --seconds 300 --out /isolated/replay-001

# 保存した同じ subject の操作列を再生する。
QA_DISPOSABLE_WORKER=1 python3 tools/qa/qa.py replay \
  --repo . --browser /isolated/staged/Floorp.app \
  --subject /isolated/qa-subject.json \
  --actions /isolated/replay-001/replay.json \
  --out /isolated/replay-002
```

Linux では browser を実行ファイルに置き換えます。新しい profile は各 campaign で自動作成されます。native input、全子プロセス crash、全 feature の oracle は未導入です。

`agent-stdio` は同じ起動引数で `--actions` を省いた双方向 JSON-lines インターフェースです。最初に observation と allowedTargets を stdout に出し、stdin の１ action に対して outcome と observation を返します。LLM adapter は親プロセス／別サービスとして接続します。

```json
{"kind":"navigate","fixture":"counter"}
```

モデルに任意 shell を渡す必要はありません。新しい target は trusted registry に追加してテストします。fixture／DOM から自由に selector や script を採用しません。`input-ended`／`budget-exhausted`／`replay-complete` は探索・再生の状態で、製品品質の PASS ではありません。

## 8. 終了コードと診断

| code | 意味 |
|---|---|
| 0 | コマンドの目的を完了。scope／status を必ず読む |
| 1 | gate BLOCK、観測 FAIL、または完了不足等 |
| 2 | 入力契約不一致、環境エラー、ソース drift 等 |

ERROR は PASS ではありません。成果物 ZIP／record／report の不一致で止まった場合、validation の条件を削って通すのではなく、元 run と exact artifact を再確認します。timeout 後はブラウザー名で一括 kill せず、所有 worker を破棄します。

## 9. 新しいCIの実装順序

Debugのflag有効化→test assets→Runtime-only L1を一系統、source job集約→既存final probes→全Floorp testsのpackaged移行をもう一系統として実装する。PGO generate/useは既存どおり、製品packageの--disable-testsも維持する。L1のqualificationと製品結果を結ぶ正式gateはQA3-08/09で追加する。

現在のCLIのpack-test-bundleはarchive結合補助であり、実ハーネスが使えるarchiveをビルドするコマンドではない。実configure/build、native tests、Deno、Actions、モデルAPIの実行結果は作業環境で別途報告する。

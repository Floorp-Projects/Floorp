# 09. 出典・ソース基準・確認範囲

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

Floorp head: `013bb6c9ed19250592898ec8fbc8d7d24aa847be`。Runtime観測head: `c74fe1a545d275cdd710ab44701c1ee0dd6b0eae`。いずれも2026-10-09のGitHub connectorでbranch headを再確認した。今回再読したのはRuntime daily-build/setup、Floorp deno.jsonとpackage.ymlのtests設定。残る構成は本会話内で同じheadに対して確認したソースを引き継ぐ。全treeをcloneして再監査/ビルドしたという意味ではない。

`qa/source-pins.json`はread-only drift検査の資料であって、本番Runtime選択の正本ではない。実releaseのRuntimeは認証済みrun/manifestから解決する。

## Floorp

- **[F1] `AGENTS.md`** — ５層構成、dev/testと製品loader、colocated/Marionette。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/AGENTS.md`
- **[F2] `.github/workflows/package.yml`** — artifact build、tests無効、native artifact、before/after-mach、mac最終outputs。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/.github/workflows/package.yml`
- **[F3] `.github/workflows/package_and_publish_release.yml`** — ４package/５native verification/assemble/publish。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/.github/workflows/package_and_publish_release.yml`
- **[F4] `.github/workflows/verify-release-artifact.yml`** — native実行、build identity、署名、v2 record。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/.github/workflows/verify-release-artifact.yml`
- **[F5] `.github/workflows/assemble-release-bundle.yml`** — closedなbundle v2とnative record依存。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/.github/workflows/assemble-release-bundle.yml`
- **[F6] `.github/workflows/validate-final-package-qa.yml`** — #2886、既存probes、公開待機のread-only再照合。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/.github/workflows/validate-final-package-qa.yml`
- **[F7] `tools/final-package-qa-source.mjs`** — pre-publicationのsource/先行jobs/bundle/approval条件。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/tools/final-package-qa-source.mjs`
- **[F8] `tools/test-final-web-panel-ua.py`** — 実HTTP/製品loader/isolated profile。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/tools/test-final-web-panel-ua.py`
- **[F9] `tools/test-final-context-menu.py`** — Fluent/Flasco/内部popupを使うintegration。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/tools/test-final-context-menu.py`
- **[F10] `tools/app-shim/test-runtime.py`** — Marionette/POSIX/LaunchServices/owned process。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/tools/app-shim/test-runtime.py`
- **[F11] `deno.json`** — source向けtaskとbrowser-integrated taskの違い。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/deno.json`
- **[F12] `tools/src/release_provenance.ts`** — strict closed schema、existing native/release provenance。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/tools/src/release_provenance.ts`

## Floorp-Runtime

- **[R1] `.github/workflows/daily-build.yml`** — debug/pgo入力、Linux ARM pgo=false、build/verify/manifest条件。
  `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/daily-build.yml`
- **[R2] `.github/workflows/scripts/setup-floorp.sh`** — template選択、Debug patch/flag、mac sandbox export、PGO分岐。
  `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/scripts/setup-floorp.sh`
- **[R3] `.github/workflows/scripts/build-and-package.sh`** — native compile/packageとprimary artifact生成。
  `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/scripts/build-and-package.sh`
- **[R5] `.github/runtime-upstream.json`** — compiled upstreamとnative patch pin。
  `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/runtime-upstream.json`

**[R4] OS別mozconfig** — tests directiveの表は本会話内のsource読取に基づく。同じRuntime headを再確認したが、実effective configは未検証。

- `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/mozconfigs/windows-x86_64.mozconfig`
- `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/mozconfigs/linux-x86_64.mozconfig`
- `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/mozconfigs/linux-aarch64.mozconfig`
- `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/mozconfigs/macosx64-x86_64.mozconfig`
- `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/mozconfigs/macosx64-aarch64.mozconfig`

**補足経路:** `.github/workflows/common-build.yml` と各wrapperはsetup/build scriptへの引数を渡す。OS wrapperにtests runnerが自動的に含まれていると仮定しない。

## Mozilla / GitHub公式資料

- **[M1]** artifactのC++再利用、MOZ_ARTIFACT_FILEにtest siblingが含まれないこと。
  `https://firefox-source-docs.mozilla.org/contributing/build/artifact_builds.html`
- **[M2]** Desktop UI、manifest、real focus/inputとheadlessの制約。
  `https://firefox-source-docs.mozilla.org/testing/browser-chrome/index.html`
- **[M3]** mach/test、raw structured logとtestsの役割。
  `https://firefox-source-docs.mozilla.org/testing/mochitest-plain/index.html`
- **[M4]** 内部module向けテストの参考。参照は前版から継承。
  `https://firefox-source-docs.mozilla.org/testing/xpcshell/index.html`
- **[M5]** profile-generate→profiling workload→profile-useの過程。
  `https://firefox-source-docs.mozilla.org/build/buildsystem/pgo.html`
- **[M6]** Debugと製品performanceの比較条件の違い。
  `https://firefox-source-docs.mozilla.org/performance/Benchmarking.html`
- **[M7]** browser chrome/content automation。参照は前版から継承。
  `https://firefox-source-docs.mozilla.org/remote/marionette/Intro.html`
- **[M8]** 未信頼code/runner/credential境界。参照は前版から継承。
  `https://docs.github.com/en/actions/reference/security/secure-use`
- **[M9]** WPT harness/metadata。参照は前版から継承。
  `https://firefox-source-docs.mozilla.org/web-platform/index.html`
- **[M10]** repeat/verify完了と時間上限。参照は前版から継承。
  `https://firefox-source-docs.mozilla.org/testing/test-verification/index.html`

M1/M2/M3/M5/M6は本改訂でもwebで確認。一般Firefoxの対応はFloorp固有artifact/テスト資材の実行保証ではない。CLIの実際のoption・生成物は選んだRuntime revisionのハーネスで検証する。

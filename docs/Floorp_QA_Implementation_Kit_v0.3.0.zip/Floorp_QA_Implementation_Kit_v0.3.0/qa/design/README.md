# 機械可読の設計契約 / 0.3.0

`build-policy.json`と`ci-graph.json`は採用方針の静的モデル。GitHub Actionsが消費するruntime設定ではない。既存qa.py plan/gateがこのpolicyを評価するという意味でもない。

`python3 tools/qa/design_contract.py`でschema/意味上の不変条件とDAGを検査する。unit testsは誤ったDebug/PGO/tests、Linux ARM欠落、source重複、依存循環、manual approval省略、L1の製品plan混入を拒否することを検証する。

新Subject/Qualification/ReleaseQASidecarの実行スキーマはdocs/12を基に別作業で実装する。現行ProductSubject v1へDebug evidenceを無理に押し込まない。

# Schema と意味検査 / 0.3.0


JSON Schema Draft 2020-12 の形状契約です。ランタイム CLI は外部ライブラリに依存せず、`core.py`／`agent.py` の意味検査も使います。

shape が正しいことだけでは合格しません。plan／subject の再計算、trusted policy、実際の archive bytes、native record binding、lifecycle、case／attempt の網羅、evidence の safe path と digest を検査する必要があります。

`runtime`／`sourceEligibility` は既存認証済み native／source validator 由来の payload を保持する箇所です。ここに `additionalProperties:false` を付けて実物と異なる v2 schema を勝手に再定義しません。詳細の正本は既存 `release_provenance.ts` と source helper です。

`details` は診断 payload。診断内の文章や PASS らしい文字列を gate の合否として解釈しません。

## 新しい設計用schema

`build-policy.schema.json`と`ci-graph.schema.json`はqa/designの形状だけを表す。design_contract.pyで採用値、境界、target、非循環DAGも検査する。実CIの設定やSubject/evidenceではない。

plan.schema.jsonは新しいproduction-package-readiness名を認識する。release-readinessは同じL2-only範囲の旧名alias。ProductSubject v1へのL1/mozilla-harness混入はcore.pyで拒否する。DebugRuntimeSubject/qualification/全体release verifierは未実装。

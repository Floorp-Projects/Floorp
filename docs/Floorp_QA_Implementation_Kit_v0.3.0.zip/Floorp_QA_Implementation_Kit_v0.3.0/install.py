#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Add new toolkit files to a Floorp checkout. Dry-run by default, no overwrites."""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    repo = args.repo.resolve(strict=True)
    if not (repo / "deno.json").is_file() or not (repo / "tools").is_dir():
        raise ValueError("Expected a Floorp source checkout (deno.json and tools/)")
    copies = []
    for directory in ("tools/qa", "qa"):
        for source in sorted((root / directory).rglob("*")):
            if not source.is_file() or "__pycache__" in source.parts or source.suffix == ".pyc":
                continue
            relative = source.relative_to(root)
            copies.append((source, repo / relative))
    for source in sorted((root / "docs").glob("*.md")):
        copies.append((source, repo / "docs/qa" / source.name))
    for source, target in copies:
        if source.is_symlink():
            raise ValueError(f"Linked source refused: {source}")
        for parent in [target, *target.parents]:
            if parent == repo:
                break
            if parent.is_symlink():
                raise ValueError(f"Linked destination refused: {parent}")
        if target.exists():
            raise ValueError(f"No-overwrite install: {target} already exists. Reconcile manually.")
    for source, target in copies:
        print(("ADD " if args.apply else "WOULD ADD ") + str(target.relative_to(repo)))
        if args.apply:
            target.parent.mkdir(parents=True, exist_ok=True)
            with source.open("rb") as src, target.open("xb") as dst:
                shutil.copyfileobj(src, dst)
    print("No workflows, existing files, Git commits, signing settings or publication settings were modified.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError) as exc:
        print(str(exc), file=sys.stderr); raise SystemExit(2)

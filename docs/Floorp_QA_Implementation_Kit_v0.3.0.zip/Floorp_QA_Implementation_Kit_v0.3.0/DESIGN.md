# Floorp ３層 QA 総合設計書

**版 0.3.0 — Debug Runtime / 製品 Package 分離方針**  
2026-10-09 / Desktop / 設計・導入仕様

Debug RuntimeでMozilla上流テストを実行し、PGO/opt Runtime生成は既存構成を維持する。Floorpのsource-only QAは共通で１回、browser/native QAは最終製品artifact×native targetごとに実行する。Agentは探索・固定再現・回帰テスト化を担う。

本書はキットの14文書を統合した閲覧用の正本ビューです。書類・限定ツールを改訂したもので、実リポジトリのCI/ビルド/公開設定を変更したものではありません。

## 目次

- [00. 採用方針と変更決定](#doc-00)
- [01. 現行ビルド構成と変更境界](#doc-01)
- [10. ビルドプロファイル・フラグ仕様](#doc-10)
- [02. ３層 QA 詳細設計 — Debug / 製品 Package 分離](#doc-02)
- [11. CI・公開ゲートの依存関係](#doc-11)
- [12. 証拠・再利用・Debug と製品のリンク契約](#doc-12)
- [03. 導入・実行 Runbook — 新方針](#doc-03)
- [04. 実装作業票 — 新方針への置換](#doc-04)
- [05. 受け入れ基準・導入状態](#doc-05)
- [06. セキュリティ・障害・継続運用](#doc-06)
- [08. 実装 Agent への引き継ぎ — Debug / 製品分離](#doc-08)
- [13. 0.2.0 からの変更・移行手順](#doc-13)
- [07. 検証報告 / 0.3.0](#doc-07)
- [09. 出典・ソース基準・確認範囲](#doc-09)


---

<a id="doc-00"></a>

## 00. 採用方針と変更決定

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

### 採用した構成

**Debug Runtime でテストをビルドし、Mozilla の上流テストを実行する。PGO/製品 Runtime の生成経路は維持し、Floorp を組み立てるリリース工程で Floorp 独自のテストを実行する。Agent は未知の不具合を探し、固定テストへ還元する。**

「３層」はテストの責務、「Debug / PGO / Package」は実行対象とタイミングである。３層と３種類のビルドを１対１に対応させない。

| 決定 ID | 採用内容 | しないこと |
|---|---|---|
| ADR-01 | 標準 Debug QA は `debug=true, pgo=false`。Runtime の最終 effective config で tests を有効化する | PGO generate/use の設定をまとめて書き換えない |
| ADR-02 | Debug の native build から対応する test archives / helper / symbols を別 artifact として保持し、native worker で L1 を実行する | `--enable-tests` や `mach package` の成功をテスト成功と数えない |
| ADR-03 | PGO generate/profile collection/use と既存 native verification を維持。新しい広域 L1 は通常の PGO build に追加しない | テスト用コンパイルを一律 disable にしない。PGO の profiling workload も削らない |
| ADR-04 | Floorp ソースだけの検査は package orchestration 内の共通ジョブで１回。ブラウザー依存テストはここに混ぜない | 各 package target で同じ platform-independent source suite を繰り返さない |
| ADR-05 | `before-mach → mach build → after-mach → package/署名・公証` を維持し、最終 artifact を対象 OS で L2 検証する | HMR / dev Runtime の PASS を実配布物の PASS に読み替えない |
| ADR-06 | 本番 packaging の `--disable-tests` は初期導入で維持。外部 L2 runner を接続する | Floorp の TypeScript テストを動かすためだけに Gecko tests を有効化しない |
| ADR-07 | Debug L1 は Runtime のソース適格性、製品 L2 は exact artifact の動作証拠として別 Subject にする | 異なる BuildID/バイナリを同じ対象として結合しない |
| ADR-08 | native / provenance / 署名・公証 / 手動承認は既存のまま。将来の公開必須化は publisher 側で認証済み QA sidecar を検証する | QA worker に公開権限を渡さない |
| ADR-09 | PGO を使わない製品版も `production-opt` として L2 必須に含める | `pgo == true` だけを条件にして Linux ARM 等を取り落とさない |
| ADR-10 | L3 は初期 advisory。確かな crash 等の一次証拠は別途重大 finding として扱う | Agent の正常宣言や API 障害を L1/L2 の合否に混ぜない |

### 「１回」の定義

共通の source suite は **同一の検査入力キーにつき１回の初回評価**、packaged suite は **最終成果物 × native target × 承認済みシナリオにつき１回の初回評価** とする。１シナリオ内で右クリックを反復する、同一 profile で再起動する、といった仕様上の操作は重複検査ではない。

当初は package run 内で source job を１個に集約する。別 run の結果を再利用する場合は Floorp SHA だけでなく lock、toolchain、OS、policy、suite、fixture、producer を一致させる。再試行は初回失敗を消さない。source job が失敗した場合、package job は開始しない。

### 保証範囲

Debug PASS は PGO 最適化固有の回帰、署名、通常起動を保証しない。そのため製品 L2 を省略しない。L2 も Gecko 内部全経路を保証しない。Runtime 更新候補の追加 opt/sanitizer 試験はリスクに応じた別 campaign とし、通常 PGO build に全 suite を戻さない。

この版で実装済みなのは旧 CLI の限定機能と改訂した設計契約の検査である。新たな Debug CI、Runtime test archive 生成、全 Floorp colocated tests の packaged 実行、正式 publisher gate は作業票で実装する。全体実装済みと表示しない。

### 文書の優先順位

本書 → [10-build-profiles](#doc-10) / [11-ci-topology](#doc-11) / [12-evidence-contracts](#doc-12) → 詳細設計 → 作業票。機械可読の `qa/design/build-policy.json` と `ci-graph.json` はこの方針の整合検査用であり、実 workflow を変更する設定ファイルではない。

前版 0.1 / キット 0.2.0 の「PGO リリースごとに別の test-enabled build を必ず作り直す」「製品 Subject に L1 全 suite をぶら下げる」という読み方は廃止する。[13-migration](#doc-13) に変更範囲を記録した。


---

<a id="doc-01"></a>

## 01. 現行ビルド構成と変更境界

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

### 観測したソース

Floorp `013bb6c9ed19250592898ec8fbc8d7d24aa847be`（#2886）、Floorp-Runtime `c74fe1a545d275cdd710ab44701c1ee0dd6b0eae` を基準とする。今回、両 branch の head、Runtime setup/daily-build、Floorp deno tasks と packaging の tests 設定を再確認した。その他の既存契約は、同じ head を読んだ本会話の前回調査を引き継ぐ。出典 ID は [09-sources](#doc-09) を参照。CI 成功や effective configure 結果を確認したという意味ではない。

### Runtime の構成

`daily-build.yml` → OS wrapper → `common-build.yml` → `setup-floorp.sh` / `build-and-package.sh` が主経路。DEBUG と PGO は独立入力であり、手動実行の既定値は両方 true。Linux ARM の呼び出しは `pgo:false` である。[R1–R3]

| Runtime mozconfig | active な `--disable-tests` | 読み取れる範囲 |
|---|---|---|
| Windows x86_64 | コメントアウト | 当該 template では tests を禁止していない |
| Linux x86_64 / aarch64 | コメントアウト | 同上 |
| macOS x86_64 / aarch64 | 有効 | 当該 template では無効化している |

この表は template の観測であり、生成後の config や全 native test の実行可否を証明しない。[R4]

setup は DEBUG に対して debug patch、debug branding、`--enable-debug` を追加する。macOS Debug では `MOZ_DISABLE_CONTENT_SANDBOX=1` を mozconfig の export に加える処理もある。実際の test process の環境・prefs を観測し、通常の製品 sandbox と同等だと解釈しない。[R2]

build-and-package は `mach configure/build/package` を行い、既存 primary artifact を構成する。`mach package` は広域 suite を実行したという意味ではなく、必要な test archives が upload されたとも限らない。テスト資材は実 build output を検査して保持する。[R3][M1]

### 二つの Runtime 選択経路

| 用途 | 既存の正本 | 新 QA の扱い |
|---|---|---|
| 開発・通常 colocated CI | `floorp-runtime.lock.json` | 引き続き既存の開発 Runtime と upstream subset を識別 |
| 本番 stable-v2 | 認証済み daily-build run / manifest / artifact | exact Runtime の native identity を継承 |
| 新規 Debug L1 | 認証済み Debug build / test-support / suite producer | 独立した DebugRuntimeSubject。製品 Subject に変換しない |

Runtime repo head、実コンパイル upstream commit、native patch、debug-only patch、Floorp overlay head は別情報として保持する。新しい Debug の BuildID は自身の run のものを使い、製品版に合わせて偽装しない。[F2][R1][R5]

### Floorp packaging

`package.yml` の workspace root は Runtime、`noraneko/` が Floorp。既存 native artifact を認証して staging し、Floorp の before-mach、`MOZ_ARTIFACT_FILE=... ./mach build`、after-mach/injection を通す。生成 mozconfig は `--enable-release --disable-tests --enable-artifact-builds` と artifact 用 objdir を使用する。[F1–F3]

**今回の採用方針では、本番 packaging の tests フラグは維持する。** Gecko のテストビルド能力と、配布物を外部から検査する Floorp L2 の能力は別である。C++/Rust の変更は Runtime の native build に反映しなければならない。[F1][M1]

primary Runtime artifact のトップレベル要素は既存の検証対象である。test-support を同じ archive に追加せず別 artifact にする。macOS の installer/MAR は `macos-ticket-verify` を優先する最終 workflow outputs を使う。[F2]

### ４ package と５ native execution target

| target key | package artifact（production） | 方針 |
|---|---|---|
| `windows/x86_64` | `noraneko-windows-x86_64-installer` | Windows native L2 |
| `linux/x86_64` | `noraneko-linux-x86_64-installer` | Linux x64 L2 |
| `linuxAarch64/aarch64` | `noraneko-linux-aarch64-installer` | 非 PGO でも製品 L2 |
| `mac/x86_64` | `noraneko-mac-universal-installer` | Intel native L2 |
| `mac/aarch64` | 同上 | Apple Silicon native L2 |

同じ universal archive に対する２つの native 実行結果は統合しない。ビルド用 Linux worker に Windows/macOS GUI の実行能力があるとは仮定しない。[F2–F4]

### 公開経路の現状

`native verification → assemble release bundle → draft → protected approval → public release/update/portable/PPA` が既存の依存関係。#2886 の別 workflow は公開承認待機の前後を read-only で検査できるが、publisher の必須 dependency や lock ではない。[F3–F7]

新設の正式 gate は [11-ci-topology](#doc-11) の target DAG に従う。旧 helper の `pendingDeployments` 条件を、まだ承認待機へ到達していない新しい inline job にそのまま使わない。source/artifact の検証を弱めず、実行フェーズごとの validator を区別する。

### 既存資産の再利用

Deno host/smoke/docs/tooling tests、実ブラウザー内の colocated tests、Firefox 互換 subset、Marionette、UA probe、Fluent/Flasco probe、macOS native GUI probe を残す。`deno task test` は browser-integrated runner であってソースだけのテストではない。`test:integration` はそれと OS API 検査を結合しているため、共通 host job に無検査で移さない。[F1][F8–F11]

UA probe は実 HTTP、Fluent probe は内部 popup/catalog/fixture 操作を含む。これをすべて純 black-box / native right-click と呼び替えない。各 test の操作方式と oracle を記録する。


---

<a id="doc-10"></a>

## 10. ビルドプロファイル・フラグ仕様

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

### 入力と解決

既存 `debug` / `pgo` / `pgo_mode` は初期導入で維持する。新しい `debug-qa` は policy 上の profile 名で、既存 workflow にその入力があるという意味ではない。`debug=true,pgo=false` の組をこの profile として扱う。将来 enum 入力へ移す場合は既存呼び出しとの mapping を別 PR で追加する。[R1–R3]

| profile | DEBUG | PGO / mode | tests compile | 新規広域 L1 | Floorp L2 |
|---|---|---|---|---|---|
| `debug-qa` | true | false / empty | 明示 enable | 必須範囲を native worker で実行 | debug overlay 診断は任意/別証拠 |
| `production-pgo-generate` | false | true / generate | 既存を維持 | 通常は追加しない | profiling workload は維持 |
| `production-pgo-use` | false | true / use | 既存を維持 | 通常は追加しない | 最終製品 package で実行 |
| `production-opt` | false | false / empty | 既存を維持 | 通常は追加しない | 最終製品 package で実行 |
| `product-package` | false相当の製品対象 | 選択済み Runtime を継承 | artifact packaging は disable を維持 | 実行しない | source１回 + native対象別 |
| legacy `debug=true,pgo=true` | true | true | 既存実験の扱いを維持 | canonical Debug QA として受理しない | 製品 release の資格にも流用しない |

Linux ARM は現在 PGO false のため `production-opt` に対応する。OS 全体を「PGO版」の一言で抽出しない。[R1]

### フラグ変更点

Runtime `setup-floorp.sh` の config 生成で `debug && !pgo` の場合のみ tests を有効化する。各 template の既存 `--disable-tests` をグローバル削除しない。PGO generate/use の設定、profile collection の依存、LTO、Rust 最適化、release/native verification を維持する。

実装は最終 config 生成後に tests options の単一正本を作る方式を推奨する。単純な `echo --enable-tests` の追加だけで「最後が勝つ」と仮定しない。include/source された設定や複数行指定、矛盾した enable/disable を処理し、configure 後の結果を assertion する。

```text
resolve input and profile
  if debug-qa:
    reject nonempty PGO mode
    remove only active tests directives in controlled generated config
    add one enable-tests directive
    reject contradictory/generated unknown directives
  else:
    preserve effective tests setting and PGO pipeline
configure
  verify DEBUG / ENABLE_TESTS / artifact-build / profiling fields
  capture complete effective configuration and its source references
```

この擬似コードは実装仕様。任意 mozconfig の shell を安全に解析する完成コードではない。`config.status` 等の実出力フィールドは選定 Runtime の configure 実装から確認する。

### acceptance assertions

Debug QA では native compile environment、Debug 有効、tests 有効、PGO disabled、PGO generate/use disabled を確認する。テスト helper の実ファイル、architecture、BuildID、依存ライブラリ、対応 test archives を確認する。compile 成功だけで suite status を PASS にしない。

PGO/production-opt では変更前後の effective tests setting と profiling/LTO/最適化設定が不必要に変わっていないことを比較する。PGO generate は profile 取得用であり製品 artifact として QA/公開しない。fresh source で Debug flag を有効化しただけの古い binary は拒否する。

### Debug の test artifacts

同じ build で生成した binary と test-support を別 artifact に保持する。support の header は source/build/target/toolchain/mozconfig/harness/producer に紐づける。macOS は arch ごとの helper/test-support を universal app と混同しない。cross compile worker では generate だけ行い、実行は対応 native OS/arch へ渡す。

既存 `build-and-package.sh` が browser package を移動する時点より前後どちらで test archives を作るべきか、実ターゲットの依存を確認する。native build を同じ run で二度作り直す設計にはしない。packaged support に必要な `_tests`/生成環境の欠落をチェックする。

### Debug/製品間の差

Debug branding、debug patches、flat chrome、sandbox override、crashreporter capability を記録する。差分を全て「DEBUGだから」で許可せず、影響する suite と比較可能な契約を明示する。特に macOS の sandbox 設定を製品 QA へ継承しない。[R2]

PGO 固有の miscompile/最適化差は Debug L1 で網羅できない。製品 L2、既存 native probes、変更リスクに応じた別 opt/sanitizer campaign を補助とする。製品 performance の比較は同条件の製品 build 同士で行い、Debug の速度から合否閾値を作らない。[M5][M6]

### 本番 Package のフラグ

`--disable-tests --enable-artifact-builds` は初期導入で維持する。[F2] Floorp の test harness は外部から接続し、本番 assets / omni.ja / signatures は不変。旧 colocated tests が dev globals を要求する場合は packaged adapter を作るか、未移行ケースとして明示する。tests フラグを変えて自動的に全 colocated test が動くとは仮定しない。


---

<a id="doc-02"></a>

## 02. ３層 QA 詳細設計 — Debug / 製品 Package 分離

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

### 1. 目標と責務

Desktop の主要操作、設定の組み合わせ、保存・復元、更新、OS 統合について、どのソース・成果物・環境・仕様を検査したかを追跡する。テスト完了・成功・期待された除外・未対応・未実行を分離する。

| 層 | 主な実行場所 | テスト対象 | 結果の主張 |
|---|---|---|---|
| L1: Upstream regression | Debug Runtime QA | tests-enabled native Debug build | 指定 Runtime source/config での Firefox 由来の契約 |
| L2: Floorp deterministic | 共通 source QA + 製品 package QA | Floorp tooling / 実際の製品 artifact | Floorp の仕様と統合後の動作 |
| L3: Agent exploration | Nightly/信頼済み候補の隔離 worker | 原則 packaged product、診断用 Debug は別 Subject | 未知の finding、再現列、固定テスト候補 |

L2 の source QA はブラウザーを必要としない検査だけを１回集約する。browser-integrated / native の部分は各対応対象で実行する。L1 の既存 compat subset は開発 CI に残してよいが、標準ハーネスと coverage を混同しない。

### 2. 共通制御

Planner が policy と対象を固定し、worker がテストを実行し、collector が証拠を保存し、trusted evaluator が予定と実行を照合する。実行器まで全て統一せず、Mozilla runner、Floorp colocated runner、Python native probe を薄い adapter で接続する。

```text
Debug Runtime build -> Debug test support -> Mozilla suites -> Runtime qualification
                                                                  |
Floorp source QA -> Product package -> Native verification -> Product L2
                                                                  |
                                              authenticated QA sidecar
                                                                  |
                                             manual approval + public gate

Product candidate -> Agent exploration -> captured finding -> fixed replay -> reviewed L1/L2
```

上図は採用する責務の図で、現行 workflow がすでに全経路を持つという表示ではない。正確なジョブ依存は 11、証拠の結び付けは 12 に定義する。

### 3. L1 — Debug Runtime で上流資産を実行

#### ビルドと実行の分離

標準 profile は `debug=true, pgo=false, tests=enabled`。tests flag を最終 generated mozconfig で正規化し、configure 後の出力で確認する。PGO generate/use の既存フラグを変えない。test-support は同じ Debug build から生成し、必要な helper binary、test extensions、manifest、head/support files、generated assets、prefs、toolchain、symbols/capability を対応づける。

`mach package` のみでは test archives の完備を仮定しない。対象 revision の package-tests ターゲットや実ハーネスが必要とする生成手順を確認し、実在と native 実行まで受け入れる。`MOZ_ARTIFACT_FILE` は sibling test artifacts を自動供給しない。[M1]

#### スイートの優先度

最初は Linux x64 の browser-chrome と xpcshell の代表群。次に macOS/Windows/Linux ARM へ native worker を拡張する。WPT、reftest/crashtest、gtest/低レベルテストは、必要な build capability と影響領域に応じて追加する。[M2–M4]

元の assertion、manifest 条件、SpecialPowers、ContentTask、head/support の意味を維持する。shim の no-op や未対応 API の黙示的 PASS は禁止。正規表現 triage は候補分類であって意味論の同等性証明ではない。

#### 素の Runtime と overlay 統合を区別

Runtime 内部テストは Floorp overlay のない素の Debug Runtime で実行してよい。それを `runtime-only` と明記する。Floorp と上流 UI の相互作用を調べる suite は Debug と対応したテスト用 overlay で `overlay-loaded` sentinel を要求し、別 job / evidence kind とする。

**素の Runtime L1 を始めるために Floorp overlay adapter の完成を待たない。** 逆に素の Runtime の成功を Floorp 統合検証と表示しない。overlay build は Debug 試験対象に合わせ、Debug と release の binary/resources を混ぜない。

#### 台帳と適格性

全 manifest を `discovered / eligible / upstream-disabled / approved-product-difference / harness-unsupported / quarantined / not-onboarded` で管理する。実行予定 ID は対応ハーネスの resolver から取得する。manifest/fixture lifetime を壊す分割はしない。

Debug L1 の成功から `RuntimeQualification` を作り、製品 build の upstream source と native patch 系列にリンクする。Debug と製品の BuildID/digest は異なる。qualification は製品バイナリの検査を代替しない。仕様と適用条件は 12。

### 4. L2 — ソース検査を集約し、製品を target ごとに検証

#### Source QA

型/静的検査、Deno host tests、docs/tooling、QA 自身の unit tests 等の platform-independent subset を１共通 job に集約する。採用対象はテスト台帳で固定し、ブラウザーを起動するテストや OS 固有 helper テストは除いて別 job に配置する。既存 command の名称からブラウザー非依存と推測せず、内部呼び出しも確認する。

最初は同一 package run で１回。cross-run reuse は source SHA、dependency locks、policy、suite IDs、Deno/Node/Python、runner image 等の同一性と trusted producer を確認できた場合だけ導入する。単なる cache hit や main の緑チェックで代用しない。

#### Packaged Floorp tests

既存の順序で build/inject/package し、署名・公証がある OS はそれらを終えた最終 artifact を対象にする。本番 packaging の `--disable-tests` は維持できる。L2 の test driver/bundle は配布物外にあり、製品ローダーを使用した本体を操作する。

Floorp colocated tests は `origin=floorp` と `executionKind` を台帳に付け、packaged-compatible なケースを受け入れながら移す。`origin=mozilla-imported` は通常の製品 package suite から除外する。ただし parser/wrapper 自体を試す host test は Floorp tooling なので残す。未分類 origin はスキップせず計画エラーにする。

現在の `deno task test` をそのまま最終 artifact の証拠としない。新しい packaged runner が必要なケースを明記する。runner が `_dist/bin` の別 Runtime を起動したら拒否し、HTTP dev loader/HMR の利用も拒否する。[F1][F11]

#### Fixture / action / oracle

起動時の prefs による fixture 設定と、検証対象の UI 操作を区別する。E2E の状態変更は UI 相当入力で行う。内部 read は fixed observer、期待値は承認済み仕様から独立に定義する。本体の getter/serializer をそのまま正解にしない。

| 領域 | 初期の必須 postcondition |
|---|---|
| 起動/終了 | fresh/synthetic-existing profile、製品 loader、owned PID、終了と次回起動 |
| tabs/workspaces | 操作後のタブ集合・選択・所属が仕様どおり。保存・再起動で保持 |
| Web Panel | server で見た HTTP UA、切替/reload/navigation、通常 tab への非漏出 |
| context menu/Flasco | Fluent 欠損キーで停止しない。参加/離脱/失効で controller と保存レイアウトが正しく扱われる |
| native GUI/PWA | OS 右クリック、表示/dismiss/再表示、フォーカスと window lifecycle |
| Split View | 作成/解除/片側 close/別 workspace との組合せ |
| update/migration | 元版→先版の実 updater と synthetic profile 保持。profile を開くだけの検査は別 |
| privacy | 対象 store ごとの private/container lifetime。OS 全体の痕跡ゼロとは主張しない |

global pins、複数 window の workspace、private scope は仕様未決のまま invariant にしない。native MouseEvent と OS 入力を区別する。条件待ちは operation 前に登録し、timeout と未達状態を残す。固定 sleep だけに依存しない。

### 5. L3 — 探索、再現、固定テスト化

既定対象は L2 と同じ packaged product。Debug 上の診断探索は別 Subject とし、PGO での再現結果を別途保存する。特定の LLM/provider は必須にしない。Agent は source/feature contracts/観測状態を読み、許可済み action を提案する。

API は登録済み click/key/type/navigation/wait/observe/restart のみに段階拡張する。任意 shell、privileged eval、外部 URL、任意 selector は公開しない。固定 observer が内部状態を読み、既知の invariant はコードで判定する。未知の視覚的問題は review finding に留める。

`finding -> raw evidence -> fixed replay -> reduction -> bad/fixed test -> human review -> L1/L2`。同じ artifact、fixture、操作列、oracle、環境を保持する。縮約は fresh fixture と同じ failure signature を要求し、低再現率なら元の証拠も残す。Agent が製品と oracle を同時に書き換えて自己承認しない。

操作数、実時間、token/API、再起動、保存容量の budget を固定する。pilot の実装範囲は counter fixture と限定 click/observe/navigation、JSONL と replay であり、LLM adapter/全機能探索/縮約は未実装。モデル障害と budget 終了は製品 PASS ではない。

### 6. 共通の判定規則

FAIL、CRASH、TIMEOUT、missing shard、空計画、未対応、証拠改変、wrong artifact、未承認 SKIP、初回失敗後の retry PASS は clean PASS にしない。SKIP は policy と一致しても成功件数に加えない。test enabled / archive generated / discovered / executed / passed を別々に記録する。

予期した crash recovery の故障注入と unexpected crash を test ID と終了理由で区別する。ハーネス内がハングしても supervisor は外部から timeout と cleanup を管理する。minidump が無い場合も process exit/OS log/last heartbeat 等を残し、未取得能力を隠さない。

現行 CLI の `gate` は per-target のローカル判定で、常に `publicationAuthorized:false`。全体 release verifier の実装は 11/12 の作業。Debug/Source/Package の結果をすべて同じ Subject の `results.json` に押し込まない。

### 7. 段階導入

Debug の tests 有効化と最小 L1、source QA 集約を先に進める。既存 product probes の取り込みと全 Floorp tests の packaged 移行を並行して増やし、native target を揃えて正式公開 gate に接続する。最後に探索を拡大する。各段階の実装状態・未検証・対象外は台帳に残す。


---

<a id="doc-11"></a>

## 11. CI・公開ゲートの依存関係

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

### 1. 方針

Runtime の L1 は Debug build に集約する。PGO/production-opt は既存 build と native verification を維持する。Floorp の package orchestration は source QA を１共通ジョブに集約し、その後４ package / ５ native QA を行う。

**ジョブ名は以下すべて新設提案。接続済み workflow ではない。** `qa/design/ci-graph.json` は依存関係の静的検査用であり、GitHub Actions YAML として投入しない。図は UML-like の依存フロー。テキスト/依存表も添え、画像閲覧に依存しない。

### 2. Runtime Debug QA

| job | needs | 責務 |
|---|---|---|
| `resolve-debug-qa` | なし | source/pin/patch/DEBUG/PGO/test plan を固定 |
| `build-debug-runtime` | resolve | native tests enabled build と対応 test assets を生成 |
| `run-debug-upstream` | build | 各 native worker の選定 L1、raw log、planned ID 照合 |
| `qualify-debug-runtime` | run | RuntimeQualification sidecar。PGO製品のPASSではない |

最初は Linux x64。残る target は未導入であることを明示し、ready と見せない。Debug daily-build が production build-manifest を生成しない条件でも、Debug専用 sidecar によって producer/build/test を識別する。製品 manifest を流用/偽造しない。[R1]

### 3. 製品 Runtime

PGO generate → profileserver workload → profile-use → native verification の既存構成を維持する。[R1–R3][M5] 非 PGO opt target も製品として扱う。Debug suite と PGO の間にはバイナリ共有ではなく、source qualification の参照がある。

Runtime 更新候補では、対応する Debug L1 がない場合に qualified としない。通常 Floorp-only release は source/patch/条件が適合する既存 qualification を参照してよく、毎回 Debug Runtime を再ビルドしない。真正性、適用範囲、失効は 12 の条件を満たす。

### 4. Floorp の目標 DAG

```text
source-qa-once --------------------------+
                                       v
resolve-product-runtime -----------> package-[4 targets]
                                       |
                          final signed/notarized outputs
                                       v
                            native-verify-[5 targets]
                                       |
                                       v
                         assemble exact existing v2 bundle
                              /                    \
                   draft staging             package-qa-[5 targets]
                              \                    /
Debug RuntimeQualification ---> aggregate authenticated QA sidecar
source-qa evidence ------------>          |
                                            v
                                 protected manual approval
                                            |
                                 revalidate QA + exact bundle
                                            |
                                public release / distribution
```

`package-qa` は assembled bundle の exact outputs を読み、各 artifact/target で１度だけ決定的 suite を実行する。現行 release-bundle-v2 の closed schema を変更せず、QA sidecar を別 artifact にする。draft は公開前の staging に限定し、公開版と区別する。

この版では「QA のために bundle が必要なのに、bundle が QA 成功を待つ」という循環を避けるため、**assemble→QA sidecar→public gate** を標準とする。既存 native verification は assemble の前提として残す。署名・公証を package から全面分離する改造は不要。

### 5. source job の配置

source-qa-once は同一 Floorp checkout/lock/policy で実行し、OS別 package jobs の needs とする。host subset を固定し、以下の既存 command は適用候補として既存呼び出しを確認する。[F11]

```bash
deno task test:smoke
deno task test:host
deno task test:firefox-tests
deno task test:docs-pipeline
python3 -m unittest discover -s tools/qa/tests -v
```

`test:firefox-tests` はこの指定では収集/互換ツールの host tests であり、Mozilla の上流 suite を再実行する指示ではない。`deno task test` と `test:integration` はブラウザーを起動するためこの一覧に入れない。source-only と称した job 内で別 Runtime をダウンロード/起動しないことを監査する。

### 6. packaged runner の新しい契約

入力は exact package ID/digest/member digest、authenticated native record、Floorp SHA、test bundle SHA、policy、suite、target。出力は actual binary/profile/process identity、loader/sandbox observation、各 case/attempt と raw evidence。

`--browser` の指定を無視して既存 `_dist/bin` を起動する fallback を禁止。production bootstrap を使用し、外部 test bundle は製品コードを再ビルドしない。tests の origin と executionKind を固定する。Floorp固有 suite の全量 discovery と実行予定の差を公開する。

runtime outside の host/native wrapper tests と Mozilla-engine tests は区別する。既存 native verification まで削ることを「Runtime 外だけ」の意味にしない。

### 7. #2886 からの移行

**Shadow 段階:** 現行 `pre_publication` の read-only workflow を維持し、共通 evidence を追加。今ある手動承認前後のチェックは残す。source/PGO/最終QAが未接続なら未導入として表示する。[F6][F7]

**Required 段階:** 新しい pipeline では QA が approval より前に位置する。既存 helper の「既に pending deployment がある」条件をそのまま呼ぶと成立しないため、独立の `pre-approval` intake を設ける。canonical source run、各先行 package/native/assemble job と exact artifactを検証し、親 run 全体の completed/success を要求しない。

required mode で追加 QA を `continue-on-error` にしない。publisher は approval 後、public mutation の直前に QA producer/status/policy/source/run/attempt/target/sidecar/bundle を再検証する。manual approval は残し、QA の成功だけで承認しない。mutableな「latest PASS」検索ではなく指定 artifact ID を渡す。

### 8. 頻度・選定

| trigger | Debug L1 | source | packaged L2 | Agent |
|---|---|---|---|---|
| Floorp PR | 通常は既存開発CIと影響選定 | 変更入力で実行 | high-risk候補/信頼済みartifact | 任意 |
| Debug schedule | 選定suite + 計画的広域shard | 必要時のみ | Debug overlay診断は別 | 診断のみ別Subject |
| Runtime candidate | 対応sourceのqualification必須化を段階導入 | Floorp candidateで１共通job | 全target重要subset | 任意重点探索 |
| Floorp product package | 適合する既存qualification参照 | run内１回 | 各final artifact/targetで１初回評価 | 別advisory |
| Nightly exploration | 必要に応じ台帳拡張 | 既存証拠を厳格再利用 | 高リスク組合せ/長期遷移 | budget付き |

### 9. 失敗とキャンセル

planned shard の未開始/未完了、timeout、artifact未取得、capability不足は gate を止める。source failure は新規 packageを開始しない。必須 L1 qualification欠落は opt Runtime のbuildを止める必要はないが、required phaseで新Runtimeのpromotion/publicationを止める。

retry/rehydrationは別attemptを記録。失敗したsuiteだけの再実行で過去失敗が消えた成功記録を作らない。緊急時waiverはowner、理由、期間、対象evidence、代替検証を別承認し、identity/署名/provenance不一致にはwaiverを許可しない。


---

<a id="doc-12"></a>

## 12. 証拠・再利用・Debug と製品のリンク契約

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

### 1. Subject の分離

| モデル | 同一性の主要入力 | この版の実装状態 |
|---|---|---|
| `DebugRuntimeSubject` | repo head、compiled upstream/patch、debug-only patch、effective config、toolchain、target、BuildID、binary/test-supportのdigest、build producer | 設計済み、producer/validator は未実装 |
| `SourceQASubject` | Floorp SHA、locks、suite/policy/fixture、toolchain、runner、generator入力 | 設計済み、CI producer は未実装 |
| `ProductSubject` | exact package/native record/source run/target/version/BuildID/署名状態 | 既存 `Subject v1` の adapter を維持 |
| `RuntimeQualification` | DebugRuntimeSubject ID、L1 plan/result、適用するsource/patch/target/環境制約、producer、失効条件 | 設計済み、正式認証は未実装 |
| `ReleaseQASidecar` | source証拠、適用資格、全製品target結果、exact bundle、trusted policy/producer、finding判断 | 設計済み、publisher verifier は未実装 |

既存 v1 ProductSubject と v2 native/release record の schema は無断に拡張しない。新モデルは別version/schemaとして実装する。機械可読設計 JSON は実 evidence そのものではない。

### 2. Runtime qualification の適用

DebugとPGO/optのバイナリdigestとBuildIDは違ってよい。一致を要求するのは「同じartifact」ではなく、対象の試験契約に関わる compiled upstream revision とproduction適用native patch集合、および承認済みの比較条件である。

| 項目 | 取り扱い |
|---|---|
| compiled upstream commit | 完全一致。表示versionだけでは不可 |
| productionに適用するnative patch identity | 同じ内容と順序/最終tree identity。unknown差分は拒否 |
| Runtime orchestration head | 両方記録。差分のcompiled-source非影響が認証できなければ資格を再取得 |
| Debug-only patch/config | 差分と影響suiteをレビュー。無条件に除外しない |
| target/arch | 同一を原則。別archのPASSで代用しない |
| compiler/SDK/runtime依存 | 差分を保持。許容ポリシー未定なら再検証 |
| BuildID/binary/test-support | Debug内部では厳格に結合。製品とは異なるIDのまま |
| sandbox/loader | 実プロセスの設定を保持。Debugの緩和環境で製品privacy/通常起動を適格化しない |
| Floorp overlay | Runtime-only資格には含めない。overlay試験はFloorp/testbundle/prefsもキーに含める |

source qualification は「このソース系列のDebug条件でL1が成功した」証拠であり、PGO実行経路の証明ではない。製品L2と既存native verificationは常に別に必要。

### 3. 資格の取得・失効

Runtime変更ではqualificationを更新する。Floorp-only変更はRuntime-only資格を再利用できるが、browser UI/actors/prefs/bootstrap/native patchesに触るとoverlay関連資格と製品suiteの影響を再評価する。

qualified subset、policy、harness、fixture、対象OSの互換条件が変わった場合は再取得/明示レビュー。新しい重大finding、revoked build、artifact取り違え、期限超過でも失効する。expiryは環境/運用policyで明記し、未測定の一律時間を既存仕様として創作しない。

署名/issuerだけで試験が十分であるとみなさず、expected manifests/test IDsと完了、rawログ、canary、実artifactを照合する。read-only APIで得たproducer情報と自己申告JSONを区別する。

### 4. 「１回」再利用キー

Source QA のキーは `H(FloorpSHA, lock digests, source suite+policy, fixture/generator inputs, toolchain, runner image)`。ブラウザー依存を含めるならRuntime identityも必要になるため、初期source jobには含めない。

Packaged QA のキーは `H(ProductSubject, final package/member digest, native target, suite+policy+test-bundle, fixture, runner/display, sandbox/automation mode)`。同じcommitから再packしてdigestが変われば再検証する。mac universalはtargetが違うため別キー。

再利用できるのはverified producerの完全な初回評価と履歴を持つ証拠だけ。cache、job名、branch名、PRの緑表示だけでは不可。別run/attemptの再利用は明示的evidence edgeで関連づけ、現在runで実行したように書かない。

### 5. Release sidecar

入力: exact bundle ID/digest/source run/attempt、FloorpSHA、Runtime production manifest/各artifact、qualified Debug references、SourceQA reference、各target ProductResult reference、policy/trusted tool revision、finding/waiver判断。

public verifier はschema、producer、signature/attestationを採用する場合そのissuer、expected subject、target集合、初回/再試行履歴、全必須case、digest、失効/waiverを検査する。必須検証が足りない場合は BLOCK。

既存 manual approval を通過しても最後に同じ sidecar と bundle を再検証する。QA中に署名し直した、archiveを置換した、再buildした、別attemptの結果を混ぜた場合は新artifactとして扱う。自動approval、公開トークンを持つAgent、任意callerのPASS JSONの信頼は禁止。

### 6. 状態モデル

`NOT_PLANNED / NOT_ONBOARDED / BUILT / DISCOVERED / RUNNING / PASS / FAIL / CRASH / TIMEOUT / SKIP_APPROVED / INCOMPLETE / ENVIRONMENT_ERROR` を意味上区別する。既存CLIの列挙値に直ちに追加するのではなく、新adapterのスキーマで対応する。型名の似たstatusを無検査で変換しない。

source scope PASS、Debug scope PASS、product target scope PASS、release authorizationは別判定。現行 `gate` の `publicationAuthorized:false` を変更しない。JSONL/画像/プロファイル差分/minidumpに秘密情報を含めず、必要最小限のsynthetic dataと保持期間を使う。

### 7. 最小負例

Debugの結果を製品Subjectとして渡す、PGOに古いDebug資格を貼る、Linux x64のPASSをLinux ARMへ貼る、Test supportとDebug buildのBuildID不一致、dev-loader起動、unsigned→production誤用、source lock差分、欠落case、FAIL後のPASSのみ提出、公開直前のbundle差替えをすべて拒否する。

### 8. Linux と署名モードの用語

既存recordの`unsigned:false`は本番pipeline側のartifactモードを表す。Linuxのtar.xz自体がWindows/macOSと同じコード署名証明書を持つという意味ではない。`signedOnly`という既存CLI名は互換上維持するが、production各targetに必要な真正性・署名/公証要件はそのOSの既存validatorで検証する。


---

<a id="doc-03"></a>

## 03. 導入・実行 Runbook — 新方針

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

### 0. この版の実行範囲

最初に00/10/11/12を読む。本書のCLIは限定的な既存実装を動かす手順であり、DebugのCI変更や全packaged runnerを自動導入するものではない。新しい順序はQA3-01/04から。実CIへの接続方法は11と作業票04を正とする。

```bash
# キットrootで設計契約を検査する。ビルドやCI起動はしない。
python3 tools/qa/design_contract.py
```

`release-readiness`は旧名互換の製品L2-only計画。新規には`--profile production-package-readiness`を使う。Debug L1は別producer/Subjectであり、製品planへ追加しない。全体release gateは未実装で、ローカルgateは公開許可を返さない。

### 1. 作業の前提

別 worktree／ブランチを使います。Python 3.12+ と Git が必要です。ブラウザー起動には credential-free の専用 GUI worker、ネイティブ権限、対象 architecture、既存 Floorp helper が必要です。`QA_DISPOSABLE_WORKER=1` は環境を隔離する機能ではなく、整備済み worker を明示する確認フラグです。

キット root と Floorp checkout root は別です。`install.py` の適用後は Floorp root から同じ CLI を呼べます。以下のプレースホルダーは実際のローカルパスに置き換えてください。

### 2. オフライン検証と追加

```bash
cd /path/to/Floorp_QA_Implementation_Kit_v0.3.0
python3 -m unittest discover -s tools/qa/tests -v
python3 install.py --repo /path/to/Floorp
python3 install.py --repo /path/to/Floorp --apply
cd /path/to/Floorp
python3 tools/qa/qa.py doctor --repo . --out /tmp/qa-source-audit.json
```

doctor が REVIEW_REQUIRED の場合、どの blob が変わったかを読む。自動で pin を更新しない。Git の CRLF checkout 差も drift に含むため、Windows では Git object と worktree の差をレビューする。diagnostic は coverage／build 成功の証拠ではない。

### 3. 既存 QA 接続のレビュー用 patch

```bash
python3 tools/qa/propose_integration.py --repo . --out /tmp/qa-advisory.patch
git apply --check /tmp/qa-advisory.patch
# 内容をレビューした後、明示的に実行する。
# git apply /tmp/qa-advisory.patch
```

生成差分は deno task の入口追加、既存２ probe のバージョン固定値の汎用化、final QA の subject/plan/collect/gate の追加です。実行ブラウザーと認証済み record の version 比較は残します。既存の `validateFinalPackageSource`、５ native gate、pre-publication の再確認、署名設定、公開承認は変更しません。

追加集計は `continue-on-error:true` の advisory ですが、**既存の実 probe の失敗は従来どおり失敗**です。advisory と書かれているのを理由に重大な finding を無視しません。公開必須化は別 work order です。

この作成環境では full checkout に対する実 `git apply --check` は実施していません。生成器は対象 blob が一致したときだけ差分を出すため、古いソースへ無検査で適用する危険を避けます。

### 4. 既存 final QA の途中に接続する

接続位置は **既存 workflow が GitHub run/artifact の認証と native record 抽出を終えた後**です。`package.zip` と `record.zip` は同 workflow がダウンロードして API digest を確認した ZIP をそのまま使います。

```bash
qa="$RUNNER_TEMP/final-package-qa"
python3 tools/qa/qa.py bind-final \
  --input "$qa/input.json" \
  --native-record "$qa/native-verification.json" \
  --package-zip "$RUNNER_TEMP/package.zip" \
  --record-zip "$RUNNER_TEMP/record.zip" \
  --out "$qa/qa-subject.json"

python3 tools/qa/qa.py plan \
  --subject "$qa/qa-subject.json" \
  --profile existing-final \
  --out "$qa/qa-plan.json"
```

`bind-final` に自作 JSON を渡しても producer の認証にはなりません。従来の source intake を省略する使い方は禁止です。subject は `sourceEligibility` と `probeHead` を読取コンテキストとして保存しますが、その前後の GitHub 再確認は既存 helper に任せます。

既存の UA／Fluent-Flasco／mac native probe を従来どおり実行後、次を追加します。

```bash
python3 tools/qa/qa.py collect-final \
  --plan "$qa/qa-plan.json" --subject "$qa/qa-subject.json" \
  --native-record "$qa/native-verification.json" \
  --qa-root "$qa" --evidence-root "$qa" \
  --out "$qa/qa-results.json"

python3 tools/qa/qa.py gate \
  --plan "$qa/qa-plan.json" --subject "$qa/qa-subject.json" \
  --results "$qa/qa-results.json" --evidence-root "$qa" \
  --out "$qa/qa-verdict.json"
```

既存と同じ `web-panel-ua/run-*/report.json`、`fluent-flasco/run-*/report.json` を読みます。各 case が複数見つかれば ambiguous として停止します。再実行のログを同じ directory に混ぜず、attempt ごとに別 evidence root を使ってください。collector の初期実装は attempt=1。将来の retry collector は元失敗を保存して attempt を連番化する必要があります。

レポート内容と対象、sandbox／loader、PID／終了状態を検査します。gate が PASS でも既存２ case の scoped PASS であり、全機能の公開判定にはなりません。

### 5. 既存 probe のローカル実行補助

承認済みの staging 手順で exact package から配置した browser と、認証済み native record を使います。任意 browser path が同じ version を返すだけでは archive との同一性の証明になりません。

```bash
export QA_DISPOSABLE_WORKER=1
python3 tools/qa/qa.py run-probe --repo . \
  --case l2.web-panel-http \
  --browser /isolated/staged/floorp \
  --native-record /isolated/evidence/native-verification.json \
  --floorp-version 12.20.1 \
  --timeout 600 --out /isolated/runs/ua-attempt-001
```

上の version は確認 baseline の例。通常は認証済み `input.json` の `floorpVersion` を使います。macOS は `.app` path。`run-probe` の process-result は終了コードの観測であり、これだけで QA 成功にしません。詳細結果は `out/raw/run-*/report.json` にあります。

既存 workflow の folder 配置と standalone runner の `raw/` 配置は異なります。standalone はファイルを移動せず、専用の `collect-probe` で process 終了と詳細 report を一緒に取り込みます。

```bash
python3 tools/qa/qa.py collect-probe \
  --plan /isolated/qa-plan.json --subject /isolated/qa-subject.json \
  --native-record /isolated/evidence/native-verification.json \
  --case l2.web-panel-http --run-dir /isolated/runs/ua-attempt-001 \
  --evidence-root /isolated --out /isolated/ua-results.json
```

複数 case の結果は gate の `--results` に複数ファイルを渡します。同じ case の同一 attempt を重複提出しません。

### 6. Debug L1 の台帳・資材・ログ検査

```bash
python3 tools/qa/qa.py inventory-runtime \
  --runtime-dir /path/to/Runtime-test-checkout \
  --out /isolated/inventory.json
```

inventory は条件未評価の台帳です。`eligibleCount:null` を 0 や総 test 件数と誤読しません。

`debug=true,pgo=false` の genuine native tests-enabled Debug build で作成した support archives を別 artifact にまとめる例：

```bash
python3 tools/qa/qa.py pack-test-bundle \
  --runtime-dir /path/to/Runtime-test-checkout \
  --runtime-sha "$VERIFIED_TEST_SOURCE_SHA" \
  --target linux/x86_64 --build-id "$VERIFIED_TEST_BUILD_ID" \
  --mozconfig /path/to/test.mozconfig \
  --application-ini /path/to/test-obj/dist/bin/application.ini \
  --materials /path/to/test-obj/dist \
  --file common.tests.zip --file mochitest.tests.zip \
  --out /isolated/runtime-test-support.zip
```

ファイル名は例であり、実 build の生成物を inventory して指定します。`--disable-tests` や `--enable-artifact-builds` を含む config は拒否します。別ファイルの source／条件分岐を含む effective config の完全検証は Runtime 側で実施してください。

Mozilla 本来の実行は、対応する test build／overlay／manifest が揃った worker で行います。公式に記載された browser-chrome と raw log の組み合わせ例：

```bash
# Runtime の対応する Debug native build checkout で実行する。配布 packaging の objdir ではない。
./mach mochitest -f browser --log-raw=/isolated/raw-mozlog.jsonl \
  path/to/reviewed/browser.toml
```

このコマンドを実行する前に、対象 manifest が現 checkout に存在し、必要な support を検証してください。Runtime-only L1にはoverlayは必須ではありません。overlay統合suiteとして実行する場合にだけ対応するFloorp bootstrap sentinelを要求します。ハーネスの終了コードを CI supervisor が保存し、同じハーネスが解決した exact ID の JSON 配列を次に渡します。

```bash
python3 /path/to/Floorp/tools/qa/qa.py check-mozlog \
  --raw /isolated/raw-mozlog.jsonl \
  --tests /isolated/resolved-test-ids.json \
  --exit-code "$HARNESS_EXIT_CODE" \
  --evidence-root /isolated \
  --out /isolated/mozlog-verdict.json
```

`--verify`／repeat の結果を単一 cycle として取り込まない。threshold 診断が出た場合は upstream の意味論を保持した adapter が必要です。このログ検査は runtime source authentication や overlay sentinel の代わりではありません。

### 7. Agent pilot と固定リプレイ

```bash
# ポリシー検査のみ。ブラウザーは起動しない。
python3 tools/qa/qa.py check-actions \
  --actions qa/scenarios/counter-actions.json --out /isolated/actions-checked.json

# Linux/macOS の専用 GUI worker。署名済み production subject が必要。
QA_DISPOSABLE_WORKER=1 python3 tools/qa/qa.py replay \
  --repo . --browser /isolated/staged/Floorp.app \
  --subject /isolated/qa-subject.json \
  --actions qa/scenarios/counter-actions.json \
  --max-actions 50 --seconds 300 --out /isolated/replay-001

# 保存した同じ subject の操作列を再生する。
QA_DISPOSABLE_WORKER=1 python3 tools/qa/qa.py replay \
  --repo . --browser /isolated/staged/Floorp.app \
  --subject /isolated/qa-subject.json \
  --actions /isolated/replay-001/replay.json \
  --out /isolated/replay-002
```

Linux では browser を実行ファイルに置き換えます。新しい profile は各 campaign で自動作成されます。native input、全子プロセス crash、全 feature の oracle は未導入です。

`agent-stdio` は同じ起動引数で `--actions` を省いた双方向 JSON-lines インターフェースです。最初に observation と allowedTargets を stdout に出し、stdin の１ action に対して outcome と observation を返します。LLM adapter は親プロセス／別サービスとして接続します。

```json
{"kind":"navigate","fixture":"counter"}
```

モデルに任意 shell を渡す必要はありません。新しい target は trusted registry に追加してテストします。fixture／DOM から自由に selector や script を採用しません。`input-ended`／`budget-exhausted`／`replay-complete` は探索・再生の状態で、製品品質の PASS ではありません。

### 8. 終了コードと診断

| code | 意味 |
|---|---|
| 0 | コマンドの目的を完了。scope／status を必ず読む |
| 1 | gate BLOCK、観測 FAIL、または完了不足等 |
| 2 | 入力契約不一致、環境エラー、ソース drift 等 |

ERROR は PASS ではありません。成果物 ZIP／record／report の不一致で止まった場合、validation の条件を削って通すのではなく、元 run と exact artifact を再確認します。timeout 後はブラウザー名で一括 kill せず、所有 worker を破棄します。

### 9. 新しいCIの実装順序

Debugのflag有効化→test assets→Runtime-only L1を一系統、source job集約→既存final probes→全Floorp testsのpackaged移行をもう一系統として実装する。PGO generate/useは既存どおり、製品packageの--disable-testsも維持する。L1のqualificationと製品結果を結ぶ正式gateはQA3-08/09で追加する。

現在のCLIのpack-test-bundleはarchive結合補助であり、実ハーネスが使えるarchiveをビルドするコマンドではない。実configure/build、native tests、Deno、Actions、モデルAPIの実行結果は作業環境で別途報告する。


---

<a id="doc-04"></a>

## 04. 実装作業票 — 新方針への置換

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

### 運用

ID を `QA3-*` に改め、旧 QA-01～10 をそのまま別内容で使い回さない。担当者は未割当。設計の採用はユーザー確認済みだが、各 feature の期待値と CI 必須化の承認は別。実装・実機検証・公開設定変更の権限も別とする。

| ID | 主担当 repository / 範囲 | 依存 | 完了成果物 |
|---|---|---|---|
| QA3-01 | Runtime / profile resolver・setup | なし | Debug非PGOだけtests enabled、PGO不変の負例付き |
| QA3-02 | Runtime / test-support生成・保存 | 01 | 同じDebug buildの別artifactとprovenance |
| QA3-03 | Runtime / L1 native worker | 02 | Linux x64の標準ハーネス実証とqualified subset |
| QA3-04 | Floorp / 共通source QA | なし | package前の１共通jobとテストorigin台帳 |
| QA3-05 | Floorp / 既存final probes・共通CLI | 04 | 現行３targetのadvisory取り込み |
| QA3-06 | Floorp / packaged colocated runner | 05 | 最終製品に対するFloorp固有suite |
| QA3-07 | 両repo / native target拡張 | 03,06 | Debug L1と製品L2の５target対応 |
| QA3-08 | 両repo / qualification・再利用 | 03,04 | Debug→製品source適格性の別Subject接続 |
| QA3-09 | Floorp / release sidecar・publisher | 05,06,07,08 | required公開gate・手動承認維持 |
| QA3-10 | Floorp / L3 model adapter・探索 | 06 | 限定探索→固定再現→回帰候補 |
| QA3-11 | 両repo / 広域選定・運用 | 07,08 | manifest被覆、コスト測定、復旧手順 |

### QA3-01: Debug tests フラグ

対象: Runtime `daily-build.yml`、wrappers、`common-build.yml`、`setup-floorp.sh`、mozconfigs。最初はprofile mappingと最終generated configの変更だけに限定する。標準Debug QA入力は`debug=true,pgo=false`。legacy debug+PGOはcanonical QAから除外するが、既存実験workflowの廃止は別判断。

受け入れ: 実configureでDebug/tests/native buildが有効、PGOが無効。５targetの設定生成を検査し、PGO generate/useとproduction-optの既存tests/profiling設定が不変。source templateにenable/disableが両方残る、unknownフラグ、PGO mode不整合を検出する。macOS compile可否は実buildで確認し、未実施ならそのまま記録する。

禁止: 本番packageの`--disable-tests`を同時に削除しない。sandboxを本番へ緩和しない。フラグを変えただけで「上流テスト成功」と報告しない。

### QA3-02: Debug test-support

対象: Runtime `build-and-package.sh`、build leaf、artifact outputs/sidecar。実revisionが持つMozillaテスト生成・パッケージ手順を確認し、native buildを１度だけ行ってその結果からsupportを生成する。arch別helperとtest extensionsを含む必要ファイルをinventoryする。

受け入れ: BuildID/source/config/targetがDebug binaryと一致。supportを誤った版と交換すると拒否。primary Runtime artifactの要素・既存manifest契約は変わらない。Debug成果物の認証はproduction-only manifestに依存しない。空archive、不可視helper、architecture違いを検出する。

### QA3-03: Runtime-only L1 と overlay の分離

最初はLinux x64のRuntime-only browser-chrome/xpcshell代表manifest。元のhead/support/IPC依存を含む実在パスを採用し、意図的FAIL canary、exact resolved IDs、raw log、exit codeを検証する。テスト有効化、discovery、実行、成功を別fieldにする。

受け入れ: 空discovery、startのみ、終了欠落、unexpected crash、未対応ログをPASSにしない。DebugRuntimeSubjectとRuntimeQualificationのスコープが明確。overlay統合は後続サブタスクにし、必要なsuiteにのみFloorp bootstrap sentinelを要求する。素のRuntimeでの成功をoverlay成功にしない。

### QA3-04: 共通 source QA

対象: Floorp `deno.json`、release orchestrator、既存smoke/host/tooling tests、新CLI selftest。候補suiteをsource-only、browser-integrated、OS-native、mozilla-importedで分類する。Host側のFirefoxテスト収集ツール自体の検査はsource QAに残せる。

受け入れ: package run内に１共通job、４package jobsが成功をneedsで要求。source jobでブラウザーを起動しない。empty/reduced/unknown-origin suiteを拒否。code/lock/toolchain/policyの差で同じ結果を使い回さない。初期は別run間dedupなし。

禁止: `deno task test`や`test:integration`をhost jobとして一括実行して「PGO製品を検査済み」としない。

### QA3-05: 既存 package probes と集計

対象: UA/Fluent・Flasco/既存native helper、`validate-final-package-qa.yml`。旧CLIのbind/plan/collect/gateを使用し、versionの固定文字列を認証済みmetadataへ汎用化する。差分生成器はadvisory用であり、この作業だけで公開gate完成とはしない。

受け入れ: Linux x64/mac Intel/mac ARMの許可済みfinal artifactsで実行。別artifact/record、sandbox無効、dev loader、wrong PID/cleanupを拒否。mac native probeも従来どおり実行。`existing-final`は２probeのsubsetと表示する。

### QA3-06: Floorp tests を packaged candidate で実行

対象: colocated runner/adapters、test bundle、feature contracts。production artifactを再build/改変せず、テストコードのみを外部から供給する。browser testsのoriginを明示し、通常package suiteにMozilla L1を混ぜない。

受け入れ: 既存Floorp testsのinventoryと移行表を提出。test runnerがexact browserを起動し、Floorp head/buildID2/native BuildID/loaderを照合。dev固有ケースを未移行と可視化。パス不明時に別binaryへfallbackしない。タブ/ワークスペース/再起動の固定caseと故障注入を含む。内部関数直呼びのケースはintegrationと表示する。

### QA3-07: 全５ target

Windows backend、Linux ARM、macOS arch別worker、OS input/display permissionsとprocess cleanupを整備。Debug L1と製品L2は異なるbinary/configで検証する。

受け入れ: native targetの実行証拠、owned PID/開始時刻/executable/profile、timeoutと子process、default launch、native右クリック。cross compileをnative実行に数えない。macOS Debugのsandbox overrideをprod workerへ継承しない。未対応targetを計画から黙って削らない。

### QA3-08: qualification と再利用

12 の別Subjectと適用条件を実装。Runtime-only qualificationをFloorp-only releaseで再利用可能にする。ただしsource/patch/toolchain/target/policy/失効を認証する。Debugと製品のBuildID一致を強制しない。

受け入れ: 同じsourceの適合例、異なるpatch/target/期限/producerの拒否例、debug-only差分未レビューの拒否例。L1が落ちてもPGO buildそのものを必要以上に再実行しないが、required phaseのpromotionを止める。source QAのcross-run再利用は別の厳格キーで評価する。

### QA3-09: 正式公開 gate

assemble→QA sidecar→manual approval→public verifier の非循環経路を構築。新pre-approval intakeは既存pending-deployment用helperと区別し、canonical source/artifact認証は維持する。closed v2 bundleは無変更で参照する。

受け入れ: 全target/result/qualification/sourceの欠落、旧attempt、wrong digest、unsigned、trustのないPASS JSON、期限切れ、QA後の差替えでpublic mutationが発生しない。manual approvalを省略できない。publisherのpolicyは候補PRから勝手に縮小できない。validation-onlyはproduction承認を得ない。

### QA3-10: L3

最初は１featureのregistered actionsと独立oracleを追加。model/controllerとbrowser workerを分離。known-bad/fixedで発見・fixed replay・回帰候補を評価する。操作数/時間/token/ディスクの上限を守る。

受け入れ: model障害を製品PASSにしない。権限逸脱拒否、固定replay、同じsignatureを維持した縮約。PGO問題をDebugだけの再現でfixed扱いしない。自動merge/quarantine/expectation変更/公開承認は禁止。

### QA3-11: 継続運用

eligible manifestの広域shard、変更影響選定、pairwiseと高リスク明示組合せ、quarantine owner/Issue/期限、retention、事故再現訓練を整備する。walltime/CPU/RAM/GUI占有/推論費用の実測で調整し、未測定の全量完走時間を約束しない。

着手順: **QA3-01 と QA3-04 → QA3-02/03 と QA3-05/06 → QA3-07/08 → QA3-09 → QA3-10/11**。独立作業は並行可能だが、受け入れ完了前にrequired化しない。


---

<a id="doc-05"></a>

## 05. 受け入れ基準・導入状態

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

### 状態の読み方

設計済み、コードあり、synthetic unit test成功、native実行成功、required CI導入、public gate enforcementは別状態。以下の「未実施」は実機実行/CI接続の未実施を指す。書類の完成と運用の完成を混同しない。

| 能力 | 設計/納品コード | 実機/CI受け入れ |
|---|---|---|
| Debug非PGOだけtests有効化 | 設計契約・負例検査 | Runtime変更/実configure未実施 |
| Debug test-support生成 | 旧`pack-test-bundle`補助、producerは設計 | native build/実archive未実施 |
| Debug L1 / qualification | mozlog単一cycle checker、identity仕様 | suite/資格認証未実装 |
| source jobを１回集約 | 命令/needs/再利用仕様 | Deno/Actions接続未実施 |
| 既存UA/Fluent-Flasco | 旧adapter/CLI/取り込み | 本作成環境の実browser未実施 |
| 全Floorp testsのpackaged化 | origin・runner仕様 | 移行実装/全case未実施 |
| ５target native L2 | matrixと負例仕様 | Windows等の追加backend未実装 |
| L3 | 制限付きpilotとreplay | LLM/全feature/縮約未実装 |
| publisher gate | sidecar/DAG/失敗条件の設計 | public enforcement未実装 |

### Profile × target

全製品target集合は windows/x86_64、linux/x86_64、linuxAarch64/aarch64、mac/x86_64、mac/aarch64。Debug側の同等native集合を段階整備する。Linux ARM非PGOを製品matrixから除外しない。mac universalは２実行target。

| case ID | 受け入れ操作/条件 | 失敗の検出 |
|---|---|---|
| A01 | Debug非PGOを生成してeffective tests=true | templateだけ変更、実config falseを拒否 |
| A02 | production-PGO generate/useを同じ入力で比較 | tests/PGO/LTO設定の意図しない変化を検出 |
| A03 | legacy Debug+PGO入力 | canonical Debug QAへ誤分類しない |
| A04 | Debug buildとsupportを結合 | 異なるBuildID/arch/sourceを拒否 |
| A05 | supportが別artifact | primaryへの余計な追加は既存validatorで拒否 |
| A06 | Runtime-only標準ハーネス実行 | 空discovery/ログ欠落/canary FAILを捕捉 |
| A07 | Debug overlay suite | feature未初期化/別loaderではoverlay成功にしない |
| A08 | source jobを１回配置 | browser起動/４回重複/空suiteを検出 |
| A09 | source evidence再利用 | 同じSHAでもlock/toolchain/policy差を拒否 |
| A10 | packaged runnerが明示binaryを起動 | `_dist/bin`/別PGO/Debug/DEVへのfallback拒否 |
| A11 | 最終mac artifact | 公証前/再署名copyをproduction結果にしない |
| A12 |５target全体 | Linux ARM/mac Intel等の欠落を拒否 |
| A13 | runtime/floorp/test origins | unknown originを計画エラー、上流suiteを製品へ混入させない |
| A14 |正常終了・再起動 | owned PID外へのkill、cleanup失敗を捕捉 |
| A15 | UIでworkspace作成→保存→再起動 |消失/選択/所属の仕様違反を検出 |
| A16 | UA設定変更→HTTP観測 |実header不一致、通常tabへの漏出を検出 |
| A17 | native右クリック反復 | OS入力失敗/crash、DOMだけの代用を拒否 |
| A18 |元版→先版の実update | profileを開くだけの証拠では代用不可 |
| A19 | Debug資格→製品sourceリンク | Debug binaryを製品と同一視しない |
| A20 | Debug資格の失効 | native patch差/target差/期限切れを拒否 |
| A21 |通常初回FAIL、retry PASS |初回FAILを残しclean PASS禁止 |
| A22 | pre-approval公開DAG |親run完了/既にpendingを要求する循環を拒否 |
| A23 | public mutation直前の再照合 |bundle変更/不正producer/sidecar欠落で停止 |
| A24 | Agent actions→fixed replay |任意shell/eval/URL拒否、LLM正常宣言をPASSにしない |

A01～A24は実CIの受け入れ仕様。全件実施済みではない。今回の設計checkerや既存unit testsと名前/件数を混ぜない。検証報告07に実行済みの範囲を記す。

### 完了の定義

最初の運用完成は、明示した必須subset/targetのDebug L1、source-once、exact product L2が証拠で繋がり、失敗/未実行/誤artifactが公開を止めること。全Firefox testsの全量実行や全機能coverage 100%とは異なる。

Coverageは全inventoryのonboarding、eligibleのexecution、critical scenario×target完了、state transition、known-bad検出の分母を分ける。未導入を減らして見かけの成功率を上げない。


---

<a id="doc-06"></a>

## 06. セキュリティ・障害・継続運用

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

### 信頼境界

Build、test、model、reporter、publisherを分離する。buildに必要な鍵をtest workerへ継承しない。test workerはdedicated profileとfixtureを使い、実ユーザーのログイン済みbrowser、SSH agent、cloud credential、通常HOMEを持ち込まない。fork PRを永続self-hosted環境で無承認実行しない。[M8]

QA policy、expected test set、producerの認証は候補コードだけで書き換えられない位置から供給する。test log、DOM、Issue、LLM出力はデータであり、実行権限や期待値の承認として扱わない。

### Debug の隔離

macOS Debugのconfigにはsandbox overrideがあるため、実行環境を記録し製品sandbox/通常起動証拠へ流用しない。[R2] 本方針で既存debug overrideを勝手に本番へ展開しない。安全性比較が必要なら通常sandboxの別Debug条件を設計し、対象suiteの実行可否を検証する。

tests-enabled Debug binary/helperは通常配布物ではない。test-supportとsymbolsは別artifactに保存する。privacy/network/crashreporterの実capabilityを記録し、dumpが取れないことを隠さない。

### GUI worker

１desktop/sessionに同時１GUI試験。並列化はVM/独立display/別sessionで行う。Windows desktop、macOS input/screen permissions、Linux X11/Wayland、native archをprobeする。権限不足はenvironment errorであってPASSではない。[M2]

各runにprofile/ports/downloads/outputを割当。process PIDだけでなく開始時刻/executable/profileを照合する。browser名の一括kill禁止。timeout時に子process/LaunchServicesが残る可能性はowned workerの廃棄と証拠で管理し、異なる利用者processへ信号を送らない。

### 通信とデータ

fixture serverと承認済み推論endpointへの通信に限定する。loopbackだけを安全境界にしない。外部LLMのAPI keyはcontrollerに置き、browser workerへ渡さない。download/clipboard/file-picker/update endpointはfixture経路で制限する。

synthetic profileは正常終了後に複製する。SQLite/WAL途中コピーを正常baselineにしない。profile内容全体や認証情報を無差別uploadしない。成功/失敗/release evidenceのretentionは別に定め、必要期間を超えるcrash dumpや通信本文を保持しない。

### Evidence と再試行

immutable/new-output-only、digest/size/path、target/source/run/attempt、producerを照合する。再実行は新directory/attempt。FAILからPASSになった事実も残す。helperの終了コード0だけ、モデルの感想だけ、署名だけ、artifact名だけで合格しない。

RuntimeQualificationの失効はsource/patch/target/policy/重大findingに基づく。PGO生成ジョブを毎回強制再buildするのでなく、必要な資格と製品検証を再取得する。発見されたcrashの再現率が低くても一次証拠を削除しない。

### Failure handling

| 症状 | 対応 | 禁止 |
|---|---|---|
| Debug tests compile失敗 | target/config/helperの依存を修正、未完了表示 |tests=falseへ戻してL1成功と表示 |
| PGO profile失敗 |既存generate/collect/useを診断 |profiling workloadの削除 |
| source QA失敗 | package前に停止 |別SHAの緑チェックへ差替え |
| product E2E失敗 | exact artifactとraw logで再現 |同じSHAで再packした別artifactへ黙って交換 |
| Agent/API停止 |探索未完了、L1/L2は独立 |モデル障害を製品PASS/FAILに偽装 |
| publisher証拠不一致 |public mutation前に停止 |manual approvalを理由に無視 |

### Required と shadow

shadowは計測/適応用であり、既存必須gateを弱めない。重大findingはshadowでも人間へ提出する。requiredへ昇格したcaseの失敗/欠落にcontinue-on-errorを使わない。

quarantineはowner/Issue/理由/期限/代替検査を必要とする。critical問題の免責をAgentに承認させない。緊急waiverは限定scopeの人間承認であり、wrong artifact、改変provenance、署名不一致の迂回には使わない。

### コストと保守

重いL1はDebug更新時/定期shard、sourceは共通１回、製品L2はtarget別１初回評価、Agentはbudget制約で運用する。p50/p95時間、CPU/RAM/storage、GUI占有、flake率、test-support容量、確認済みfindingあたり推論費用を測る。

ツール、モデル、prompt、harness、policy更新時にはknown-bad/fixed corpusと失敗canaryを再実行する。週次監視などは運用設計であり、この納品で通知や定期タスクは設定しない。


---

<a id="doc-08"></a>

## 08. 実装 Agent への引き継ぎ — Debug / 製品分離

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

### 共通指示（そのまま渡す文章）

> Floorp QA設計0.3.0の00/01/02/10/11/12/04/07を読み、対象checkoutの最新sourceと既存testsを確認する。方針はDebug Runtime（debug=true,pgo=false）でtests有効化とMozilla L1実行、PGO/production-optの生成設定は維持、Floorp source-only QAはpackage runの共通jobで１回、Floorp browser/native testsは最終製品artifact×native targetで１初回評価。製品packagingの--disable-testsは初期導入で維持する。Runtime/provenance/署名・公証/native verification/手動承認を弱めない。指示された作業票だけを実装し、公開・署名鍵操作・workflow本番起動は別途許可がない限り行わない。

### 最初の実装

> QA3-01とQA3-04を別PRとして進める。Runtimeはsetupの最終generated configでDebug非PGOだけtestsを有効化し、effective configure結果とPGO generate/use不変を検査する。templateのdisable-testsを全OS/全profileで無条件削除しない。legacy Debug+PGOをcanonical QAと誤分類しない。Floorpはsource-only test catalogを固定し、source jobを各package jobのneedsにする。deno task test/test:integrationをソース専用jobに混ぜない。新packaged runnerは別作業なので、source testsの成功を実製品の成功と報告しない。

### Runtimeテストの実装

> QA3-02/03を行う。同じDebug native buildから実ハーネスが必要とするtest archives/helper/configを別artifactに保持する。primary Runtime artifactとproduction v2 manifestは変更しない。Linux x64の実在manifestでRuntime-only L1を最初に実証し、empty discovery/意図的FAIL/欠落ログを拒否する。Floorp overlayが必要なsuiteは別evidenceとしてsentinelを追加し、overlay adapter未完成を理由にRuntime-only全体を止めない。Debugの成功をPGO binaryに直接付けない。

### 製品テストの実装

> QA3-05/06/07を行う。最終workflow outputs、公証後のmacOS artifact、認証済みnative recordに結合する。元colocated testsをorigin=floorp/mozilla-imported/toolingとexecutionKindで台帳化し、Floorpのpackaged-compatibleケースを移す。unknownや未移行を黙ってskipしない。dev Runtimeへfallbackせず、実行binary/head/build/loaderを検査する。Linux ARMは非PGOでも含め、mac universalはIntelとARMの別native runにする。既存内部probeとOS right-clickを混同しない。

### 資格・公開ゲートの実装

> QA3-08/09は12の別Subject/再利用契約と11の非循環DAGを実装する。Debug qualificationはsource/patch/target/config差分に対する資格で、製品そのもののPASSではない。assembleの後にexact bundleからQAし、sidecarを別artifactとして認証する。QA前に既にpending deploymentがあることや親run全体の完了を要求する古いhelperを新inline経路にそのまま使わない。manual approval後、public mutation直前にtrusted policy/producer/sidecar/bundleを再確認する。publicationAuthorized:falseの既存local gateを単独の公開許可へ変更しない。

### 探索の拡張

> QA3-10は１featureから開始。model controllerとbrowser workerを分離し、任意shell/eval/URLを与えない。Budget、固定observer/oracle、JSONL、LLMなしreplay、bad/fixed検査を追加する。Debugのみの再現をPGO問題の修正確認に使わない。回帰テストと期待値には人間レビューを要求する。

### 各PRの提出形式

対象source SHA、作業票ID、変更一覧、実行したcommands、実際のartifact/run/target、PASS/FAIL/未実施、負例の検出、未移行/未対応、設計からの差分を記載する。生成コードと実環境での検証を区別する。現行pinのdriftがあれば差分を読んでレビューし、自動で「新しいからOK」にしない。


---

<a id="doc-13"></a>

## 13. 0.2.0 からの変更・移行手順

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

### 変更の要点

| 旧設計/旧実装 | 0.3.0 |
|---|---|
| release候補ごとに別test-capable Runtimeを作ると読める | Debug native buildにL1を集約。適合するqualificationを製品releaseから再利用 |
| release-readinessのProductSubjectにL1 browser-chrome/xpcshell/WPTを混載 | 製品readinessはL2のみ。Debug L1は別Subject/qualificationへ移動 |
| sourceとbrowser testsの１回実行の境界が曖昧 | source-onlyはrun内１共通job、browser/nativeはfinal artifact×target |
| tests-enabled artifact buildが中心と読める |本番package flagsは維持し、外部packaged runnerを接続 |
| QA-01/02中心の着手 |Runtime Debugフラグとsource QA集約を最初に着手 |
| PGO版だけの製品条件 | production-opt（Linux ARM等）も対象 |
| read-only pre-publicationとrequired gateが混ざりやすい | legacy hold検査と新pre-approval intake/public verifierを分離 |

### 互換性

既存 `existing-final` profileとその２probe adapterは維持する。`release-readiness` は後方互換のCLI名として残すが、scopeを `production-package-readiness` に改める。新しい同名profile `production-package-readiness` を推奨し、両方は同じL2計画を作る。plan IDはprofile名も含むためalias同士で異なる。旧plan/result/subjectを無検査で新planへ転用しない。

L1を製品計画から外すのは試験削除の免責ではなく、別Debug資格へ置き換える責務分離。新しいqualification verifierが未実装の間は全体release-readyを表示しない。既存local gateは引き続き `publicationAuthorized:false`。

native record v2 / release bundle v2 / ProductSubject v1 は維持。新Debug/Source/Qualification/ReleaseSidecar evidenceの実validatorは作業票で追加する。`qa/design/*.json`は設計契約であって、実CI適用済みの証拠ではない。

### 新しいファイル

00/10/11/12/13の文書、`qa/design/build-policy.json`、`qa/design/ci-graph.json`、それらの設計用schema、`tools/qa/design_contract.py` と整合テストを追加。README、既存01～09、integrations/schema案内、baseline policy、CLI profile表示と製品L1誤用拒否、検証報告を更新した。

### 作業票の対応

| 旧 | 新 |
|---|---|
| QA-01 共通CLI | QA3-04/05 |
| QA-02 final probes | QA3-05 |
| QA-03/04 Runtime bundle/harness | QA3-01/02/03/08 |
| QA-05/06 native/feature | QA3-06/07 |
| QA-07 Agent | QA3-10 |
| QA-08 publisher | QA3-09 |
| QA-09/10 運用 | QA3-11 |

### 既存checkoutへの導入

未導入checkoutは `install.py --repo PATH` でdry-runし、明示的applyで新規追加できる。0.2.0を既に導入済みならinstall.pyは上書き拒否する。別worktreeで比較して、変更したdocs/qaと関連tool/policyをレビューして取り込む。新規性を偽るため旧ファイルを一括削除しない。

`propose_integration.py` は従来どおり既存２probeのadvisory接続差分を生成する補助であり、新Debug profile、source-once、packaged全suite、正式publisherを自動実装しない。この位置づけを変更しない。生成差分を適用する前にexactソースpinとgit apply --checkを実checkoutで確認する。

### 受け入れとrollback

新しい設計checker、旧unit tests、新profile計画、unsigned拒否、ProductSubjectへのL1誤投入拒否、ドキュメントリンクとchecksumを確認する。本環境の結果は07に記載。

実CIのrollbackは新規shadow接続単位で行い、既存native/provenance/manual approvalを消さない。required gateを戻す場合は明示承認・期間・代替検査を残す。旧release-readiness JSONを戻してL1を製品に混載する方法では戻さない。


---

<a id="doc-07"></a>

## 07. 検証報告 / 0.3.0

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

### 実施結果

この作成環境で **114件のPython unittestが成功**。失敗0、error0、skip0。旧75件を改訂後のキットで再実行し、設計/計画分離に関する39件を追加した。検証用データはsyntheticで、実Floorpの試験結果ではない。

| 検査 | 実施結果 |
|---|---|
| `python3 -m unittest discover -s tools/qa/tests -v` |114件成功 |
| `python3 tools/qa/design_contract.py` |DESIGN_VALID。ビルド/CI/公開の副作用なし |
| Python compileall |tools/qa と install.py の構文検査成功 |
| JSON Schema Draft 2020-12 |10定義を検査。設計2モデル、baseline、3profile計画も適合 |
| host-only workflow YAML |構文読取成功。GitHub Actionsとしての実行ではない |
| CLI help/version |起動成功、0.3.0を表示 |
| installer |既存テスト内でdry-run/新規追加/上書き拒否を検証 |

環境: Python 3.13.5 / container。JSON Schema/YAML検査はこの作成環境のvalidatorを使い、CLIの実行時依存に追加していない。生ログは`validation/unittest.log`、要約は`validation/host-validation.json`、設計結果は`validation/design-contract.json`。

### 新しい負例

Debugでtests無効/PGO有効、productionでtests設定を強制変更、PGO profiling削除、product packageのtests有効化、source browser依存/重複、Linux ARM欠落、Debug/製品BuildID同一視、test-supportのprimary混入、manual approval省略、assemble↔QA循環、unknown edge、Agent blocking化、ProductSubjectへのL1/mozilla-harness誤投入、unsigned production計画を拒否するテストを追加した。

旧readiness aliasと新profileが同じL2ケースを持ち別plan IDを持つこと、旧既存probeの互換性、未実装caseは引き続きBLOCK、local publicationAuthorized=falseも確認した。

### 実装が変わった範囲

README/既存01～09の改訂、新00/10～13、設計JSON/schema、design checker/tests、baseline policy、CLI/profile enum、製品Subjectで上流evidenceを拒否するcore検査を変更。Runtime/Floorpの実リポジトリ、GitHubのworkflow、protected environment、署名/公開設定は変更していない。

### 未実施

Runtimeの実configure/build、tests-enabled Debugの生成、test archivesの実生成、Mozilla標準suiteの実行、PGO profiling、最終Floorpのnative GUI、Deno、全colocated testsのpackaged移行、外部LLM、GitHub Actions、publisherのpublic mutation阻止は、この環境では未実施。

full checkoutに対する`git apply --check`は未実施。`propose_integration.py`の変換単体テストが成功していても、現在のfull checkoutで適用・build成功したとはしない。CLIのprocess/driver機能は既存のpilotであり、実機での安全性・全OS対応の認定ではない。

### 納品物の整合

文書リンク、バージョン、policyとDAG、チェックサムは梱包時に検査する。`MANIFEST.sha256`は各ファイルのbytesを識別するもので、署名や信頼済みproducerの認証ではない。


---

<a id="doc-09"></a>

## 09. 出典・ソース基準・確認範囲

**版 0.3.0 / 2026-10-09 / 設計改訂。実 CI への適用は未実施。**

Floorp head: `013bb6c9ed19250592898ec8fbc8d7d24aa847be`。Runtime観測head: `c74fe1a545d275cdd710ab44701c1ee0dd6b0eae`。いずれも2026-10-09のGitHub connectorでbranch headを再確認した。今回再読したのはRuntime daily-build/setup、Floorp deno.jsonとpackage.ymlのtests設定。残る構成は本会話内で同じheadに対して確認したソースを引き継ぐ。全treeをcloneして再監査/ビルドしたという意味ではない。

`qa/source-pins.json`はread-only drift検査の資料であって、本番Runtime選択の正本ではない。実releaseのRuntimeは認証済みrun/manifestから解決する。

### Floorp

- **[F1] `AGENTS.md`** — ５層構成、dev/testと製品loader、colocated/Marionette。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/AGENTS.md`
- **[F2] `.github/workflows/package.yml`** — artifact build、tests無効、native artifact、before/after-mach、mac最終outputs。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/.github/workflows/package.yml`
- **[F3] `.github/workflows/package_and_publish_release.yml`** — ４package/５native verification/assemble/publish。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/.github/workflows/package_and_publish_release.yml`
- **[F4] `.github/workflows/verify-release-artifact.yml`** — native実行、build identity、署名、v2 record。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/.github/workflows/verify-release-artifact.yml`
- **[F5] `.github/workflows/assemble-release-bundle.yml`** — closedなbundle v2とnative record依存。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/.github/workflows/assemble-release-bundle.yml`
- **[F6] `.github/workflows/validate-final-package-qa.yml`** — #2886、既存probes、公開待機のread-only再照合。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/.github/workflows/validate-final-package-qa.yml`
- **[F7] `tools/final-package-qa-source.mjs`** — pre-publicationのsource/先行jobs/bundle/approval条件。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/tools/final-package-qa-source.mjs`
- **[F8] `tools/test-final-web-panel-ua.py`** — 実HTTP/製品loader/isolated profile。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/tools/test-final-web-panel-ua.py`
- **[F9] `tools/test-final-context-menu.py`** — Fluent/Flasco/内部popupを使うintegration。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/tools/test-final-context-menu.py`
- **[F10] `tools/app-shim/test-runtime.py`** — Marionette/POSIX/LaunchServices/owned process。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/tools/app-shim/test-runtime.py`
- **[F11] `deno.json`** — source向けtaskとbrowser-integrated taskの違い。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/deno.json`
- **[F12] `tools/src/release_provenance.ts`** — strict closed schema、existing native/release provenance。
  `https://github.com/Floorp-Projects/Floorp/blob/013bb6c9ed19250592898ec8fbc8d7d24aa847be/tools/src/release_provenance.ts`

### Floorp-Runtime

- **[R1] `.github/workflows/daily-build.yml`** — debug/pgo入力、Linux ARM pgo=false、build/verify/manifest条件。
  `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/daily-build.yml`
- **[R2] `.github/workflows/scripts/setup-floorp.sh`** — template選択、Debug patch/flag、mac sandbox export、PGO分岐。
  `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/scripts/setup-floorp.sh`
- **[R3] `.github/workflows/scripts/build-and-package.sh`** — native compile/packageとprimary artifact生成。
  `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/scripts/build-and-package.sh`
- **[R5] `.github/runtime-upstream.json`** — compiled upstreamとnative patch pin。
  `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/runtime-upstream.json`

**[R4] OS別mozconfig** — tests directiveの表は本会話内のsource読取に基づく。同じRuntime headを再確認したが、実effective configは未検証。

- `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/mozconfigs/windows-x86_64.mozconfig`
- `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/mozconfigs/linux-x86_64.mozconfig`
- `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/mozconfigs/linux-aarch64.mozconfig`
- `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/mozconfigs/macosx64-x86_64.mozconfig`
- `https://github.com/Floorp-Projects/Floorp-Runtime/blob/c74fe1a545d275cdd710ab44701c1ee0dd6b0eae/.github/workflows/mozconfigs/macosx64-aarch64.mozconfig`

**補足経路:** `.github/workflows/common-build.yml` と各wrapperはsetup/build scriptへの引数を渡す。OS wrapperにtests runnerが自動的に含まれていると仮定しない。

### Mozilla / GitHub公式資料

- **[M1]** artifactのC++再利用、MOZ_ARTIFACT_FILEにtest siblingが含まれないこと。
  `https://firefox-source-docs.mozilla.org/contributing/build/artifact_builds.html`
- **[M2]** Desktop UI、manifest、real focus/inputとheadlessの制約。
  `https://firefox-source-docs.mozilla.org/testing/browser-chrome/index.html`
- **[M3]** mach/test、raw structured logとtestsの役割。
  `https://firefox-source-docs.mozilla.org/testing/mochitest-plain/index.html`
- **[M4]** 内部module向けテストの参考。参照は前版から継承。
  `https://firefox-source-docs.mozilla.org/testing/xpcshell/index.html`
- **[M5]** profile-generate→profiling workload→profile-useの過程。
  `https://firefox-source-docs.mozilla.org/build/buildsystem/pgo.html`
- **[M6]** Debugと製品performanceの比較条件の違い。
  `https://firefox-source-docs.mozilla.org/performance/Benchmarking.html`
- **[M7]** browser chrome/content automation。参照は前版から継承。
  `https://firefox-source-docs.mozilla.org/remote/marionette/Intro.html`
- **[M8]** 未信頼code/runner/credential境界。参照は前版から継承。
  `https://docs.github.com/en/actions/reference/security/secure-use`
- **[M9]** WPT harness/metadata。参照は前版から継承。
  `https://firefox-source-docs.mozilla.org/web-platform/index.html`
- **[M10]** repeat/verify完了と時間上限。参照は前版から継承。
  `https://firefox-source-docs.mozilla.org/testing/test-verification/index.html`

M1/M2/M3/M5/M6は本改訂でもwebで確認。一般Firefoxの対応はFloorp固有artifact/テスト資材の実行保証ではない。CLIの実際のoption・生成物は選んだRuntime revisionのハーネスで検証する。

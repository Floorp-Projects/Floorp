# SPDX-License-Identifier: MPL-2.0
"""Adapters for existing, version-pinned Floorp package probes."""
from __future__ import annotations

import os
import platform
import signal
import subprocess
import sys
from pathlib import Path

from core import QAError, contained, digest, evidence_entry, read_json, require, result

PROBES = {
    "l2.web-panel-http": {"script": "tools/test-final-web-panel-ua.py", "folder": "web-panel-ua", "kind": "packaged-automation"},
    "l2.fluent-flasco": {"script": "tools/test-final-context-menu.py", "folder": "fluent-flasco", "kind": "packaged-automation"},
}


def normalize_report(report: dict, native: dict, floorp_version: str, case_id: str) -> tuple[str, dict]:
    require(case_id in PROBES, "Unsupported existing probe")
    require(type(report) is dict and report.get("status") in ("passed", "failed"), "Unrecognized probe report schema/status")
    require(report.get("nativeRecord") == native, "Report targets a different native record")
    if report["status"] == "failed":
        return "FAIL", {"error": report.get("error", "Probe reported failure")}
    require(report.get("hostProcessIdentity", {}).get("verified") is True, "Host process identity not verified")
    require(type(report.get("ownedHostPid")) is int and report["ownedHostPid"] > 0, "Missing owned process")
    require(report["ownedHostPid"] == report["hostProcessIdentity"].get("pid"), "Owned PID differs from verified host PID")
    require(not any(key in report for key in ("hostCleanupError", "clientCleanupError", "cleanupError", "unexpectedHostExit")), "Cleanup/exit evidence contradicts PASS")
    exit_code, requested = report.get("hostExitCode"), report.get("cleanupRequestedSignal")
    require(type(exit_code) is int and (requested is None or type(requested) is int), "Missing exit status")
    require(exit_code in (0, -(requested or 0)), "Abnormal browser exit")
    if case_id == "l2.fluent-flasco":
        inner = report.get("browserRegression", {})
        require(inner.get("status") == "passed" and type(inner.get("checks")) is list and bool(inner["checks"]), "Incomplete browser regression")
        identity = inner.get("identity", {})
        version_key = "floorpVersion"
    else:
        require(type(report.get("httpRequests")) is dict and bool(report["httpRequests"]), "No HTTP evidence")
        require(type(report.get("checks")) is list and bool(report["checks"]), "No Web Panel assertions")
        identity, version_key = report.get("identity", {}), "version2"
    require(identity.get("version") == native["firefox_version"], "Firefox version differs")
    require(identity.get(version_key) == floorp_version and identity.get("buildID2") == native["build_id2"], "Floorp version/buildID2 differs")
    require(identity.get("appBuildID") == identity.get("platformBuildID") == native["runtime"]["expected_build_id"], "Browser BuildID differs")
    require(identity.get("startupMode") not in (None, "dev", "test") and identity.get("httpLoaderAllowed") is False, "Development loader detected / mode not reported")
    require(type(identity.get("sandboxLevel")) is int and identity["sandboxLevel"] > 0, "Sandbox not proven enabled")
    return "PASS", {"identity": identity, "sourceReportDigest": digest(report), "probe": case_id}


def collect_reports(plan: dict, subject: dict, native: dict, qa_root: Path, evidence_root: Path) -> list[dict]:
    require(subject["nativeRecordDigest"] == digest(native), "Native record differs from subject")
    records = []
    for row in plan["cases"]:
        case = row["id"]
        if case not in PROBES:
            continue  # Planned-but-unimplemented cases remain MISSING, never SKIP/PASS.
        candidates = sorted((qa_root / PROBES[case]["folder"]).glob("run-*/report.json"))
        require(len(candidates) <= 1, f"Ambiguous reports for {case}; isolate each run/attempt")
        if not candidates:
            continue
        path = candidates[0]
        require(not path.is_symlink(), "Symlink report")
        report = read_json(path)
        status, details = normalize_report(report, native, subject["floorpVersion"], case)
        records.append(result(plan, case, status, PROBES[case]["kind"], [evidence_entry(evidence_root, path)], details))
    return records


def clean_environment() -> dict[str, str]:
    # This avoids accidental token inheritance. It is NOT an OS sandbox.
    keys = ("PATH", "HOME", "USER", "LOGNAME", "TMPDIR", "TMP", "TEMP", "LANG", "LC_ALL", "DISPLAY",
            "XAUTHORITY", "WAYLAND_DISPLAY", "XDG_RUNTIME_DIR", "DBUS_SESSION_BUS_ADDRESS",
            "SYSTEMROOT", "WINDIR", "USERPROFILE", "HOMEDRIVE", "HOMEPATH", "COMSPEC")
    return {key: os.environ[key] for key in keys if key in os.environ}


def run_existing_probe(repo: Path, case_id: str, browser: Path, native_record: Path,
                       floorp_version: str, output: Path, timeout: int) -> dict:
    require(os.environ.get("QA_DISPOSABLE_WORKER") == "1", "Use a disposable, credential-free GUI worker; set QA_DISPOSABLE_WORKER=1 there")
    require(platform.system() in ("Linux", "Darwin"), "Existing HostProcess helper is POSIX-specific; Windows adapter is not implemented")
    require(case_id in PROBES and 1 <= timeout <= 3600, "Unsupported probe or timeout")
    script = contained(repo, PROBES[case_id]["script"])
    require(browser.exists() and native_record.is_file(), "Browser/native record missing")
    output.mkdir(parents=True, exist_ok=False)
    command = [sys.executable, str(script), "--browser", str(browser.resolve()), "--native-record", str(native_record.resolve()),
               "--expected-floorp-version", floorp_version, "--output", str(output / "raw")]
    with (output / "process.log").open("xb") as stream:
        process = subprocess.Popen(command, cwd=repo, env=clean_environment(), stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        timed_out = False
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            # LaunchServices may reparent the browser; only VM disposal is a
            # complete cleanup guarantee on timeout. Never pkill by browser name.
            os.killpg(process.pid, signal.SIGTERM)
            try:
                code = process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                code = process.wait(timeout=10)
    return {"status": "TIMEOUT" if timed_out else "PASS" if code == 0 else "FAIL", "exitCode": code,
            "command": command, "requiresWorkerDisposal": timed_out,
            "note": "PASS here means process exit only. Import the detailed report before accepting QA."}


def collect_standalone(plan: dict, subject: dict, native: dict, case_id: str,
                       run_dir: Path, evidence_root: Path) -> list[dict]:
    """Import this toolkit's run-probe output without moving its report files."""
    require(subject["nativeRecordDigest"] == digest(native), "Native record differs from subject")
    require(case_id in PROBES and case_id in [c["id"] for c in plan["cases"]], "Unplanned probe")
    process_path = run_dir / "process-result.json"
    process = read_json(process_path)
    require(type(process) is dict and process.get("status") in ("PASS", "FAIL", "TIMEOUT"), "Invalid process record")
    evidence = [evidence_entry(evidence_root, process_path)]
    candidates = sorted((run_dir / "raw").glob("run-*/report.json"))
    require(len(candidates) <= 1, "Ambiguous standalone reports")
    if process["status"] != "PASS":
        if candidates:
            evidence.append(evidence_entry(evidence_root, candidates[0]))
        return [result(plan, case_id, process["status"], PROBES[case_id]["kind"], evidence, {"process": process})]
    require(type(process.get("exitCode")) is int and process["exitCode"] == 0 and process.get("requiresWorkerDisposal") is False,
            "Process PASS has invalid exit or cleanup state")
    require(len(candidates) == 1, "Successful process has no detailed report")
    evidence.append(evidence_entry(evidence_root, candidates[0]))
    status, details = normalize_report(read_json(candidates[0]), native, subject["floorpVersion"], case_id)
    return [result(plan, case_id, status, PROBES[case_id]["kind"], evidence, details)]

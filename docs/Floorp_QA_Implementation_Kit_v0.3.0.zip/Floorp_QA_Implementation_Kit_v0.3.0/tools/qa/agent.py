# SPDX-License-Identifier: MPL-2.0
"""Small real Marionette action bridge; no arbitrary eval/shell/URL API.

The trusted adapter reuses Floorp's existing POSIX HostProcess/Marionette.
This is automation UI, not native OS input. It does NOT implement feature-wide
QA, OS isolation, all child-process crash monitoring, or a publication gate.
"""
from __future__ import annotations
import http.server
import importlib.util
import json
import os
import platform
import plistlib
import select
import sys
import threading
import time
from pathlib import Path
from typing import Any

from core import QAError, contained, read_json, require, utc_now, validate_subject, write_json

ELEMENT_KEY = "element-6066-11e4-a52e-4f735466cecf"
LOCATORS = {
    "fixture.increment": ("content", "#increment"),
    "fixture.reset": ("content", "#reset"),
    "chrome.new-tab": ("chrome", "#tabs-newtab-button"),
    "chrome.reload": ("chrome", "#reload-button"),
}
PAGE = b'''<!doctype html><html><head><meta charset="utf-8"><title>Floorp QA fixture</title>
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'none'; form-action 'none'; base-uri 'none'">
</head><body><h1>Isolated QA counter</h1><button id="increment">Increment</button>
<button id="reset">Reset</button><output id="count">0</output>
<script>let n=0;const c=document.getElementById('count');document.getElementById('increment').onclick=()=>c.textContent=String(++n);document.getElementById('reset').onclick=()=>{n=0;c.textContent='0'}</script></body></html>'''


def validate_action(value: Any) -> dict:
    require(type(value) is dict and type(value.get("kind")) is str, "Action must be an object with a kind")
    kind = value["kind"]
    if kind == "observe":
        require(set(value) == {"kind"}, "observe accepts no arguments")
    elif kind == "navigate":
        require(set(value) == {"kind", "fixture"} and value["fixture"] == "counter", "Only the registered counter fixture is navigable")
    elif kind == "click":
        require(set(value) == {"kind", "target"} and type(value["target"]) is str and value["target"] in LOCATORS, "Click target is not registered")
    else:
        raise QAError(f"Forbidden action kind: {kind}")
    return dict(value)


def replay_actions(payload: Any, subject_id: str) -> list[dict]:
    """Accept a raw action array or this tool's recorded replay.json."""
    if type(payload) is dict:
        require(set(payload) == {"schemaVersion", "subjectId", "actions", "status"}, "Unknown replay fields")
        require(payload["schemaVersion"] == 1 and payload["subjectId"] == subject_id, "Replay subject mismatch")
        require(type(payload["status"]) is str, "Invalid recorded replay status")
        payload = payload["actions"]
    require(type(payload) is list and 0 < len(payload) <= 500, "Expect 1..500 replay actions")
    return [validate_action(action) for action in payload]


class Fixture(http.server.BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        body = PAGE if self.path == "/counter" else b"Not found"
        self.send_response(200 if self.path == "/counter" else 404)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args: Any) -> None:
        pass


def unwrap(value: Any) -> Any:
    return value.get("value", value) if type(value) is dict else value


class Driver:
    def __init__(self, repo: Path, browser: Path, output: Path, subject: dict):
        require(os.environ.get("QA_DISPOSABLE_WORKER") == "1", "Disposable GUI worker required (QA_DISPOSABLE_WORKER=1)")
        require(platform.system() in ("Linux", "Darwin"), "Windows driver is not onboarded")
        validate_subject(subject)
        require((platform.system() == "Darwin") == subject["target"].startswith("mac/"), "OS and subject target mismatch")
        actual_arch = {"arm64": "aarch64", "AMD64": "x86_64"}.get(platform.machine(), platform.machine())
        require(subject["target"].split("/")[1] == actual_arch, "Native architecture mismatch (emulation is not native evidence)")
        require(not subject["unsigned"], "This bridge requires an unmodified production package")
        helper_path = contained(repo, "tools/app-shim/test-runtime.py")
        spec = importlib.util.spec_from_file_location("floorp_qa_native_helpers", helper_path)
        require(spec is not None and spec.loader is not None, "Cannot load trusted Floorp helper")
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        self.client = self.host = self.server = self.log = None
        self.subject, self.output = subject, output
        output.mkdir(parents=True, exist_ok=False)
        profile = (output / "profile").resolve()
        profile.mkdir(mode=0o700)
        port = helper.unused_port()
        prefs = {"marionette.port": port, "browser.shell.checkDefaultBrowser": False,
                 "browser.aboutwelcome.enabled": False, "browser.startup.page": 0,
                 "browser.startup.homepage": "about:blank", "app.update.enabled": False,
                 "datareporting.policy.dataSubmissionEnabled": False}
        (profile / "user.js").write_text("\n".join(f"user_pref({json.dumps(k)}, {json.dumps(v)});" for k, v in prefs.items()) + "\n")
        browser = browser.resolve(strict=True)
        binary = browser
        if browser.is_dir():
            info = plistlib.loads((browser / "Contents/Info.plist").read_bytes())
            binary = browser / "Contents/MacOS" / info["CFBundleExecutable"]
        try:
            self.log = (output / "browser.log").open("w")
            self.host = helper.HostProcess(browser, binary, profile, output, self.log,
                                          launch_services=platform.system() == "Darwin")
            def connect():
                require(self.host.poll() is None, "Browser exited during startup")
                try:
                    return helper.Marionette(port)
                except OSError:
                    return None
            self.client = helper.wait_for("QA Marionette", connect, 90)
            self.host.verify_session(self.client.session)
            self.client.command("WebDriver:SetTimeouts", {"script": 15000, "pageLoad": 20000, "implicit": 0})
            self.client.socket.settimeout(25)
            self.client.context("chrome")
            identity = self.client.script("""
                const {NoranekoConstants:n}=ChromeUtils.importESModule('resource://noraneko/modules/NoranekoConstants.sys.mjs');
                return {floorp:n.version2,buildID2:n.buildID2,firefox:Services.appinfo.version,
                  buildID:Services.appinfo.appBuildID,platformBuildID:Services.appinfo.platformBuildID,
                  mode:Services.prefs.getStringPref('nora.startup.mode',''),
                  http:Services.prefs.getBoolPref('nora.dev.allow_http_loader',false),
                  sandbox:Services.prefs.getIntPref('security.sandbox.content.level')};
            """)
            require(identity["floorp"] == subject["floorpVersion"] and identity["buildID2"] == subject["buildID2"], "Floorp identity mismatch")
            require(identity["firefox"] == subject["firefoxVersion"] and identity["buildID"] == identity["platformBuildID"] == subject["runtime"]["expected_build_id"], "Runtime identity mismatch")
            require(identity["mode"] not in ("dev", "test") and identity["http"] is False and identity["sandbox"] > 0, "Product mode/sandbox requirement failed")
            write_json(output / "identity.json", identity)
            self.server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Fixture)
            threading.Thread(target=self.server.serve_forever, daemon=True).start()
            self.url = f"http://127.0.0.1:{self.server.server_port}/counter"
        except Exception:
            self.close()
            raise

    def observe(self) -> dict:
        require(self.host.poll() is None, "Owned browser exited")
        self.client.context("chrome")
        state = self.client.script("""
            const tabs=Array.from(window.gBrowser.tabs);
            return {tabCount:tabs.length,selectedCount:tabs.filter(t=>t.selected).length,
              selectedExists:tabs.includes(window.gBrowser.selectedTab)};
        """)
        require(type(state) is dict and state.get("tabCount", 0) > 0 and state.get("selectedCount") == 1 and state.get("selectedExists") is True,
                "Invariant violation: selected browser tab")
        self.client.context("content")
        page = self.client.script("return {url:location.href,count:document.getElementById('count')?.textContent??null};")
        return {"browser": state, "fixture": page if page["url"] == self.url else {"registeredFixture": False}}

    def execute(self, action: dict) -> dict:
        action = validate_action(action)
        if action["kind"] == "navigate":
            self.client.context("content")
            self.client.navigate(self.url)
        elif action["kind"] == "click":
            context, selector = LOCATORS[action["target"]]
            self.client.context(context)
            if context == "content":
                require(self.client.script("return location.href;") == self.url, "Content actions restricted to owned fixture")
            element = unwrap(self.client.command("WebDriver:FindElement", {"using": "css selector", "value": selector}))
            require(type(element) is dict and type(element.get(ELEMENT_KEY)) is str, "No actionable registered element")
            self.client.command("WebDriver:ElementClick", {"id": element[ELEMENT_KEY]})
        return self.observe()

    def close(self) -> None:
        failures = []
        if self.client is not None:
            try:
                self.client.close()
            except Exception as exc:
                failures.append(f"client: {exc}")
        if self.host is not None:
            try:
                if self.host.poll() is not None:
                    failures.append("Owned host exited before requested cleanup")
                self.host.close()
                if type(self.host.returncode) is not int or self.host.returncode not in (0, -int(self.host.requested_signal or 0)):
                    failures.append(f"Unexpected host cleanup exit: {self.host.returncode}")
            except Exception as exc:
                failures.append(f"host: {exc}")
        if self.server is not None:
            self.server.shutdown()
            self.server.server_close()
        if self.log is not None:
            self.log.close()
        if failures:
            raise QAError("; ".join(failures))


def execute_campaign(repo: Path, browser: Path, subject: dict, output: Path,
                     actions: list[dict] | None, max_actions: int, seconds: int) -> dict:
    require(1 <= max_actions <= 500 and 1 <= seconds <= 3600, "Campaign budget out of range")
    if actions is not None:
        require(type(actions) is list and 0 < len(actions) <= max_actions, "Invalid replay action count")
        actions = [validate_action(action) for action in actions]
    driver = None
    events = []
    summary = {"schemaVersion": 1, "subjectId": subject["id"], "status": "incomplete", "releaseEvidence": False}
    try:
        driver = Driver(repo, browser, output, subject)
        deadline = time.monotonic() + seconds
        with (output / "actions.jsonl").open("x", encoding="utf-8") as log:
            initial = driver.observe()
            if actions is None:
                print(json.dumps({"observation": initial, "allowedTargets": sorted(LOCATORS), "protocol": "one validated action JSON per line"}), flush=True)
            for index in range(max_actions):
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    summary["status"] = "budget-exhausted"
                    break
                if actions is not None:
                    if index >= len(actions):
                        summary["status"] = "replay-complete"
                        break
                    action = actions[index]
                else:
                    ready, _, _ = select.select([sys.stdin], [], [], remaining)
                    if not ready:
                        summary["status"] = "budget-exhausted"
                        break
                    raw = sys.stdin.buffer.readline(65537)
                    if not raw:
                        summary["status"] = "input-ended"
                        break
                    require(len(raw) <= 65536, "Action input too large")
                    from core import loads
                    action = validate_action(loads(raw.decode("utf-8")))
                event = {"step": index + 1, "at": utc_now(), "action": action}
                # Write the attempted action before execution, including failures.
                log.write(json.dumps({**event, "phase": "start"}) + "\n")
                log.flush()
                try:
                    observation = driver.execute(action)
                    event.update({"phase": "end", "status": "completed", "observation": observation})
                except Exception as exc:
                    event.update({"phase": "end", "status": "failed", "error": str(exc)})
                    log.write(json.dumps(event) + "\n"); log.flush()
                    events.append(event)
                    raise
                log.write(json.dumps(event) + "\n"); log.flush()
                events.append(event)
                if actions is None:
                    print(json.dumps(event), flush=True)
            else:
                summary["status"] = "replay-complete" if actions is not None and len(actions) == max_actions else "budget-exhausted"
    except Exception as exc:
        summary.update({"status": "finding-or-environment-error", "error": str(exc)})
    finally:
        if driver is not None:
            try:
                driver.close()
            except Exception as exc:
                summary.update({"status": "cleanup-error", "cleanupError": str(exc), "requiresWorkerDisposal": True})
        output.mkdir(parents=True, exist_ok=True)
        summary["completedSteps"] = sum(event.get("status") == "completed" for event in events)
        write_json(output / "campaign.json", summary)
        write_json(output / "replay.json", {"schemaVersion": 1, "subjectId": subject["id"],
                                            "actions": [event["action"] for event in events],
                                            "status": summary["status"]})
    return summary

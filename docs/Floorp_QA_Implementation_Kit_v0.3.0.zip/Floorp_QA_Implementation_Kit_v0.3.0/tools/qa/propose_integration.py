#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Write a reviewable diff. Never changes the checkout, CI or release settings."""
from __future__ import annotations
import argparse
import difflib
import json
from pathlib import Path
import sys
from core import QAError, blob_sha, read_json, require

ROOT = Path(__file__).resolve().parents[2]


def once(source: str, old: str, new: str) -> str:
    require(source.count(old) == 1, f"Expected exactly one patch anchor: {old[:100]!r}")
    return source.replace(old, new, 1)


def transform(path: str, source: str) -> str:
    if path == "deno.json":
        data = json.loads(source)
        require("qa" not in data.get("tasks", {}), "qa task already exists; reconcile manually")
        return once(source, '"tasks": {', '"tasks": {\n    "qa": "deno run --allow-run=python,python3 tools/qa/cli.ts",')
    if path == "tools/test-final-web-panel-ua.py":
        source = once(source,
            'require(record["firefox_version"] == "157.0.1", "Expected final Firefox157.0.1")',
            'require(isinstance(record["firefox_version"], str) and\n'
            '            re.fullmatch(r"[0-9]+\\.[0-9]+(?:\\.[0-9]+)?", record["firefox_version"]),\n'
            '            "Expected Firefox version from authenticated native record")')
        return once(source, 'identity["version"] == "157.0.1"', 'identity["version"] == record["firefox_version"]')
    if path == "tools/test-final-context-menu.py":
        return once(source, 'identity["version"] == record["firefox_version"] == "157.0.1" and',
                    'identity["version"] == record["firefox_version"] and')
    if path == ".github/workflows/validate-final-package-qa.yml":
        source = once(source,
            "if (version !== '12.20.1') throw new Error('This regression run requires Floorp12.20.1');",
            "if (!/^(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)$/.test(version)) {\n"
            "              throw new Error('Expected canonical Floorp version from exact source package.json');\n"
            "            }\n"
            "            fs.appendFileSync(process.env.GITHUB_ENV, `QA_EXPECTED_FLOORP_VERSION=${version}\\n`);")
        source = once(source, "              record['firefox_version'] != '157.0.1' or\n",
            "              not isinstance(record['firefox_version'], str) or not record['firefox_version'] or\n")
        require(source.count("--expected-floorp-version 12.20.1") == 2, "Expected two versioned package probes")
        source = source.replace("--expected-floorp-version 12.20.1", '--expected-floorp-version "$QA_EXPECTED_FLOORP_VERSION"')
        bind = '''      # QA KIT: advisory until the per-target acceptance matrix is completed.
      - name: Bind exact package QA subject and plan (advisory)
        id: qa-kit-plan
        continue-on-error: true
        shell: bash
        run: |
          set -euo pipefail
          qa="$RUNNER_TEMP/final-package-qa"
          python3 tools/qa/qa.py bind-final --input "$qa/input.json" \\
            --native-record "$qa/native-verification.json" \\
            --package-zip "$RUNNER_TEMP/package.zip" --record-zip "$RUNNER_TEMP/record.zip" \\
            --out "$qa/qa-subject.json"
          python3 tools/qa/qa.py plan --subject "$qa/qa-subject.json" \\
            --profile existing-final --out "$qa/qa-plan.json"

'''
        source = once(source, "      - name: Set up the Linux display and extract the package\n",
                      bind + "      - name: Set up the Linux display and extract the package\n")
        collect = '''      - name: Record existing package QA coverage (advisory, not publication authorization)
        if: always() && steps.qa-kit-plan.outcome == 'success'
        continue-on-error: true
        shell: bash
        run: |
          set -euo pipefail
          qa="$RUNNER_TEMP/final-package-qa"
          python3 tools/qa/qa.py collect-final --plan "$qa/qa-plan.json" \\
            --subject "$qa/qa-subject.json" --native-record "$qa/native-verification.json" \\
            --qa-root "$qa" --evidence-root "$qa" --out "$qa/qa-results.json"
          python3 tools/qa/qa.py gate --plan "$qa/qa-plan.json" --subject "$qa/qa-subject.json" \\
            --results "$qa/qa-results.json" --evidence-root "$qa" --out "$qa/qa-verdict.json"

'''
        return once(source, "      - name: Upload compact final package regression evidence\n",
                    collect + "      - name: Upload compact final package regression evidence\n")
    raise QAError(f"No approved transformation for {path}")


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo", type=Path, required=True); p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()
    pins = read_json(ROOT / "qa/source-pins.json")["floorpFiles"]
    files = ["deno.json", "tools/test-final-web-panel-ua.py", "tools/test-final-context-menu.py", ".github/workflows/validate-final-package-qa.yml"]
    chunks = []
    for name in files:
        path = args.repo / name
        require(path.is_file() and not path.is_symlink(), f"Missing/linked source: {path}")
        if name in pins:
            require(blob_sha(path) == pins[name], f"Source drift: {name}; review and update the integration design rather than forcing the patch")
        before = path.read_text(encoding="utf-8")
        after = transform(name, before)
        chunks.extend(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                                          fromfile=f"a/{name}", tofile=f"b/{name}"))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("x", encoding="utf-8") as stream:
        stream.writelines(chunks)
    print(f"Review-only patch written: {args.out}. No source file or release setting was changed.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (QAError, OSError, ValueError) as exc:
        print(str(exc), file=sys.stderr); raise SystemExit(2)

# SPDX-License-Identifier: MPL-2.0
"""Synthetic-data unit/integration tests. These are NOT Floorp browser results."""
from __future__ import annotations
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile

TOOLS = Path(__file__).resolve().parents[1]
ROOT = TOOLS.parents[1]
sys.path.insert(0, str(TOOLS))
from core import (QAError, TARGETS, contained, digest, evaluate, evidence_entry, file_digest,
                  import_mozlog, loads, make_plan, read_json, result, subject_from_final, write_json)
from probes import normalize_report
from agent import validate_action
from propose_integration import once, transform
from runtime_tools import inventory, pack_bundle


def archive(path: Path, name: str, data: bytes) -> None:
    with zipfile.ZipFile(path, "w") as z:
        z.writestr(name, data)


class KitTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.addCleanup(self.temp.cleanup)
        self.package_zip, self.record_zip = self.root / "package.zip", self.root / "record.zip"
        archive(self.package_zip, TARGETS["linux/x86_64"][1], b"SYNTHETIC NONEXECUTABLE INSTALLER FIXTURE")
        package = {"id": 123, "name": TARGETS["linux/x86_64"][0], "digest": file_digest(self.package_zip)}
        self.native = {"schema_version": 2, "verification": {"status": "verified"},
          "floorp": {"repository": "Floorp-Projects/Floorp", "head_sha": "a" * 40, "workflow_run_id": 100},
          "target_key": "linux", "native_arch": "x86_64", "floorp_package": {
            "artifact_id": package["id"], "artifact_name": package["name"], "artifact_digest": package["digest"], "unsigned": False},
          "runtime": {"expected_build_id": "20261009000000", "head_sha": "b" * 40, "workflow_run_id": 50},
          "app_build_id": "20261009000000", "platform_build_id": "20261009000000", "firefox_version": "157.0.1",
          "build_id2": "019e43d1-29ff-7000-8000-000000000000"}
        archive(self.record_zip, "native-verification.json", json.dumps(self.native).encode())
        self.input = {"runId": 100, "floorpHead": "a" * 40, "floorpVersion": "12.20.1", "platform": "linux", "arch": "x86_64",
                      "unsigned": False, "package": package,
                      "record": {"id": 124, "name": "floorp-native-verification-linux-x86_64-v2", "digest": file_digest(self.record_zip)}}
        self.subject = self.bind()
        self.policy = read_json(ROOT / "qa/policies/baseline.json")
        self.plan = make_plan(self.subject, self.policy, "existing-final")
        self.raw = self.root / "raw.json"
        write_json(self.raw, {"synthetic": True})
        self.evidence = [evidence_entry(self.root, self.raw)]
        self.records = [result(self.plan, row["id"], "PASS", row["kind"], self.evidence, {"synthetic": True}) for row in self.plan["cases"]]

    def bind(self):
        return subject_from_final(self.input, self.native, self.package_zip, self.record_zip)

    def evaluate(self, records=None, plan=None):
        return evaluate(plan or self.plan, self.subject, self.policy, self.records if records is None else records, self.root)

    def rewrite_native(self):
        archive(self.record_zip, "native-verification.json", json.dumps(self.native).encode())
        self.input["record"]["digest"] = file_digest(self.record_zip)

    def log(self, events, tests=None):
        path = self.root / "mozlog.jsonl"
        path.write_text("".join(json.dumps(event) + "\n" for event in events))
        return import_mozlog(path, tests or ["browser_example.js"], self.root)

    def happy_events(self):
        return [{"action": "suite_start"}, {"action": "test_start", "test": "browser_example.js"},
                {"action": "test_status", "test": "browser_example.js", "subtest": "invariant", "status": "PASS"},
                {"action": "test_end", "test": "browser_example.js", "status": "OK"}, {"action": "suite_end"}]

    def probe_report(self, case="l2.web-panel-http"):
        identity = {"version": "157.0.1", "version2": "12.20.1", "floorpVersion": "12.20.1", "buildID2": self.native["build_id2"],
                    "appBuildID": "20261009000000", "platformBuildID": "20261009000000", "startupMode": "", "httpLoaderAllowed": False, "sandboxLevel": 4}
        return {"status": "passed", "nativeRecord": self.native, "hostProcessIdentity": {"verified": True, "pid": 99},
                "ownedHostPid": 99, "hostExitCode": -15, "cleanupRequestedSignal": 15,
                "identity": identity, "httpRequests": {"normal": ["SYNTHETIC-UA"]}, "checks": [{"key": "synthetic"}],
                "browserRegression": {"status": "passed", "identity": identity, "checks": [{"name": "synthetic"}]}}

    def test_subject_binds_two_archives(self):
        self.assertEqual(self.subject["target"], "linux/x86_64")
        self.assertTrue(self.subject["installer"]["digest"].startswith("sha256:"))

    def test_subject_changes_with_artifact_id(self):
        original = self.subject["id"]
        self.input["package"]["id"] = 222
        self.native["floorp_package"]["artifact_id"] = 222
        self.rewrite_native()
        self.assertNotEqual(original, self.bind()["id"])

    def test_reject_changed_archive(self):
        self.package_zip.write_bytes(b"tampered")
        with self.assertRaises(QAError): self.bind()

    def test_reject_record_substitution(self):
        self.native["build_id2"] = "foreign"
        with self.assertRaises(QAError): self.bind()

    def test_reject_boolean_run_id(self):
        self.input["runId"] = True
        with self.assertRaises(QAError): self.bind()

    def test_reject_invalid_target(self):
        self.input["arch"] = "arm64"
        with self.assertRaises(QAError): self.bind()

    def test_reject_mismatched_native_target(self):
        self.native["native_arch"] = "aarch64"; self.rewrite_native()
        with self.assertRaises(QAError): self.bind()

    def test_reject_inconsistent_build_id(self):
        self.native["platform_build_id"] = "20261008000000"; self.rewrite_native()
        with self.assertRaises(QAError): self.bind()

    def test_reject_invalid_calendar_build_id(self):
        self.native["runtime"]["expected_build_id"] = "20269999000000"; self.rewrite_native()
        with self.assertRaises(QAError): self.bind()

    def test_reject_extra_input_fields(self):
        self.input["approved"] = True
        with self.assertRaises(QAError): self.bind()

    def test_reject_unsigned_name_mismatch(self):
        self.input["unsigned"] = True
        with self.assertRaises(QAError): self.bind()

    def test_reject_extra_zip_members(self):
        with zipfile.ZipFile(self.package_zip, "a") as z: z.writestr("extra", b"bad")
        self.input["package"]["digest"] = file_digest(self.package_zip)
        self.native["floorp_package"]["artifact_digest"] = self.input["package"]["digest"]; self.rewrite_native()
        with self.assertRaises(QAError): self.bind()

    def test_duplicate_json_keys(self):
        with self.assertRaises(QAError): loads('{"status":"PASS","status":"FAIL"}')

    def test_nan_json(self):
        with self.assertRaises(QAError): loads('{"value":NaN}')

    def test_write_is_exclusive(self):
        with self.assertRaises(FileExistsError): write_json(self.raw, {"replacement": True})

    def test_path_escape(self):
        for path in ("../raw.json", "/etc/passwd", "a/../raw.json", "a\\raw.json"):
            with self.subTest(path=path), self.assertRaises(QAError): contained(self.root, path)

    @unittest.skipIf(os.name == "nt", "Symlink privileges depend on Windows worker configuration")
    def test_symlink_evidence(self):
        (self.root / "link.json").symlink_to(self.raw)
        with self.assertRaises(QAError): contained(self.root, "link.json")

    def test_plan_is_deterministic(self):
        self.assertEqual(self.plan, make_plan(self.subject, self.policy, "existing-final"))

    def test_existing_subset_cannot_authorize_publication(self):
        verdict = self.evaluate()
        self.assertEqual(verdict["status"], "PASS")
        self.assertFalse(verdict["publicationAuthorized"])
        self.assertEqual(verdict["scope"], "existing-final-subset")

    def test_missing_case_blocks(self):
        self.assertEqual(self.evaluate(self.records[:1])["status"], "BLOCK")

    def test_empty_results_blocks(self):
        self.assertEqual(self.evaluate([])["status"], "BLOCK")

    def test_skip_not_pass(self):
        self.records[0]["status"] = "SKIP"
        self.assertEqual(self.evaluate()["status"], "BLOCK")

    def test_retry_cannot_erase_failure(self):
        retry = copy.deepcopy(self.records[0]); retry["attempt"] = 2
        self.records[0]["status"] = "FAIL"; self.records.append(retry)
        self.assertEqual(self.evaluate()["status"], "BLOCK")

    def test_missing_attempt_history_blocks(self):
        self.records[0]["attempt"] = 2
        self.assertEqual(self.evaluate()["status"], "BLOCK")

    def test_duplicate_attempt_blocks(self):
        self.records.append(copy.deepcopy(self.records[0]))
        self.assertEqual(self.evaluate()["status"], "BLOCK")

    def test_foreign_subject_blocks(self):
        self.records[0]["subjectId"] = "sha256:" + "0" * 64
        self.assertEqual(self.evaluate()["status"], "BLOCK")

    def test_evidence_tampering_blocks(self):
        self.raw.write_text("changed")
        self.assertEqual(self.evaluate()["status"], "BLOCK")

    def test_wrong_evidence_kind_blocks(self):
        self.records[0]["kind"] = "native-input"
        self.assertEqual(self.evaluate()["status"], "BLOCK")

    def test_unplanned_case_blocks(self):
        self.records[0]["caseId"] = "not-planned"
        self.assertEqual(self.evaluate()["status"], "BLOCK")

    def test_reduced_plan_rejected_against_trusted_policy(self):
        reduced = copy.deepcopy(self.plan); reduced["cases"] = reduced["cases"][:1]
        reduced["id"] = digest({k: v for k, v in reduced.items() if k != "id"})
        with self.assertRaises(QAError): self.evaluate(plan=reduced)

    def test_readiness_remains_blocked_for_unimplemented_cases(self):
        plan = make_plan(self.subject, self.policy, "release-readiness")
        records = [result(plan, r["id"], "PASS", r["kind"], self.evidence, {"synthetic": True}) for r in plan["cases"]]
        verdict = evaluate(plan, self.subject, self.policy, records, self.root)
        self.assertEqual(verdict["status"], "BLOCK")
        self.assertTrue(any("Not onboarded" in reason for reason in verdict["reasons"]))

    def test_mozlog_happy(self):
        self.assertEqual(self.log(self.happy_events())["status"], "PASS")

    def test_mozlog_truncated(self):
        self.assertEqual(self.log(self.happy_events()[:-1])["status"], "INCOMPLETE")

    def test_mozlog_missing_test(self):
        self.assertEqual(self.log(self.happy_events(), ["browser_example.js", "missing.js"])["status"], "FAIL")

    def test_mozlog_unexpected_fail(self):
        rows = self.happy_events(); rows[2]["status"] = "FAIL"
        self.assertEqual(self.log(rows)["status"], "FAIL")

    def test_mozlog_expected_fail_does_not_hide_failure(self):
        rows = self.happy_events(); rows[2].update(status="FAIL", expected="FAIL")
        self.assertEqual(self.log(rows)["status"], "FAIL")

    def test_mozlog_unexpected_pass(self):
        rows = self.happy_events(); rows[2]["expected"] = "FAIL"
        self.assertEqual(self.log(rows)["status"], "FAIL")

    def test_mozlog_crash_blocks(self):
        rows = self.happy_events(); rows.insert(3, {"action": "crash"})
        self.assertEqual(self.log(rows)["status"], "FAIL")

    def test_mozlog_end_without_start(self):
        with self.assertRaises(QAError): self.log(self.happy_events()[2:])

    def test_mozlog_double_suite(self):
        with self.assertRaises(QAError): self.log(self.happy_events() * 2)

    def test_mozlog_unknown_test(self):
        rows = self.happy_events(); rows[1]["test"] = "unknown"
        with self.assertRaises(QAError): self.log(rows)

    def test_mozlog_unknown_status(self):
        rows = self.happy_events(); rows[2]["status"] = "all-good"
        with self.assertRaises(QAError): self.log(rows)

    def test_mozlog_test_after_end(self):
        rows = self.happy_events() + [{"action": "test_start", "test": "browser_example.js"}]
        with self.assertRaises(QAError): self.log(rows)

    def test_probe_valid_report(self):
        self.assertEqual(normalize_report(self.probe_report(), self.native, "12.20.1", "l2.web-panel-http")[0], "PASS")

    def test_probe_flasco_report(self):
        self.assertEqual(normalize_report(self.probe_report(), self.native, "12.20.1", "l2.fluent-flasco")[0], "PASS")

    def test_probe_missing_requests_rejected(self):
        report = self.probe_report(); report["httpRequests"] = {}
        with self.assertRaises(QAError): normalize_report(report, self.native, "12.20.1", "l2.web-panel-http")

    def test_probe_cleanup_failure_rejected(self):
        report = self.probe_report(); report["hostCleanupError"] = "orphan"
        with self.assertRaises(QAError): normalize_report(report, self.native, "12.20.1", "l2.web-panel-http")

    def test_probe_wrong_pid_rejected(self):
        report = self.probe_report(); report["ownedHostPid"] = 333
        with self.assertRaises(QAError): normalize_report(report, self.native, "12.20.1", "l2.web-panel-http")

    def test_probe_dev_loader_rejected(self):
        report = self.probe_report(); report["identity"]["httpLoaderAllowed"] = True
        with self.assertRaises(QAError): normalize_report(report, self.native, "12.20.1", "l2.web-panel-http")

    def test_probe_failed_result_not_success(self):
        report = self.probe_report(); report["status"] = "failed"
        self.assertEqual(normalize_report(report, self.native, "12.20.1", "l2.web-panel-http")[0], "FAIL")

    def test_action_allowlist(self):
        for action in ({"kind":"observe"},{"kind":"navigate","fixture":"counter"},{"kind":"click","target":"fixture.increment"}):
            self.assertEqual(validate_action(action), action)

    def test_action_rejects_arbitrary_code_url_extra_fields(self):
        bad = [{"kind":"eval","source":"true"},{"kind":"shell","command":"id"},
               {"kind":"navigate","fixture":"https://example.org"},{"kind":"click","target":"#urlbar"},
               {"kind":"observe","approved":True},{"kind":"click","target":[]},
               {"kind":"key","chord":"Alt+F4"}]
        for value in bad:
            with self.subTest(value=value), self.assertRaises(QAError): validate_action(value)

    def test_patch_requires_unique_anchor(self):
        with self.assertRaises(QAError): once("xx", "x", "y")

    def test_patch_deno_addition_is_valid_json(self):
        source = '{\n  "tasks": {\n    "test": "deno test"\n  }\n}\n'
        self.assertIn("qa", json.loads(transform("deno.json", source))["tasks"])

    def test_patch_wont_add_duplicate_task(self):
        with self.assertRaises(QAError): transform("deno.json", '{"tasks": {"qa":"exists"}}')

    def test_patch_flasco_preserves_runtime_comparison(self):
        source = 'require(identity["version"] == record["firefox_version"] == "157.0.1" and\n True, "msg")'
        changed = transform("tools/test-final-context-menu.py", source)
        self.assertIn('identity["version"] == record["firefox_version"] and', changed)
        compile(changed, "probe.py", "exec")

    def test_inventory_does_not_claim_eligibility(self):
        (self.root / "browser.toml").write_text('[DEFAULT]\nhead="head.js"\n["browser_a.js"]\nskip-if=["os == \'win\'"]\n')
        value = inventory(self.root)
        self.assertEqual(value["manifestCount"], 1)
        self.assertIsNone(value["eligibleCount"])
        self.assertEqual(value["manifests"][0]["state"], "discovered-unresolved")

    def test_cli_help(self):
        call = subprocess.run([sys.executable, str(TOOLS / "qa.py"), "--help"], capture_output=True, text=True)
        self.assertEqual(call.returncode, 0, call.stderr)
        self.assertIn("bind-final", call.stdout)

    def test_cli_actions_validation_end_to_end(self):
        output = self.root / "action-check.json"
        call = subprocess.run([sys.executable, str(TOOLS / "qa.py"), "check-actions", "--actions", str(ROOT / "qa/scenarios/counter-actions.json"), "--out", str(output)], capture_output=True, text=True)
        self.assertEqual(call.returncode, 0, call.stderr)
        self.assertEqual(read_json(output)["status"], "policy-valid-not-executed")

    def test_cli_gate_end_to_end(self):
        for name, data in (("subject",self.subject),("plan",self.plan),("results",self.records)):
            write_json(self.root/f"{name}.json",data)
        command=[sys.executable,str(TOOLS/'qa.py'),'gate','--subject',str(self.root/'subject.json'),'--plan',str(self.root/'plan.json'),
                 '--results',str(self.root/'results.json'),'--evidence-root',str(self.root),'--out',str(self.root/'verdict.json')]
        call=subprocess.run(command,capture_output=True,text=True)
        self.assertEqual(call.returncode,0,call.stderr)
        self.assertFalse(read_json(self.root/'verdict.json')["publicationAuthorized"])


class BundleTest(unittest.TestCase):
    def test_bundle_is_separate_and_deterministic(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); repo=root/'runtime'; repo.mkdir()
            subprocess.run(['git','init','-q',str(repo)],check=True)
            (repo/'tracked').write_text('source')
            subprocess.run(['git','-C',str(repo),'add','tracked'],check=True)
            subprocess.run(['git','-C',str(repo),'-c','user.name=QA Fixture','-c','user.email=qa@example.invalid','commit','-qm','synthetic'],check=True)
            sha=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
            materials=root/'materials';materials.mkdir(); (materials/'common.tests.zip').write_bytes(b'synthetic support archive')
            cfg=root/'mozconfig'; cfg.write_text('ac_add_options --enable-tests\n')
            ini=root/'application.ini'; ini.write_text('[App]\nBuildID=20261009000000\n')
            a=pack_bundle(repo,materials,['common.tests.zip'],sha,'linux/x86_64','20261009000000',cfg,ini,root/'a.zip')
            b=pack_bundle(repo,materials,['common.tests.zip'],sha,'linux/x86_64','20261009000000',cfg,ini,root/'b.zip')
            self.assertEqual(a['bundleDigest'],b['bundleDigest'])
            self.assertIn('not-yet-execution-validated',a['manifest']['capability'])
            cfg.write_text('ac_add_options --disable-tests\n')
            with self.assertRaises(QAError):
                pack_bundle(repo,materials,['common.tests.zip'],sha,'linux/x86_64','20261009000000',cfg,ini,root/'bad.zip')


if __name__ == '__main__': unittest.main()

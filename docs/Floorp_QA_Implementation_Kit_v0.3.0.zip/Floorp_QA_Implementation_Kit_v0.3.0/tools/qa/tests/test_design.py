# SPDX-License-Identifier: MPL-2.0
"""Design policy and product-plan negative tests; NOT runtime/browser tests."""
from __future__ import annotations
import copy
import json
from pathlib import Path
import subprocess
import sys
import unittest

TOOLS = Path(__file__).resolve().parents[1]
ROOT = TOOLS.parents[1]
sys.path.insert(0, str(TOOLS))
from design_contract import DesignError, validate
from core import QAError, digest, make_plan
import test_core

class DesignTest(unittest.TestCase):
    def setUp(self):
        self.policy = json.loads((ROOT/'qa/design/build-policy.json').read_text())
        self.graph = json.loads((ROOT/'qa/design/ci-graph.json').read_text())
        self.baseline = json.loads((ROOT/'qa/policies/baseline.json').read_text())
    def check(self):
        return validate(self.policy, self.graph, self.baseline)
    def reject(self):
        with self.assertRaises(DesignError): self.check()
    def node(self, name):
        return next(n for n in self.graph['nodes'] if n['id'] == name)
    def test_design_valid(self):
        result = self.check()
        self.assertEqual(result['status'],'DESIGN_VALID')
        self.assertFalse(result['publicationAuthorized'])
        self.assertFalse(result['buildExecuted'])
    def test_debug_tests_disabled(self):
        self.policy['profiles']['debug-qa']['testsCompilation']='disable'; self.reject()
    def test_debug_pgo_enabled(self):
        self.policy['profiles']['debug-qa']['pgo']=True; self.reject()
    def test_debug_pgo_mode_set(self):
        self.policy['profiles']['debug-qa']['pgoMode']='generate'; self.reject()
    def test_debug_tests_only_built_not_run(self):
        self.policy['profiles']['debug-qa']['runBroadUpstream']=False; self.reject()
    def test_generate_tests_disabled_globally(self):
        self.policy['profiles']['production-pgo-generate']['testsCompilation']='disable'; self.reject()
    def test_use_tests_forced_enabled(self):
        self.policy['profiles']['production-pgo-use']['testsCompilation']='enable'; self.reject()
    def test_heavy_upstream_in_pgo(self):
        self.policy['profiles']['production-pgo-use']['runBroadUpstream']=True; self.reject()
    def test_drop_profiling_workload(self):
        self.policy['productPackaging']['preservePgoProfilingWorkload']=False; self.reject()
    def test_package_tests_enabled(self):
        self.policy['productPackaging']['testsCompilation']='enable'; self.reject()
    def test_package_internal_driver(self):
        self.policy['productPackaging']['testDriver']='dev-loader'; self.reject()
    def test_package_early_artifact(self):
        self.policy['productPackaging']['requireFinalWorkflowOutputs']=False; self.reject()
    def test_missing_arm_target(self):
        self.policy['targets'].remove('linuxAarch64/aarch64'); self.reject()
    def test_duplicate_target(self):
        self.policy['targets'][-1]=self.policy['targets'][0]; self.reject()
    def test_exclude_non_pgo(self):
        self.policy['productQa']['includeNonPgoProduct']=False; self.reject()
    def test_unknown_origin_skip(self):
        self.policy['productQa']['unknownOrigin']='skip'; self.reject()
    def test_browser_tests_as_source(self):
        self.policy['sourceQa']['browserIndependentOnly']=False; self.reject()
    def test_unauthenticated_source_reuse(self):
        self.policy['sourceQa']['crossRunReuse']='latest-green'; self.reject()
    def test_force_debug_product_same_buildid(self):
        self.policy['runtimeQualification']['requireSameBuildIdAsProduct']=True; self.reject()
    def test_debug_replaces_product_qa(self):
        self.policy['runtimeQualification']['doesNotReplaceProductQa']=False; self.reject()
    def test_merge_test_support_into_primary(self):
        self.policy['testSupport']['separateArtifact']=False; self.reject()
    def test_claim_ci_applied(self):
        self.policy['implementation']='done'; self.reject()
    def test_local_gate_authorizes_release(self):
        self.policy['release']['localGateAuthorizesPublication']=True; self.reject()
    def test_manual_approval_disabled(self):
        self.policy['release']['manualApproval']=False; self.reject()
    def test_source_job_replicated(self):
        self.node('source-qa-once')['replicas']=4; self.reject()
    def test_cycle_assemble_qa(self):
        self.node('assemble-bundle')['needs'].append('package-qa'); self.reject()
    def test_unknown_dependency(self):
        self.node('package')['needs'].append('fake-done'); self.reject()
    def test_public_bypasses_approval(self):
        self.node('public-mutation')['needs']=['aggregate-qa']; self.reject()
    def test_package_bypasses_source(self):
        self.node('package')['needs']=['build-product-runtime']; self.reject()
    def test_pgo_depends_on_full_debug_suite(self):
        self.node('build-product-runtime')['needs'].append('qualify-debug-runtime'); self.reject()
    def test_agent_is_blocking_dependency(self):
        self.node('aggregate-qa')['needs'].append('agent-explore'); self.reject()
    def test_product_policy_has_l1(self):
        for name in ('release-readiness','production-package-readiness'):
            self.baseline['profiles'][name]['cases'][0]['layer']='L1'
        self.reject()
    def test_alias_is_consistent(self):
        self.assertEqual(self.baseline['profiles']['release-readiness'],self.baseline['profiles']['production-package-readiness'])
    def test_design_cli_has_no_build_side_effect_claim(self):
        result=subprocess.run([sys.executable,str(TOOLS/'design_contract.py')],capture_output=True,text=True,check=True)
        value=json.loads(result.stdout)
        self.assertFalse(value['ciModified'])
        self.assertEqual(len(value['nativeTargets']),5)

class ProductPlanSeparationTest(unittest.TestCase):
    def setUp(self):
        self.fixture=test_core.KitTest()
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
    def test_new_profile_l2_only(self):
        f=self.fixture
        plan=make_plan(f.subject,f.policy,'production-package-readiness')
        self.assertEqual(plan['scope'],'production-package-readiness')
        self.assertTrue(all(c['layer']=='L2' for c in plan['cases']))
    def test_old_name_is_same_cases_but_distinct_id(self):
        f=self.fixture
        old=make_plan(f.subject,f.policy,'release-readiness')
        new=make_plan(f.subject,f.policy,'production-package-readiness')
        self.assertEqual(old['cases'],new['cases'])
        self.assertNotEqual(old['id'],new['id'])
    def test_unsigned_product_readiness_rejected(self):
        f=self.fixture
        subject=copy.deepcopy(f.subject);subject['unsigned']=True
        subject['id']=digest({k:v for k,v in subject.items() if k!='id'})
        for name in ('release-readiness','production-package-readiness'):
            with self.subTest(profile=name):
                with self.assertRaises(QAError): make_plan(subject,f.policy,name)
    def test_l1_in_product_plan_rejected(self):
        f=self.fixture
        f.policy['profiles']['existing-final']['cases'][0]['layer']='L1'
        with self.assertRaises(QAError):make_plan(f.subject,f.policy,'existing-final')
    def test_mozilla_harness_mislabeled_l2_rejected(self):
        f=self.fixture
        f.policy['profiles']['existing-final']['cases'][0]['kind']='mozilla-harness'
        with self.assertRaises(QAError):make_plan(f.subject,f.policy,'existing-final')

if __name__ == '__main__': unittest.main()

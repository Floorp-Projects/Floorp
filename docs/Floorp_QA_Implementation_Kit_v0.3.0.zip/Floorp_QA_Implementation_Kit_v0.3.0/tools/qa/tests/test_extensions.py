# SPDX-License-Identifier: MPL-2.0
"""Additional host-only integration checks. No real browser or model calls."""
from __future__ import annotations
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

TOOLS = Path(__file__).resolve().parents[1]
ROOT = TOOLS.parents[1]
sys.path.insert(0, str(TOOLS))
from core import QAError, read_json, write_json
from agent import replay_actions
from probes import collect_standalone
import test_core


class ExtensionTest(unittest.TestCase):
    def setUp(self):
        self.fixture = test_core.KitTest(methodName='test_subject_binds_two_archives')
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)

    def test_preserve_probe_and_bundle_context(self):
        f=self.fixture
        f.input['probeHead']='b'*40
        f.input['sourceEligibility']={'phase':'awaiting-publication-approval','bundle':{'id':8,'name':'fixture','digest':'sha256:'+'c'*64},'publicationApprovalPerformed':False}
        s=f.bind()
        self.assertEqual(s['intakeContext']['sourceEligibility'],f.input['sourceEligibility'])
        self.assertEqual(s['intakeContext']['probeHead'],'b'*40)
        self.assertNotEqual(s['id'],f.subject['id'])

    def test_reject_malformed_probe_head(self):
        f=self.fixture;f.input['probeHead']='main'
        with self.assertRaises(QAError):f.bind()

    def test_recorded_replay_roundtrip(self):
        f=self.fixture;a=[{'kind':'observe'}]
        r={'schemaVersion':1,'subjectId':f.subject['id'],'status':'finding-or-environment-error','actions':a}
        self.assertEqual(replay_actions(r,f.subject['id']),a)

    def test_recorded_replay_rejects_foreign_subject(self):
        f=self.fixture
        with self.assertRaises(QAError):replay_actions({'schemaVersion':1,'subjectId':'wrong','status':'replay-complete','actions':[{'kind':'observe'}]},f.subject['id'])

    def test_recorded_replay_rejects_extra_fields(self):
        f=self.fixture
        with self.assertRaises(QAError):replay_actions({'schemaVersion':1,'subjectId':f.subject['id'],'status':'replay-complete','actions':[{'kind':'observe'}],'shell':'true'},f.subject['id'])

    def standalone(self,process=None,report=True):
        f=self.fixture;d=f.root/'standalone';d.mkdir()
        write_json(d/'process-result.json',process or {'status':'PASS','exitCode':0,'requiresWorkerDisposal':False})
        if report:write_json(d/'raw/run-001/report.json',f.probe_report())
        return collect_standalone(f.plan,f.subject,f.native,'l2.web-panel-http',d,f.root)

    def test_collect_standalone_success(self):
        records=self.standalone();self.assertEqual(records[0]['status'],'PASS');self.assertEqual(len(records[0]['evidence']),2)

    def test_collect_standalone_timeout_never_passes(self):
        records=self.standalone({'status':'TIMEOUT','exitCode':-15,'requiresWorkerDisposal':True},False)
        self.assertEqual(records[0]['status'],'TIMEOUT')

    def test_collect_standalone_missing_report(self):
        with self.assertRaises(QAError):self.standalone(report=False)

    def test_collect_standalone_exit_contradiction(self):
        with self.assertRaises(QAError):self.standalone({'status':'PASS','exitCode':1,'requiresWorkerDisposal':False})

    def test_installer_dry_run_apply_and_no_overwrite(self):
        # install.py is shipped at kit root, not installed into Floorp/tools/qa.
        # Installed checkout selftests exercise this only where the kit installer exists.
        installer=ROOT/'install.py'
        if not installer.is_file() or 'Add new toolkit files to a Floorp checkout. Dry-run by default, no overwrites.' not in installer.read_text(encoding='utf-8'):
            self.skipTest('Kit installer is not copied into Floorp checkout')
        with tempfile.TemporaryDirectory() as temp:
            repo=Path(temp)/'floorp';repo.mkdir();(repo/'tools').mkdir();(repo/'deno.json').write_text('{"tasks":{}}\n')
            command=[sys.executable,str(installer),'--repo',str(repo)]
            a=subprocess.run(command,capture_output=True,text=True);self.assertEqual(a.returncode,0,a.stderr)
            self.assertFalse((repo/'tools/qa').exists())
            a=subprocess.run(command+['--apply'],capture_output=True,text=True);self.assertEqual(a.returncode,0,a.stderr)
            self.assertTrue((repo/'tools/qa/qa.py').exists())
            self.assertEqual((repo/'deno.json').read_text(),'{"tasks":{}}\n')
            self.assertFalse((repo/'.github').exists())
            a=subprocess.run(command+['--apply'],capture_output=True,text=True);self.assertEqual(a.returncode,2)


class CampaignTest(unittest.TestCase):
    def setUp(self):
        import unittest.mock
        self.patch = unittest.mock.patch
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def run_campaign(self, fail_action=False, fail_cleanup=False, actions=None):
        from agent import execute_campaign
        class FakeDriver:
            def __init__(self, repo, browser, output, subject): output.mkdir()
            def observe(self): return {"synthetic": True}
            def execute(self, action):
                if fail_action: raise QAError("SYNTHETIC invariant failure")
                return self.observe()
            def close(self):
                if fail_cleanup: raise QAError("SYNTHETIC cleanup error")
        with self.patch("agent.Driver", FakeDriver):
            summary=execute_campaign(self.root,self.root/"unused",{"id":"sha256:"+"a"*64},self.root/"out",
                                     actions or [{"kind":"observe"}],2,10)
        return summary

    def test_campaign_replay_records_success_without_quality_pass(self):
        summary=self.run_campaign()
        self.assertEqual(summary["status"],"replay-complete")
        self.assertFalse(summary["releaseEvidence"])
        replay=read_json(self.root/"out/replay.json")
        self.assertEqual(replay["actions"],[{"kind":"observe"}])

    def test_campaign_failed_action_is_recorded(self):
        summary=self.run_campaign(fail_action=True)
        self.assertEqual(summary["status"],"finding-or-environment-error")
        events=[json.loads(line) for line in (self.root/"out/actions.jsonl").read_text().splitlines()]
        self.assertEqual([e["phase"] for e in events],["start","end"])
        self.assertEqual(events[-1]["status"],"failed")
        self.assertEqual(len(read_json(self.root/"out/replay.json")["actions"]),1)

    def test_campaign_cleanup_error_is_not_replay_success(self):
        summary=self.run_campaign(fail_cleanup=True)
        self.assertEqual(summary["status"],"cleanup-error")
        self.assertTrue(summary["requiresWorkerDisposal"])

    def test_browser_child_environment_drops_model_and_github_tokens(self):
        from probes import clean_environment
        with self.patch.dict("os.environ",{"QA_MODEL_API_KEY":"secret","GITHUB_TOKEN":"secret","SSH_AUTH_SOCK":"secret","PATH":"/bin"},clear=True):
            self.assertEqual(clean_environment(),{"PATH":"/bin"})


if __name__=='__main__':unittest.main()

# SPDX-License-Identifier: MPL-2.0
"""Inventory and package support material without touching release artifacts."""
from __future__ import annotations

import configparser
import hashlib
import os
import re
from datetime import datetime
import subprocess
import tomllib
import zipfile
from pathlib import Path

from core import SHA, TARGETS, contained, digest, file_digest, require


def inventory(runtime: Path) -> dict:
    root = runtime.resolve(strict=True)
    rows = []
    for current, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d != ".git" and not d.startswith("obj") and d not in ("node_modules", "target", ".venv"))
        for name in sorted(files):
            if name not in ("browser.toml", "xpcshell.toml", "mochitest.toml", "chrome.toml"):
                continue
            path = Path(current) / name
            require(not path.is_symlink(), "Manifest symlink not accepted")
            try:
                parsed = tomllib.loads(path.read_text(encoding="utf-8"))
            except (ValueError, UnicodeError) as exc:
                rows.append({"path": path.relative_to(root).as_posix(), "state": "parse-error", "error": str(exc)})
                continue
            tests = [key for key in parsed if key != "DEFAULT" and not key.startswith("include:")]
            rows.append({"path": path.relative_to(root).as_posix(), "digest": file_digest(path),
                         "kind": name, "listedTests": tests, "state": "discovered-unresolved",
                         "note": "Manifest conditions, head/support dependencies and generated tests must be resolved by the matching Mozilla harness."})
    return {"schemaVersion": 1, "manifests": rows, "manifestCount": len(rows),
            "webPlatform": {"present": (root / "testing/web-platform/tests").is_dir(),
                            "state": "use-matching-wpt-manifest-resolver"},
            "eligibleCount": None, "note": "Inventory is not a runnable test plan or coverage claim."}


def pack_bundle(runtime: Path, materials: Path, files: list[str], expected_sha: str,
                target: str, build_id: str, mozconfig: Path, application_ini: Path,
                output: Path) -> dict:
    require(SHA.fullmatch(expected_sha) is not None and target in TARGETS, "Bad runtime SHA/target")
    require(re.fullmatch(r"[0-9]{14}", build_id) is not None, "Invalid test BuildID")
    try:
        datetime.strptime(build_id, "%Y%m%d%H%M%S")
    except ValueError as exc:
        from core import QAError
        raise QAError("Test BuildID is not a calendar timestamp") from exc
    actual = subprocess.run(["git", "-C", str(runtime), "rev-parse", "HEAD"], capture_output=True, text=True, check=True).stdout.strip()
    require(actual == expected_sha, "Runtime checkout does not match selected source")
    config = configparser.ConfigParser(interpolation=None)
    config.read_string(application_ini.read_text(encoding="utf-8"))
    require(config.get("App", "BuildID") == build_id, "Support build's application.ini BuildID mismatch")
    lines = [line.strip() for line in mozconfig.read_text(encoding="utf-8").splitlines() if not line.lstrip().startswith("#")]
    require(not any("--disable-tests" in line or "--enable-artifact-builds" in line for line in lines),
            "Use a separate genuine test-enabled build, not the release artifact mozconfig")
    require(files and len(files) == len(set(files)), "No or duplicate support materials")
    paths = [(name, contained(materials, name)) for name in sorted(files)]
    require(all(name != "qa-test-bundle.json" for name, _ in paths), "Reserved bundle manifest name")
    patch = subprocess.run(["git", "-C", str(runtime), "diff", "--binary", "HEAD"], capture_output=True, check=True).stdout
    untracked = subprocess.run(["git", "-C", str(runtime), "ls-files", "--others", "--exclude-standard", "-z"], capture_output=True, check=True).stdout
    require(not untracked, "Untracked source files must be committed or explicitly excluded before a test-support build")
    manifest = {"schemaVersion": 1, "runtimeHead": actual, "target": target, "buildId": build_id,
                "mozconfigDigest": file_digest(mozconfig), "applicationIniDigest": file_digest(application_ini),
                "workingPatchDigest": "sha256:" + hashlib.sha256(patch).hexdigest(),
                "capability": "support-materials-not-yet-execution-validated",
                "files": [{"path": name, "digest": file_digest(path), "bytes": path.stat().st_size,
                           "mode": "0755" if path.stat().st_mode & 0o111 else "0644"} for name, path in paths]}
    require(not output.exists(), "Bundle output exists")
    output.parent.mkdir(parents=True, exist_ok=True)
    import json
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        def put(name: str, data: bytes) -> None:
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
        put("qa-test-bundle.json", (json.dumps(manifest, sort_keys=True, indent=2) + "\n").encode())
        for name, path in paths:
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            mode = next(item["mode"] for item in manifest["files"] if item["path"] == name)
            info.external_attr = (0o100000 | int(mode, 8)) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            with path.open("rb") as source, archive.open(info, "w", force_zip64=True) as dest:
                import shutil
                shutil.copyfileobj(source, dest, length=1024 * 1024)
            require(file_digest(path) == next(item["digest"] for item in manifest["files"] if item["path"] == name), "Support material changed while archiving")
    return {"manifest": manifest, "bundleDigest": file_digest(output), "manifestDigest": digest(manifest),
            "note": "Upload as a separate artifact. Do not add to the strict Runtime primary artifact."}

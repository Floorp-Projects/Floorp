// SPDX-License-Identifier: MPL-2.0
// Deno convenience wrapper; the standalone Python CLI works without Deno.
import { fileURLToPath } from "node:url";
const python = Deno.build.os === "windows" ? "python" : "python3";
const child = new Deno.Command(python, {
  args: [fileURLToPath(new URL("./qa.py", import.meta.url)), ...Deno.args],
  stdin: "inherit", stdout: "inherit", stderr: "inherit",
}).spawn();
Deno.exit((await child.status).code);

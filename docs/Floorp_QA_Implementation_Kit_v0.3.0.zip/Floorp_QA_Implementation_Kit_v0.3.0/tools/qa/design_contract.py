#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Check the Debug/Product DESIGN contracts. No build, CI, or publication occurs."""
from __future__ import annotations
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TARGETS = {"windows/x86_64", "linux/x86_64", "linuxAarch64/aarch64", "mac/x86_64", "mac/aarch64"}

class DesignError(ValueError):
    """A document/plan contradicts the adopted design."""

def require(condition: bool, message: str) -> None:
    if not condition:
        raise DesignError(message)

def exact(value: object, keys: tuple[str, ...], path: str) -> dict:
    require(type(value) is dict and set(value) == set(keys), f"{path}: invalid fields")
    return value

def validate(policy: dict, graph: dict, baseline: dict) -> dict:
    exact(policy, ("schemaVersion", "designVersion", "mode", "profiles", "legacyDebugPgo", "productPackaging",
                   "sourceQa", "productQa", "targets", "runtimeQualification", "testSupport", "release", "implementation"), "build-policy")
    require(type(policy["schemaVersion"]) is int and policy["schemaVersion"] == 1, "Unsupported schema")
    require(policy["designVersion"] == "0.3.0" and policy["mode"] == "design-only", "Not a 0.3 design contract")
    require(policy["implementation"] == "profiles-and-ci-not-applied", "Do not claim CI implementation")
    profiles = exact(policy["profiles"], ("debug-qa", "production-pgo-generate", "production-pgo-use", "production-opt"), "profiles")
    expected = {
        "debug-qa": (True, False, "none", "enable", True),
        "production-pgo-generate": (False, True, "generate", "preserve", False),
        "production-pgo-use": (False, True, "use", "preserve", False),
        "production-opt": (False, False, "none", "preserve", False),
    }
    fields = ("debug", "pgo", "pgoMode", "testsCompilation", "runBroadUpstream")
    for name, values in expected.items():
        item = exact(profiles[name], fields, name)
        for key, value in zip(fields, values):
            require(type(item[key]) is type(value) and item[key] == value, f"{name}.{key}: violates adopted profile")
    require(policy["legacyDebugPgo"] == "not-canonical-qa", "Debug+PGO is not canonical Debug QA")
    exact_values = {
        "productPackaging": {"artifactBuild":True,"testsCompilation":"disable","testDriver":"external","preservePgoProfilingWorkload":True,"requireFinalWorkflowOutputs":True},
        "sourceQa": {"initialScope":"once-per-package-run","browserIndependentOnly":True,"crossRunReuse":"off-until-authenticated-complete-key"},
        "productQa": {"scope":"once-per-final-artifact-native-target","testOrigin":"floorp","unknownOrigin":"error","includeNonPgoProduct":True,"requiresNormalSandbox":True},
        "runtimeQualification": {"subjectRelation":"source-compatible-not-artifact-identical","requireSameBuildIdAsProduct":False,"reusableForFloorpOnlyChange":True,"requiresAuthenticatedCompatibility":True,"doesNotReplaceProductQa":True},
        "testSupport": {"separateArtifact":True,"sameDebugBuild":True},
        "release": {"bundleSchema":"existing-v2-unchanged","qaSidecar":"separate","manualApproval":True,"publicVerifier":True,"agentAdvisory":True,"localGateAuthorizesPublication":False},
    }
    for key, expectation in exact_values.items():
        item = exact(policy[key], tuple(expectation), key)
        for field, value in expectation.items():
            require(type(item[field]) is type(value) and item[field] == value, f"{key}.{field}: violates adopted boundary")
    targets = policy["targets"]
    require(type(targets) is list and all(type(x) is str for x in targets) and
            len(targets) == len(TARGETS) and set(targets) == TARGETS, "Five distinct native targets required")

    exact(graph, ("schemaVersion", "designVersion", "mode", "nodes"), "graph")
    require(type(graph["schemaVersion"]) is int and graph["schemaVersion"] == 1 and
            graph["designVersion"] == "0.3.0" and graph["mode"] == "target-design-not-actions-yaml", "Invalid graph metadata")
    require(type(graph["nodes"]) is list and bool(graph["nodes"]), "Empty graph")
    nodes = {}
    for node in graph["nodes"]:
        exact(node, ("id", "needs", "replicas", "role"), "node")
        require(type(node["id"]) is str and node["id"] and node["id"] not in nodes, "Invalid or duplicate node")
        require(type(node["needs"]) is list and all(type(x) is str for x in node["needs"]) and
                len(node["needs"]) == len(set(node["needs"])), "Invalid or duplicate edges")
        require(type(node["replicas"]) is int and node["replicas"] > 0, "Invalid replica count")
        require(type(node["role"]) is str, "Invalid role")
        nodes[node["id"]] = node
    for node in nodes.values():
        require(set(node["needs"]).issubset(nodes), "Unknown dependency")
    visiting, done, order = set(), set(), []
    def visit(name: str) -> None:
        require(name not in visiting, "Dependency cycle")
        if name in done:
            return
        visiting.add(name)
        for parent in nodes[name]["needs"]:
            visit(parent)
        visiting.remove(name)
        done.add(name)
        order.append(name)
    for name in nodes:
        visit(name)
    roles = {
        "resolve-debug-qa": (1,"resolve"), "build-debug-runtime":(5,"debug-build"),
        "run-debug-upstream":(5,"L1"), "qualify-debug-runtime":(1,"qualification"),
        "resolve-product-runtime":(1,"resolve"), "build-product-runtime":(4,"existing-pgo-or-opt"),
        "source-qa-once":(1,"source"), "package":(4,"package"), "native-verify":(5,"native"),
        "assemble-bundle":(1,"assemble"), "draft-staging":(1,"draft"), "package-qa":(5,"L2"),
        "aggregate-qa":(1,"gate"), "manual-approval":(1,"approval"), "public-mutation":(1,"public"),
        "agent-explore":(5,"advisory-L3"),
    }
    require(set(nodes) == set(roles), "Graph nodes must match reviewed topology")
    for name, (replicas, role) in roles.items():
        require(nodes[name]["replicas"] == replicas and nodes[name]["role"] == role, f"{name}: wrong role/replicas")
    edges = {
        "resolve-debug-qa": set(), "build-debug-runtime":{"resolve-debug-qa"},
        "run-debug-upstream":{"build-debug-runtime"}, "qualify-debug-runtime":{"run-debug-upstream"},
        "resolve-product-runtime":set(), "build-product-runtime":{"resolve-product-runtime"},
        "source-qa-once":set(), "package":{"source-qa-once","build-product-runtime"},
        "native-verify":{"package"}, "assemble-bundle":{"native-verify"},
        "draft-staging":{"assemble-bundle"}, "package-qa":{"assemble-bundle"},
        "aggregate-qa":{"package-qa","qualify-debug-runtime","source-qa-once","assemble-bundle"},
        "manual-approval":{"aggregate-qa","draft-staging"},
        "public-mutation":{"manual-approval","aggregate-qa"}, "agent-explore":{"package"},
    }
    for name, deps in edges.items():
        require(set(nodes[name]["needs"]) == deps, f"{name}: dependency boundary changed")

    exact(baseline, ("schemaVersion", "profiles"), "product baseline")
    require(baseline["schemaVersion"] == 1 and type(baseline["profiles"]) is dict, "Invalid baseline")
    require(set(baseline["profiles"]) == {"existing-final","release-readiness","production-package-readiness"}, "Product profiles drifted")
    require(baseline["profiles"]["release-readiness"] == baseline["profiles"]["production-package-readiness"], "Alias differs")
    for name, profile in baseline["profiles"].items():
        require(type(profile["cases"]) is list and bool(profile["cases"]), "Empty product suite")
        for row in profile["cases"]:
            require(row["layer"] == "L2" and row["kind"] != "mozilla-harness", "Debug L1 must not bind a product Subject")
            if name != "existing-final":
                require(profile["scope"] == "production-package-readiness", "Readiness scope incorrect")
                require(len(row["targets"]) == 5 and set(row["targets"]) == TARGETS, "Product readiness lost a target")
                require(row["signedOnly"] is True, "Production readiness must reject unsigned validation")
    return {"schemaVersion":1,"status":"DESIGN_VALID","designVersion":"0.3.0",
            "topologicalOrder":order,"nativeTargets":sorted(TARGETS),
            "buildExecuted":False,"ciModified":False,"publicationAuthorized":False}

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    args = parser.parse_args()
    root = args.root.resolve(strict=True)
    def read(name: str) -> dict:
        value = json.loads((root / name).read_text(encoding="utf-8"))
        require(type(value) is dict, f"{name}: expected object")
        return value
    result = validate(read("qa/design/build-policy.json"),read("qa/design/ci-graph.json"),read("qa/policies/baseline.json"))
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (DesignError,OSError,KeyError,TypeError,ValueError) as error:
        print(json.dumps({"status":"DESIGN_INVALID","error":str(error)},ensure_ascii=False))
        raise SystemExit(2)

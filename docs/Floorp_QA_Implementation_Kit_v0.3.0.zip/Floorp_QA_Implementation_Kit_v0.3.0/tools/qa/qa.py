#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Floorp QA toolkit. All publication-changing operations are intentionally absent."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

from core import (BASELINE, QAError, TARGETS, blob_sha, digest, evaluate, file_digest, import_mozlog,
                  make_plan, read_json, require, result, subject_from_final, validate_plan, write_json)
from probes import collect_reports, collect_standalone, clean_environment, run_existing_probe

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_POLICY = ROOT / "qa/policies/baseline.json"


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--version", action="version", version="Floorp QA toolkit 0.3.0 (Debug/Product design revision; advisory tools)")
    sub = p.add_subparsers(dest="command", required=True)
    def add(name, help_text):
        return sub.add_parser(name, help=help_text)
    x = add("doctor", "Read-only source-contract audit (not a browser test)")
    x.add_argument("--repo", type=Path, required=True); x.add_argument("--out", type=Path, required=True)
    x = add("bind-final", "Bind existing authenticated input/native record to exact downloaded ZIPs")
    for flag in ("input", "native-record", "package-zip", "record-zip", "out"):
        x.add_argument("--" + flag, type=Path, required=True)
    x = add("plan", "Create deterministic per-target plan")
    x.add_argument("--subject", type=Path, required=True); x.add_argument("--policy", type=Path, default=DEFAULT_POLICY)
    x.add_argument("--profile", choices=("existing-final", "release-readiness", "production-package-readiness"), required=True)
    x.add_argument("--out", type=Path, required=True)
    x = add("collect-final", "Import exact-version reports; unimplemented cases remain missing")
    for flag in ("plan", "subject", "native-record", "qa-root", "evidence-root", "out"):
        x.add_argument("--" + flag, type=Path, required=True)
    x = add("collect-probe", "Import standalone run-probe output and its process exit")
    for flag in ("plan", "subject", "native-record", "run-dir", "evidence-root", "out"):
        x.add_argument("--" + flag, type=Path, required=True)
    x.add_argument("--case", choices=("l2.web-panel-http", "l2.fluent-flasco"), required=True)
    x = add("gate", "Evaluate evidence; this command NEVER approves a public release")
    for flag in ("plan", "subject", "evidence-root", "out"):
        x.add_argument("--" + flag, type=Path, required=True)
    x.add_argument("--policy", type=Path, default=DEFAULT_POLICY)
    x.add_argument("--results", type=Path, nargs="+", required=True)
    x = add("check-mozlog", "Validate one non-repeat Mozilla suite against resolved test IDs")
    for flag in ("raw", "tests", "evidence-root", "out"):
        x.add_argument("--" + flag, type=Path, required=True)
    x.add_argument("--exit-code", type=int, required=True)
    x = add("inventory-runtime", "Inventory manifests without guessing eligibility")
    x.add_argument("--runtime-dir", type=Path, required=True); x.add_argument("--out", type=Path, required=True)
    x = add("pack-test-bundle", "Create a SEPARATE support-material artifact from a genuine test build")
    for flag in ("runtime-dir", "materials", "mozconfig", "application-ini", "out"):
        x.add_argument("--" + flag, type=Path, required=True)
    x.add_argument("--file", action="append", required=True)
    x.add_argument("--runtime-sha", required=True); x.add_argument("--target", choices=sorted(TARGETS), required=True)
    x.add_argument("--build-id", required=True)
    x = add("run-probe", "Run an existing POSIX package probe on a disposable worker")
    for flag in ("repo", "browser", "native-record", "out"):
        x.add_argument("--" + flag, type=Path, required=True)
    x.add_argument("--case", choices=("l2.web-panel-http", "l2.fluent-flasco"), required=True)
    x.add_argument("--floorp-version", required=True); x.add_argument("--timeout", type=int, default=600)
    x = add("check-actions", "Validate restricted Agent actions without launching a browser")
    x.add_argument("--actions", type=Path, required=True); x.add_argument("--out", type=Path, required=True)
    for name in ("replay", "agent-stdio"):
        x = add(name, "Run restricted automation UI; never native/full-coverage evidence")
        for flag in ("repo", "browser", "subject", "out"):
            x.add_argument("--" + flag, type=Path, required=True)
        x.add_argument("--max-actions", type=int, default=50); x.add_argument("--seconds", type=int, default=300)
        if name == "replay":
            x.add_argument("--actions", type=Path, required=True)
    return p


def main(argv: list[str] | None = None) -> int:
    require(sys.version_info >= (3, 12), "Python 3.12+ required")
    args = parser().parse_args(argv)
    command = args.command
    code = 0
    if command == "doctor":
        pins = read_json(ROOT / "qa/source-pins.json")
        rows = []
        for path, sha in pins["floorpFiles"].items():
            file = args.repo / path
            actual = blob_sha(file) if file.is_file() and not file.is_symlink() else None
            rows.append({"path": path, "expectedBlob": sha, "actualBlob": actual,
                         "status": "MATCH" if actual == sha else "MISSING" if actual is None else "DRIFT"})
        head = subprocess.run(["git", "-C", str(args.repo), "rev-parse", "HEAD"], text=True, capture_output=True)
        value = {"schemaVersion": 1, "baseline": BASELINE, "actualHead": head.stdout.strip() if head.returncode == 0 else None,
                 "files": rows, "status": "MATCH" if all(r["status"] == "MATCH" for r in rows) else "REVIEW_REQUIRED",
                 "note": "Worktree blob audit, not CI execution. CRLF conversions also count as drift; review before updating pins."}
        code = 0 if value["status"] == "MATCH" else 1
    elif command == "bind-final":
        value = subject_from_final(read_json(args.input), read_json(args.native_record), args.package_zip, args.record_zip)
    elif command == "plan":
        value = make_plan(read_json(args.subject), read_json(args.policy), args.profile)
    elif command == "collect-final":
        plan = read_json(args.plan); validate_plan(plan)
        subject = read_json(args.subject)
        require(plan["subjectId"] == subject["id"], "Plan subject mismatch")
        value = collect_reports(plan, subject, read_json(args.native_record), args.qa_root, args.evidence_root)
    elif command == "collect-probe":
        plan, subject = read_json(args.plan), read_json(args.subject)
        validate_plan(plan)
        require(plan["subjectId"] == subject["id"], "Plan subject mismatch")
        value = collect_standalone(plan, subject, read_json(args.native_record), args.case, args.run_dir, args.evidence_root)
    elif command == "gate":
        records = []
        for path in args.results:
            block = read_json(path)
            require(type(block) is list, "Results must be an array")
            records.extend(block)
        value = evaluate(read_json(args.plan), read_json(args.subject), read_json(args.policy), records, args.evidence_root)
        code = 0 if value["status"] == "PASS" else 1
    elif command == "check-mozlog":
        tests = read_json(args.tests)
        require(type(tests) is list and all(type(t) is str for t in tests), "Resolved Mozilla tests must be a string array")
        value = import_mozlog(args.raw, tests, args.evidence_root)
        value["exitCode"] = args.exit_code
        if args.exit_code != 0:
            value["status"] = "FAIL"; value["issues"].append(f"Harness process exit code {args.exit_code}")
        code = 0 if value["status"] == "PASS" else 1
    elif command == "inventory-runtime":
        from runtime_tools import inventory
        value = inventory(args.runtime_dir)
        code = 0 if value["manifestCount"] > 0 and not any(r["state"] == "parse-error" for r in value["manifests"]) else 1
    elif command == "pack-test-bundle":
        from runtime_tools import pack_bundle
        value = pack_bundle(args.runtime_dir, args.materials, args.file, args.runtime_sha, args.target,
                            args.build_id, args.mozconfig, args.application_ini, args.out)
        print(json.dumps(value, ensure_ascii=False, indent=2))
        return 0
    elif command == "run-probe":
        value = run_existing_probe(args.repo, args.case, args.browser, args.native_record, args.floorp_version, args.out, args.timeout)
        write_json(args.out / "process-result.json", value)
        print(json.dumps(value, ensure_ascii=False))
        return 0 if value["status"] == "PASS" else 1
    elif command == "check-actions":
        from agent import validate_action
        actions = read_json(args.actions)
        require(type(actions) is list and 0 < len(actions) <= 500, "Expect 1..500 actions")
        value = {"schemaVersion": 1, "actions": [validate_action(a) for a in actions], "status": "policy-valid-not-executed"}
    elif command in ("replay", "agent-stdio"):
        from agent import execute_campaign, replay_actions
        subject = read_json(args.subject)
        actions = replay_actions(read_json(args.actions), subject["id"]) if command == "replay" else None
        require(not args.out.exists(), "Use a new campaign output directory")
        # This CLI process is the dedicated worker, not the model controller.
        # Existing HostProcess inherits os.environ; strip credentials before it
        # is constructed. An OS/VM boundary is still required for HOME/network.
        safe_env = clean_environment()
        if os.environ.get("QA_DISPOSABLE_WORKER") == "1":
            safe_env["QA_DISPOSABLE_WORKER"] = "1"
        os.environ.clear()
        os.environ.update(safe_env)
        value = execute_campaign(args.repo, args.browser, subject, args.out, actions, args.max_actions, args.seconds)
        print(json.dumps(value, ensure_ascii=False), file=sys.stderr)
        return 0 if value["status"] in ("replay-complete", "input-ended", "budget-exhausted") else 1
    else:
        raise QAError("Unsupported command")
    write_json(args.out, value)
    print(json.dumps({"command": command, "output": str(args.out), "exitCode": code}, ensure_ascii=False))
    return code


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (QAError, OSError, KeyError, TypeError, ValueError, subprocess.SubprocessError) as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(2)

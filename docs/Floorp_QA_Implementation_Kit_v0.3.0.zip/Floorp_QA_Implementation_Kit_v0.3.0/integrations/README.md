# Integration files — 0.3.0

`qa-toolkit-selftest.yml` はレビュー後に配置するhost test専用workflow。install.pyは自動配置しない。新しいdesign contract selftestもunittest discoveryから実行する。

`propose_integration.py` は既存final QAの２probeとCLIをadvisory接続する補助であり、Debug tests flag/source-once/packaged全suite/正式publisher gateの実装ではない。source blob不一致で停止し、強制適用しない。

新CIはdocs/10/11/12とQA3-01～09に従って実装する。既存v2 artifact/provenance、署名・公証、manual approvalを維持する。製品packageの--disable-testsは初期導入で維持し、Mozilla L1はDebug Runtimeに分離する。未検証の汎用YAMLをそのまま本番へ配置する方式は採用しない。

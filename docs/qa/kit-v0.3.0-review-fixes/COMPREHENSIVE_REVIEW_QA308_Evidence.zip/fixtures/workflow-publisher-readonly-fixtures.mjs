// Execute only the two source-extracted read-only github-script gates with mocks.
import { readFileSync, writeFileSync } from "node:fs";

const snippets = JSON.parse(readFileSync(new URL("../evidence/workflow-readonly-gate-scripts.json", import.meta.url), "utf8"));
const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
const checks = [];
const head = "a".repeat(40);
const digest = "sha256:" + "b".repeat(64);
const baseline = {
  context: { repo: { owner: "Floorp-Projects", repo: "Floorp" }, runId: 123 },
  env: { SOURCE_WORKFLOW_RUN_ID: "123", PUBLISH_PPA: "true", BUNDLE_ARTIFACT: JSON.stringify({ name: "floorp-release-bundle-v2", id: 501, digest }) },
  run: { id: 123, repository: { full_name: "Floorp-Projects/Floorp" }, status: "in_progress", conclusion: null, head_sha: head },
  artifacts: [{ id: 501, name: "floorp-release-bundle-v2", digest, expired: false, size_in_bytes: 10 }],
};
const assetNames = ["floorp-12.20.1.deb", "floorp-stub.installer.exe", "floorp-linux-aarch64-full.mar", "floorp-linux-aarch64.tar.xz", "floorp-linux-x86_64-full.mar", "floorp-linux-x86_64.tar.xz", "floorp-mac-universal-full.mar", "floorp-macOS-universal.dmg", "floorp-windows-x86_64-full.mar", "floorp-windows-x86_64.installer.exe", "hashes.txt", "linux-aarch64-meta.json", "linux-meta.json", "mac-meta.json", "release-manifest-set-v2.json", "win-meta.json"];
const publicBaseline = {
  context: baseline.context,
  env: { RELEASE_TAG: "v12.20.1", FLOORP_HEAD_SHA: head, FLOORP_VERSION: "12.20.1" },
  release: { draft: false, prerelease: false, tag_name: "v12.20.1", target_commitish: head, assets: assetNames.map((name) => ({ name, size: 1 })) },
  tag: { type: "commit", sha: head },
};
async function execute(which, input) {
  const calls = [];
  const outputs = {};
  const read = (route, data) => { calls.push(route); return Promise.resolve({ data }); };
  const github = {
    rest: {
      actions: { getWorkflowRun: () => read("GET workflow run", input.run), listWorkflowRunArtifacts() { throw new Error("pagination stub should be used"); } },
      repos: { getReleaseByTag: () => read("GET release by tag", input.release) },
      git: { getRef: () => read("GET ref", { object: input.tag }), getTag: () => read("GET annotated tag", { object: input.annotatedTarget ?? input.tag }) },
    },
    paginate: () => { calls.push("GET artifact pages"); return Promise.resolve(input.artifacts); },
  };
  const core = { setOutput: (name, value) => outputs[name] = value, setFailed: (message) => { throw new Error(message); } };
  const previous = {};
  for (const [name, value] of Object.entries(input.env)) { previous[name] = process.env[name]; process.env[name] = value; }
  try {
    await new AsyncFunction("github", "context", "core", snippets[which].script)(github, input.context, core);
    return { accepted: true, calls, outputs };
  } catch (error) {
    return { accepted: false, calls, reason: error.message };
  } finally {
    for (const [name, value] of Object.entries(previous)) { if (value === undefined) delete process.env[name]; else process.env[name] = value; }
  }
}
async function test(which, name, mutate, accepted) {
  const input = structuredClone(which === "prepare_release" ? baseline : publicBaseline);
  mutate(input);
  const result = await execute(which, input);
  checks.push({ name, passed: result.accepted === accepted, expectedAccepted: accepted, result });
}
await test("prepare_release", "exact current-run production bundle accepted", () => {}, true);
for (const [name, mutate] of [
  ["noncanonical source run", (i) => i.env.SOURCE_WORKFLOW_RUN_ID = "00123"],
  ["unsafe source run integer", (i) => i.env.SOURCE_WORKFLOW_RUN_ID = "99999999999999999"],
  ["prior source run cannot publish PPA", (i) => i.context.runId = 124],
  ["arbitrary bundle JSON keys", (i) => i.env.BUNDLE_ARTIFACT = JSON.stringify({ name: "floorp-release-bundle-v2", id: 501, digest, pass: true })],
  ["validation-only bundle", (i) => i.env.BUNDLE_ARTIFACT = JSON.stringify({ name: "floorp-release-bundle-v2-validation", id: 501, digest })],
  ["invalid bundle ID", (i) => i.env.BUNDLE_ARTIFACT = JSON.stringify({ name: "floorp-release-bundle-v2", id: 0, digest })],
  ["invalid bundle digest", (i) => i.env.BUNDLE_ARTIFACT = JSON.stringify({ name: "floorp-release-bundle-v2", id: 501, digest: "latest-pass" })],
  ["wrong source repository", (i) => i.run.repository.full_name = "other/repo"],
  ["wrong source run ID", (i) => i.run.id = 124],
  ["invalid source head", (i) => i.run.head_sha = "main"],
  ["current source unexpected status", (i) => i.run.status = "cancelled"],
  ["missing exact bundle artifact", (i) => i.artifacts = []],
  ["ambiguous same-name bundle", (i) => i.artifacts.push({ ...i.artifacts[0], id: 502 })],
  ["changed bundle ID", (i) => i.artifacts[0].id = 502],
  ["changed bundle digest", (i) => i.artifacts[0].digest = "sha256:" + "c".repeat(64)],
  ["expired bundle", (i) => i.artifacts[0].expired = true],
  ["empty bundle", (i) => i.artifacts[0].size_in_bytes = 0],
]) await test("prepare_release", name, mutate, false);
await test("prepare_release", "exact completed successful prior source run accepted for non-PPA", (i) => { i.env.PUBLISH_PPA = "false"; i.context.runId = 124; i.run.status = "completed"; i.run.conclusion = "success"; }, true);
await test("prepare_release", "prior failed source run rejected", (i) => { i.env.PUBLISH_PPA = "false"; i.context.runId = 124; i.run.status = "completed"; i.run.conclusion = "failure"; }, false);
await test("release_check", "exact public stable release identity accepted before byte comparison", () => {}, true);
for (const [name, mutate] of [
  ["unpublished draft rejected", (i) => i.release.draft = true],
  ["prerelease rejected", (i) => i.release.prerelease = true],
  ["wrong resolved release tag commit", (i) => i.tag.sha = "c".repeat(40)],
  ["noncommit release tag target", (i) => i.tag.type = "tree"],
  ["excessive annotated tag depth", (i) => { i.tag.type = "tag"; i.annotatedTarget = { type: "tag", sha: head }; }],
  ["wrong public release tag", (i) => i.release.tag_name = "v12.20.0"],
  ["wrong public release target", (i) => i.release.target_commitish = "d".repeat(40)],
  ["missing public release asset", (i) => i.release.assets.pop()],
  ["extra public release asset", (i) => i.release.assets.push({ name: "unexpected", size: 1 })],
  ["duplicate public release asset", (i) => i.release.assets.push({ ...i.release.assets[0] })],
  ["empty public release asset", (i) => i.release.assets[0].size = 0],
]) await test("release_check", name, mutate, false);
const result = { scope: "two exact source-extracted read-only github-script gates with mock GET methods; no mutation API exposed", network: false, credentials: false, publication: false, checks, passed: checks.filter((c) => c.passed).length, failed: checks.filter((c) => !c.passed).length };
writeFileSync(new URL("../evidence/workflow-publisher-readonly-results.json", import.meta.url), JSON.stringify(result, null, 2) + "\n");
console.log(JSON.stringify({ passed: result.passed, failed: result.failed, results: "evidence/workflow-publisher-readonly-results.json" }));
process.exitCode = result.failed ? 1 : 0;

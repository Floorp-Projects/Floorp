"""Read-only QA review fixtures; no browser, build, network, or source writes."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
from unittest import mock

REVIEW = Path('/workspace/qa-review-v030/review-qa308')
RUNTIME = Path('/workspace/qa-review-v030/repos/Floorp-Runtime')
FLOORP = Path('/workspace/qa-review-v030/repos/Floorp')
ORIGINAL = Path('/workspace/qa-review-v030/inputs/github-87311566/extracted/Floorp_QA_Implementation_Kit_v0.3.0')
REPAIRED = Path('/workspace/qa-review-v030/fixes/archive-verification/Floorp_QA_Implementation_Kit_v0.3.0')
GIB = 1024 ** 3
EXPECTED_RUNTIME = '460106115bc76b026c8bf8dad24df7fcb07f97c2'
EXPECTED_FLOORP = '718e688fbd7ad88a776534e7778ad8e4a7f67364'

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def git(repo, *args):
    return subprocess.check_output(['git', '-c', 'core.packedGitWindowSize=8m', '-c', 'core.packedGitLimit=32m', '-C', str(repo), *args], env={**os.environ, 'GIT_NO_LAZY_FETCH': '1'})

assert git(RUNTIME, 'rev-parse', 'HEAD').decode().strip() == EXPECTED_RUNTIME
assert git(FLOORP, 'rev-parse', 'HEAD').decode().strip() == EXPECTED_FLOORP
sys.path.insert(0, str(RUNTIME / '.github/workflows/scripts'))
native_io = load('qa3_native_io', RUNTIME / '.github/workflows/scripts/qa3_native_io.py')
source = load('portability_source', FLOORP / 'tools/qa3/source.py')
sys.path.insert(0, str(REPAIRED / 'tools/qa'))
probes = load('portability_probes', REPAIRED / 'tools/qa/probes.py')
root = REVIEW / 'fixtures/portability-ops-output-3'
root.mkdir(exist_ok=False)
results = []

def resource_case(label, free, ram, cpus, required_free, required_ram, required_cpus, rejected):
    def read_text(path, *args, **kwargs):
        if str(path) == '/proc/meminfo':
            return f'MemTotal: {ram // 1024} kB\n'
        if path.name == 'memory.max':
            return 'max'
        if path.name == 'cpu.max':
            return 'max 100000'
        raise AssertionError(str(path))
    actual = None
    with mock.patch.object(native_io.Path, 'read_text', read_text), mock.patch.object(native_io.Path, 'is_file', return_value=True), mock.patch.object(native_io.os, 'sched_getaffinity', return_value=set(range(cpus))), mock.patch.object(native_io.shutil, 'disk_usage', return_value=SimpleNamespace(total=free, used=0, free=free)):
        try:
            actual = native_io.verify_budget(root, required_free, required_ram, required_cpus)
        except ValueError as exc:
            actual = {'rejected': True, 'error': str(exc)}
    assert bool(actual.get('rejected')) == rejected, (label, actual)
    results.append({'name': label, 'expectedRejection': rejected, 'observed': actual, 'fixtureOnly': True})

resource_case('4vCPU consumer cannot meet even post-transfer 80 GiB free on 80 GB disk', 80 * 10 ** 9, 16 * 10 ** 9, 4, 80 * GIB, 14 * GIB, 4, True)
resource_case('4vCPU consumer still cannot meet initial 100 GiB on generous 80 GiB disk', 80 * GIB, 16 * GIB, 4, 100 * GIB, 14 * GIB, 4, True)
resource_case('8vCPU builder fails documented 180 GiB initial reserve on 160 GiB disk', 160 * GIB, 32 * GIB, 8, 180 * GIB, 28 * GIB, 8, True)
resource_case('8vCPU consumer physical machine can meet 4 CPU and 14 GiB scoped preflight', 120 * GIB, 32 * GIB, 8, 80 * GIB, 14 * GIB, 4, False)
resource_case('16vCPU builder machine passes physical check without changing build jobs', 200 * GIB, 64 * GIB, 16, 140 * GIB, 28 * GIB, 8, False)

for platform_value in ('darwin', 'win32'):
    with mock.patch.object(source.sys, 'platform', platform_value):
        output = root / ('source-' + platform_value)
        code = source.run_source(output, EXPECTED_FLOORP)
    receipt = source.read_json(output / 'source-receipt.json')
    assert code == 1 and receipt['sourceVerdict'] == 'FAIL' and receipt['executedCases'] == 0 and receipt['publicationAuthorized'] is False
    results.append({'name': 'source host plan rejects ' + platform_value, 'exit': code, 'error': receipt['error'], 'fixtureOnly': True})

with mock.patch.dict(os.environ, {'QA_DISPOSABLE_WORKER': '1'}), mock.patch.object(probes.platform, 'system', return_value='Windows'), mock.patch.object(probes.subprocess, 'Popen') as start:
    try:
        probes.run_existing_probe(FLOORP, 'l2.web-panel-http', root / 'unused-browser', root / 'unused-native-record', '12.20.1', root / 'unused-probe-output', 60)
    except probes.QAError as exc:
        assert 'Windows' in str(exc)
        start.assert_not_called()
        results.append({'name': 'kit POSIX probe rejects Windows before process launch', 'error': str(exc), 'fixtureOnly': True})
    else:
        raise AssertionError('Unsupported Windows probe did not reject')

plan = json.loads((RUNTIME / '.github/qa/linux-proof-plan.json').read_text())
selected_paths = {row['id'] for row in plan['selection']} | {row['manifest'] for row in plan['selection']}
materials = {row['path']: row['sha256'] for row in plan['sourceMaterials']}
upstream = json.loads((RUNTIME / '.github/runtime-upstream.json').read_text())['upstream']['commit']
upstream_object = subprocess.run(['git', '-C', str(RUNTIME), 'cat-file', '-e', upstream + '^{commit}'], env={**os.environ, 'GIT_NO_LAZY_FETCH': '1'}, capture_output=True, text=True)
upstream_available = upstream_object.returncode == 0
selected = []
for path in sorted(selected_paths):
    head_data = git(RUNTIME, 'show', EXPECTED_RUNTIME + ':' + path)
    sha = hashlib.sha256(head_data).hexdigest()
    assert sha == materials[path]
    upstream_equal = None
    if upstream_available:
        upstream_equal = git(RUNTIME, 'show', upstream + ':' + path) == head_data
        assert upstream_equal
    selected.append({'path': path, 'sha256': sha, 'headMatchesPlanPin': True, 'headMatchesPinnedUpstream': upstream_equal})

docs = [REPAIRED / 'DESIGN.md', *sorted((REPAIRED / 'docs').glob('*.md'))]
doc_receipts = []
for path in docs:
    relative = path.relative_to(REPAIRED)
    data = path.read_bytes()
    assert data == (ORIGINAL / relative).read_bytes()
    doc_receipts.append({'path': relative.as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'unchangedFromOriginal': True})
assert len(doc_receipts) == 15

value = {'schemaVersion': 1, 'scope': 'portability-ops-read-only-synthetic-fixtures', 'runtimeHead': EXPECTED_RUNTIME, 'floorpHead': EXPECTED_FLOORP, 'upstream': upstream, 'upstreamTreeAvailable': upstream_available, 'upstreamReadError': upstream_object.stderr.strip(), 'negativeChecks': results, 'selectedPinnedFiles': selected, 'documentIntegrity': doc_receipts, 'nativeExecuted': False, 'ciDispatched': False, 'blacksmithConnected': False, 'publicationAuthorized': False}
(REVIEW / 'evidence/portability-ops-negative.json').write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({'checks': len(results), 'selectedPinnedFiles': len(selected), 'documents': len(doc_receipts), 'nativeExecuted': False}, indent=2))

import configparser
import hashlib
import json
import resource
import tarfile
import urllib.error
import urllib.request
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (256 * 1024**2, 256 * 1024**2))
resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
resource.setrlimit(resource.RLIMIT_FSIZE, (4 * 1024**2, 4 * 1024**2))
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
BASE = Path(__file__).resolve().parents[1]
old = json.loads(Path('/workspace/qa-review-v030/evidence/official-firefox-provenance.json').read_text())
archive = Path('/workspace/qa-review-v030/official-firefox/firefox-157.0.1-linux-x86_64-en-US.tar.xz')
sums = Path('/workspace/qa-review-v030/official-firefox/SHA256SUMS')
result = {'schemaVersion': 1, 'archivePath': str(archive), 'artifactURL': old['artifact_url'], 'checksumURL': old['checksums_url'], 'browserExecuted': False, 'archiveExtracted': False, 'metadata': {}, 'networkReads': [], 'limits': {'addressSpaceMiB': 256, 'cpuSeconds': 30, 'fileSizeMiB': 4, 'wallSeconds': 60}}
sha = hashlib.sha256()
with archive.open('rb') as stream:
    while data := stream.read(1024**2):
        sha.update(data)
result['archiveSha256'] = sha.hexdigest()
result['archiveBytes'] = archive.stat().st_size
result['checksumListSha256'] = hashlib.sha256(sums.read_bytes()).hexdigest()
member = 'linux-x86_64/en-US/firefox-157.0.1.tar.xz'
matches = [line.split(maxsplit=1)[0] for line in sums.read_text().splitlines() if len(line.split(maxsplit=1)) == 2 and line.split(maxsplit=1)[1].lstrip('*') == member]
result['exactChecksumEntries'] = len(matches)
result['checksumMatched'] = len(matches) == 1 and matches[0] == result['archiveSha256']
wanted = {'firefox/application.ini', 'firefox/platform.ini'}
with tarfile.open(archive, 'r|xz') as stream:
    for info in stream:
        if info.name not in wanted:
            continue
        if not info.isfile() or not 0 < info.size < 64 * 1024:
            raise ValueError('invalid exact metadata entry')
        data = stream.extractfile(info).read(64 * 1024)
        if len(data) != info.size:
            raise ValueError('truncated metadata')
        parser = configparser.ConfigParser(interpolation=None, strict=True)
        parser.optionxform = str
        parser.read_string(data.decode('utf-8'))
        value = {section: dict(parser[section]) for section in parser.sections()}
        value['_sha256'] = hashlib.sha256(data).hexdigest()
        result['metadata'][info.name] = value
        wanted.remove(info.name)
        if not wanted:
            break
if wanted:
    raise ValueError('required metadata absent')
result['matchesEarlierRawMetadata'] = result['metadata'] == old['metadata']
result['runtimePin'] = json.loads(Path('/workspace/qa-review-v030/repos/Floorp-Runtime/.github/runtime-upstream.json').read_text())['upstream']
urls = [
    'https://api.github.com/repos/mozilla-firefox/firefox/git/ref/tags/FIREFOX_157_0_1_RELEASE',
    'https://api.github.com/repos/mozilla-firefox/firefox/git/commits/0c469c2352451630bc69fc328c9f0c589c6c534d',
    'https://hg.mozilla.org/releases/mozilla-release/json-rev/737ec77d798755890b062aab541a90d6c75afd19',
]
for url in urls:
    item = {'url': url}
    try:
        request = urllib.request.Request(url, headers={'User-Agent': 'QA308-read-only-provenance-review', 'Accept': 'application/json'})
        with urllib.request.urlopen(request, timeout=7) as response:
            data = response.read(512 * 1024 + 1)
            if len(data) > 512 * 1024:
                raise ValueError('response budget exceeded')
            item.update(status=response.status, finalURL=response.url, contentType=response.headers.get('Content-Type'), bodySha256=hashlib.sha256(data).hexdigest())
            try:
                item['data'] = json.loads(data)
            except (UnicodeDecodeError, json.JSONDecodeError):
                item['bodyPrefix'] = data[:500].decode('utf-8', 'replace')
    except (ValueError, OSError, urllib.error.URLError) as error:
        item['error'] = str(error)
    result['networkReads'].append(item)
result['checksumSignatureVerified'] = False
result['gitHgMappingVerified'] = False
result['officialFirefoxMatch'] = 'unverified'
target = BASE / 'evidence/source-official-metadata.json'
target.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'evidence': str(target), 'sha256': result['archiveSha256'], 'checksumMatched': result['checksumMatched'], 'matchesEarlierRawMetadata': result['matchesEarlierRawMetadata'], 'hgSourceStamp': result['metadata']['firefox/platform.ini']['Build']['SourceStamp'], 'networkReads': [{k:v for k,v in x.items() if k not in {'data','bodyPrefix'}} for x in result['networkReads']]}))

// Independent fake receipts; no GitHub API, browser, or publisher invocation.
import { writeFileSync } from "node:fs";
import { validateFinalPackageSource } from "../evidence/workflow-sources/floorp-pr2889/tools/final-package-qa-source.mjs";

const checks = [];
const head = "a".repeat(40);
const targets = ["windows/x86_64", "linux/x86_64", "linuxAarch64/aarch64", "mac/x86_64", "mac/aarch64"];
const completed = (name) => ({ name, status: "completed", conclusion: "success" });
const valid = {
  run: { id: 123, repository: { full_name: "Floorp-Projects/Floorp" }, path: ".github/workflows/package_and_publish_release.yml", head_sha: head, event: "workflow_dispatch", head_branch: "main", status: "in_progress", conclusion: null },
  headSha: head, prePublication: true, unsigned: false,
  jobs: [...targets.map((target) => completed(`Verify ${target} package`)),
    completed("Validate provenance and assemble the flat release bundle"), completed("Validate immutable bundle and create draft release"),
    { name: "Manual approval and public release gate", status: "waiting", conclusion: null },
    { name: "Publish and verify stable updater metadata v2", status: "queued", conclusion: null }],
  pendingDeployments: [{ environment: { id: 9, name: "Deploy-to-installer-release" }, reviewers: [{ type: "User", reviewer: { id: 7 } }] }],
  release: { draft: true, prerelease: false, target_commitish: head },
  bundleArtifacts: [{ id: 501, name: "floorp-release-bundle-v2", expired: false, digest: "sha256:" + "c".repeat(64), workflow_run: { id: 123, head_sha: head } }],
};
function check(name, passed, details) { checks.push({ name, passed, details }); }
function reject(name, mutate) {
  const input = structuredClone(valid);
  mutate(input);
  try { validateFinalPackageSource(input); check(name, false, "accepted invalid fake receipt"); }
  catch (error) { check(name, true, error.message); }
}
const initial = validateFinalPackageSource(valid);
check("valid unfinished canonical run accepted without approving publication", initial.phase === "awaiting-publication-approval" && initial.publicationApprovalPerformed === false, initial);
for (const [name, mutate] of [
  ["wrong package workflow", (i) => i.run.path = ".github/workflows/arbitrary.yml"],
  ["PR producer", (i) => i.run.event = "pull_request"],
  ["wrong repository", (i) => i.run.repository.full_name = "wrong/repo"],
  ["wrong head", (i) => i.run.head_sha = "d".repeat(40)],
  ["unsigned production candidate", (i) => i.unsigned = true],
  ["cancelled package run", (i) => { i.run.status = "completed"; i.run.conclusion = "cancelled"; }],
  ["missing native target", (i) => i.jobs = i.jobs.filter((j) => j.name !== "Verify mac/aarch64 package")],
  ["failed native target", (i) => i.jobs[0].conclusion = "failure"],
  ["ambiguous native target", (i) => i.jobs.push(structuredClone(i.jobs[0]))],
  ["manual gate already running", (i) => i.jobs.find((j) => j.name === "Manual approval and public release gate").status = "in_progress"],
  ["approval removed during QA", (i) => i.pendingDeployments = []],
  ["required reviewers absent", (i) => i.pendingDeployments[0].reviewers = []],
  ["unprotected environment", (i) => i.pendingDeployments[0].environment.name = "arbitrary"],
  ["already public release", (i) => i.release.draft = false],
  ["expired bundle", (i) => i.bundleArtifacts[0].expired = true],
  ["wrong bundle producer run", (i) => i.bundleArtifacts[0].workflow_run.id = 124],
  ["wrong bundle producer head", (i) => i.bundleArtifacts[0].workflow_run.head_sha = "e".repeat(40)],
  ["ambiguous bundle", (i) => i.bundleArtifacts.push(structuredClone(i.bundleArtifacts[0]))],
  ["pre-approval inline intake has no pending deployment", (i) => { i.pendingDeployments = []; i.jobs = i.jobs.filter((j) => j.name !== "Manual approval and public release gate"); }],
]) reject(name, mutate);
for (const [name, mutate] of [
  ["bundle ID substitution detected by existing after-QA equality check", (i) => i.bundleArtifacts[0].id = 502],
  ["bundle digest substitution detected by existing after-QA equality check", (i) => i.bundleArtifacts[0].digest = "sha256:" + "f".repeat(64)],
]) {
  const changed = structuredClone(valid);
  mutate(changed);
  const after = validateFinalPackageSource(changed);
  check(name, JSON.stringify(initial) !== JSON.stringify(after), { before: initial, after });
}
const result = { scope: "pure intake and existing after-QA comparison over fake receipts", network: false, credentials: false, publication: false, checks, passed: checks.filter((c) => c.passed).length, failed: checks.filter((c) => !c.passed).length };
writeFileSync(new URL("../evidence/workflow-final-intake-results.json", import.meta.url), JSON.stringify(result, null, 2) + "\n");
console.log(JSON.stringify({ passed: result.passed, failed: result.failed, results: "evidence/workflow-final-intake-results.json" }));
process.exitCode = result.failed ? 1 : 0;

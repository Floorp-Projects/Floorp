import copy
import hashlib
import json
import os
import resource
import shutil
import subprocess
import sys
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (256 * 1024**2, 256 * 1024**2))
resource.setrlimit(resource.RLIMIT_CPU, (20, 20))
resource.setrlimit(resource.RLIMIT_FSIZE, (8 * 1024**2, 8 * 1024**2))
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

BASE = Path(__file__).resolve().parents[1]
ROOT = Path('/workspace/qa-review-v030/repos/Floorp-Runtime')
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / '.github/workflows/scripts'))
from qa3_build_profile import ac_options, profile
from qa3_source_cohort import same_cohort, verify_profile, verify_subject


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()


def invoke(fn, *args):
    try:
        fn(*args)
        return {'accepted': True}
    except (ValueError, TypeError, KeyError) as error:
        return {'accepted': False, 'error': str(error)}


results = {'schemaVersion': 1, 'runtime': '460106115bc76b026c8bf8dad24df7fcb07f97c2', 'nativeExecuted': False, 'sourceModified': False, 'credentialEnvironment': False, 'limits': {'addressSpaceMiB': 256, 'cpuSeconds': 20, 'fileSizeMiB': 8, 'wallSeconds': 40}, 'setup': [], 'cohort': [], 'profdata': []}
work = BASE / 'fixtures/source-negative-work'
work.mkdir(exist_ok=False)
for number, args in enumerate([
    ('windows', 'aarch64', False, False, '', ''),
    ('linux', 'aarch64', False, True, 'generate', ''),
    ('linux', 'x86_64', True, False, 'use', 'old-profile'),
    ('mac', 'aarch64', False, True, 'use', ''),
    ('mac', 'x86_64', False, True, 'generate', 'old-profile'),
    ('linux', 'x86_64', False, True, 'invalid-mode', ''),
]):
    case = work / f'setup-{number}'
    scripts = case / '.github/workflows/scripts'
    scripts.mkdir(parents=True)
    configs = case / '.github/workflows/mozconfigs'
    configs.mkdir()
    for path in (ROOT / '.github/workflows/mozconfigs').glob('*.mozconfig'):
        shutil.copy2(path, configs / path.name)
    for name in ('setup-floorp.sh', 'qa3_build_profile.py'):
        shutil.copy2(ROOT / '.github/workflows/scripts' / name, scripts / name)
    (case / '.github/patches/debug').mkdir(parents=True)
    (case / 'build').mkdir()
    (case / 'build/application.ini.in').write_text('fixture\n')
    bins = case / 'bin'
    bins.mkdir()
    for path in (bins / 'sudo', bins / 'rustup', case / 'mach'):
        path.write_text('#!/bin/sh\nexit 0\n')
        path.chmod(0o700)
    home = case / 'home'
    home.mkdir()
    env = {'PATH': f'{bins}:/usr/bin:/bin', 'HOME': str(home), 'GITHUB_WORKSPACE': str(case), 'SCCACHE_PATH': '/fixture/sccache', 'PYTHONDONTWRITEBYTECODE': '1', 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_TERMINAL_PROMPT': '0'}
    argv = ['bash', str(scripts / 'setup-floorp.sh'), args[0], args[1], str(args[2]).lower(), str(args[3]).lower(), args[4], args[5], '20261009000000']
    proc = subprocess.run(argv, cwd=case, env=env, capture_output=True, text=True, timeout=5)
    text = (case / 'mozconfig').read_text() if (case / 'mozconfig').is_file() else ''
    results['setup'].append({'requested': list(args), 'profileContract': invoke(profile, *args), 'realSetupExit': proc.returncode, 'realSetupStdout': proc.stdout, 'realSetupStderr': proc.stderr, 'generatedAcOptions': ac_options(text)})

common = {'schemaVersion': 1, 'U': {'vcs': 'git', 'repository': 'https://github.com/mozilla-firefox/firefox', 'fullRevision': 'a' * 40}, 'R': 'b' * 40, 'P': [{'path': 'common.patch', 'sha256': 'c' * 64}], 'transforms': [{'path': 'build/application.ini.in', 'sha256': 'd' * 64}], 'B': 'e' * 64, 'scope': 'qa3-preconfigure-source-v1'}
for key, subkey, value in [('U', 'vcs', 'hg'), ('U', 'fullRevision', '0' * 40), ('R', None, '0' * 40), ('B', None, '0' * 64), ('transforms', 0, {'path': 'build/application.ini.in', 'sha256': '0' * 64}), ('P', 0, {'path': 'common.patch', 'sha256': '0' * 64})]:
    changed = copy.deepcopy(common)
    if subkey is None:
        changed[key] = value
    else:
        changed[key][subkey] = value
    results['cohort'].append({'mutation': f'{key}/{subkey}', **invoke(same_cohort, changed, common)})

subject = {'schemaVersion': 1, 'common': common, 'role': 'profile-generate', 'target': 'x86_64-pc-linux-gnu', 'delta': [], 'finalTree': common['B'], 'configSha256': '1' * 64, 'toolchainSha256': '2' * 64, 'artifactSha256': '3' * 64, 'run': 101, 'attempt': 1}
consumer = {**subject, 'role': 'profile-use', 'configSha256': '4' * 64, 'artifactSha256': '5' * 64}
profdata = work / 'merged.profdata'
jarlog = work / 'en-US.log'
profdata.write_bytes(b'synthetic profile bytes\n')
jarlog.write_bytes(b'synthetic jarlog\n')
provenance = {'producerSubjectSha256': digest(subject), 'producerArtifactSha256': subject['artifactSha256'], 'producerRun': 101, 'producerAttempt': 1, 'workloadSha256': '6' * 64, 'profdataSha256': hashlib.sha256(profdata.read_bytes()).hexdigest(), 'jarlogSha256': hashlib.sha256(jarlog.read_bytes()).hexdigest()}
results['profileBaseline'] = invoke(verify_profile, provenance, subject, consumer, profdata, jarlog, '6' * 64)
for key, value in [('producerRun', 102), ('producerAttempt', 2), ('producerArtifactSha256', '0' * 64), ('producerSubjectSha256', '0' * 64), ('workloadSha256', '0' * 64), ('profdataSha256', '0' * 64), ('jarlogSha256', '0' * 64)]:
    results['profdata'].append({'mutation': key, **invoke(verify_profile, {**provenance, key: value}, subject, consumer, profdata, jarlog, '6' * 64)})
for key, value in [('target', 'x86_64-pc-windows-msvc'), ('toolchainSha256', '0' * 64), ('finalTree', '0' * 64), ('role', 'canonical-debug')]:
    results['profdata'].append({'mutation': 'consumer/' + key, **invoke(verify_profile, provenance, subject, {**consumer, key: value}, profdata, jarlog, '6' * 64)})
changed = copy.deepcopy(consumer)
changed['common']['R'] = '0' * 40
results['profdata'].append({'mutation': 'consumer/common/R', **invoke(verify_profile, provenance, subject, changed, profdata, jarlog, '6' * 64)})
profdata.write_bytes(b'stale profile under same file name\n')
results['profdata'].append({'mutation': 'actual-profdata-bytes', **invoke(verify_profile, provenance, subject, consumer, profdata, jarlog, '6' * 64)})
for role, target in [('legacy-debug-profile-use', subject['target']), ('profile-use', 'aarch64-unknown-linux-gnu')]:
    results['profdata'].append({'mutation': f'unsupported/{role}/{target}', **invoke(verify_subject, {**subject, 'role': role, 'target': target})})
output = BASE / 'evidence/source-negative-results.json'
output.write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps({'result': str(output), 'setupRejectedByContract': sum(not x['profileContract']['accepted'] for x in results['setup']), 'setupAcceptedByRealScript': sum(x['realSetupExit'] == 0 for x in results['setup']), 'cohortNegativeRejected': sum(not x['accepted'] for x in results['cohort']), 'profileNegativeRejected': sum(not x['accepted'] for x in results['profdata']), 'profileBaselineAccepted': results['profileBaseline']['accepted']}))

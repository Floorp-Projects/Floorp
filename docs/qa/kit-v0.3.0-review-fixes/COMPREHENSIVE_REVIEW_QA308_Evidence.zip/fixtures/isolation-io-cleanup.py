"""Bounded synthetic subprocess check; no native harness, credentials or network."""

import argparse
import errno
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import tempfile
from unittest import mock


SCRIPTS = Path('/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts')
ROOT = Path('/workspace/qa-review-v030/review-qa308')


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (256 * 1024**2, 256 * 1024**2))
    resource.setrlimit(resource.RLIMIT_CPU, (8, 8))
    resource.setrlimit(resource.RLIMIT_FSIZE, (32 * 1024**2, 32 * 1024**2))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def case():
    sys.path.insert(0, str(SCRIPTS))
    import qa3_native_io as io

    created = []
    writes = []
    real_popen = subprocess.Popen
    real_open = Path.open

    class FaultySink:
        def __init__(self, stream):
            self.stream = stream

        def __enter__(self):
            return self

        def __exit__(self, *args):
            self.stream.close()

        def write(self, data):
            writes.append(len(data))
            raise OSError(errno.EDQUOT, 'synthetic own-fixture log quota failure')

    def open_log(path, *args, **kwargs):
        stream = real_open(path, *args, **kwargs)
        return FaultySink(stream) if path.name == 'io-failure.stdout' and args == ('xb',) else stream

    def owned_popen(*args, **kwargs):
        child = real_popen(*args, **kwargs)
        created.append((child, io._proc(child.pid)[2]))
        return child

    with tempfile.TemporaryDirectory(prefix='isolation-io-fixture-') as directory:
        root = Path(directory)
        child_env = {'PATH': os.environ['PATH'], 'LANG': 'C.UTF-8', 'PYTHONDONTWRITEBYTECODE': '1'}
        code = (
            'import os,signal,time\n'
            'signal.signal(signal.SIGTERM, signal.SIG_IGN)\n'
            'while True:\n'
            ' os.write(1, b"synthetic\\n" * 1024)\n'
            ' time.sleep(0.001)\n'
        )
        error = None
        alive = False
        try:
            with mock.patch.object(Path, 'open', open_log), mock.patch.object(io.subprocess, 'Popen', owned_popen), mock.patch.object(io, 'MAX_EXPANDED', 16 * 1024**2):
                io.run_owned(
                    [sys.executable, '-B', '-c', code], root, child_env,
                    root / 'logs', 'io-failure', 2,
                    memory=128 * 1024**2, log_limit=1024**2,
                )
        except OSError as exc:
            error = {'type': type(exc).__name__, 'errno': exc.errno, 'message': str(exc)}
            alive = bool(created and created[0][0].poll() is None)
        finally:
            fixture_cleanup = []
            for child, birth in created:
                current = io._proc(child.pid)
                if child.poll() is None and current and current[2] == birth:
                    os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=3)
                fixture_cleanup.append({'pid': child.pid, 'reaped': child.poll() is not None})
        result = {
            'case': 'cleanup-drain-log-EDQUOT',
            'sourceSha256': hashlib.sha256((SCRIPTS / 'qa3_native_io.py').read_bytes()).hexdigest(),
            'error': error,
            'failedWrites': len(writes),
            'childAliveAfterRunOwnedRaised': alive,
            'processReceiptWritten': (root / 'logs/io-failure.process.json').exists(),
            'fixtureCleanup': fixture_cleanup,
            'nativeOrBrowserExecuted': False,
            'networkOrModelCalled': False,
            'credentialEnvironmentPassed': False,
        }
        assert error and error['errno'] == errno.EDQUOT, result
        assert len(writes) >= 2 and alive, result
        assert all(item['reaped'] for item in fixture_cleanup), result
        print(json.dumps(result))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--case', action='store_true')
    args = parser.parse_args()
    if args.case:
        case()
        return
    output = ROOT / 'evidence/isolation-io-cleanup.raw.log'
    env = {
        'PATH': os.environ['PATH'], 'LANG': 'C.UTF-8',
        'TMPDIR': '/tmp', 'PYTHONDONTWRITEBYTECODE': '1',
        'PYTHONNOUSERSITE': '1', 'GIT_CONFIG_NOSYSTEM': '1',
        'GIT_CONFIG_GLOBAL': '/dev/null',
    }
    with output.open('xb') as log:
        process = subprocess.Popen(
            [sys.executable, '-B', str(Path(__file__).resolve()), '--case'],
            stdout=log, stderr=subprocess.STDOUT, env=env,
            start_new_session=True, preexec_fn=limits,
        )
        try:
            status = process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=3)
            raise
    raw = output.read_text()
    assert status == 0, raw
    result = json.loads(raw.splitlines()[-1])
    result.update(exitCode=status, outerTimeout=False, resourceLimits={'ASMiB': 256, 'cpuSeconds': 8, 'fileMiB': 32, 'wallSeconds': 15})
    destination = ROOT / 'evidence/isolation-io-cleanup.json'
    with destination.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()

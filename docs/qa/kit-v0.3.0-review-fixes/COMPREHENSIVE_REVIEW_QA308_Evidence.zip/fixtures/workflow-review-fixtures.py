#!/usr/bin/env python3
"""Read-only topology checks and synthetic native transport fixtures."""

import copy
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import urllib.error
from unittest.mock import patch

import yaml


ROOT = Path(__file__).resolve().parents[1]
SOURCES = ROOT / "evidence/workflow-sources"
MANIFEST = json.loads((ROOT / "frozen-inputs.json").read_text())
RESULTS = []


class GithubLoader(yaml.SafeLoader):
    pass


GithubLoader.yaml_implicit_resolvers = {
    key: [(tag, expression) for tag, expression in values
          if tag != "tag:yaml.org,2002:bool"]
    for key, values in yaml.SafeLoader.yaml_implicit_resolvers.items()
}
GithubLoader.add_implicit_resolver(
    "tag:yaml.org,2002:bool", re.compile(r"^(?:true|false|True|False|TRUE|FALSE)$"),
    list("tTfF"),
)


def check(name, condition, details=None):
    RESULTS.append({"name": name, "passed": bool(condition), "details": details})


def reject(name, call):
    try:
        call()
    except (ValueError, OSError, KeyError) as error:
        check(name, True, {"rejectedBy": type(error).__name__, "reason": str(error)})
    else:
        check(name, False, "accepted invalid synthetic input")


def load(label, filename):
    return yaml.load((SOURCES / label / ".github/workflows" / filename).read_text(),
                     Loader=GithubLoader)


def git_bytes(repo, revision, filename):
    return subprocess.check_output(["git", "show", revision + ":" + filename],
                                   cwd=repo)


def dependencies(job):
    value = job.get("needs", [])
    return [value] if isinstance(value, str) else value


def yaml_files(repo, revision):
    paths = subprocess.check_output(
        ["git", "ls-tree", "-r", "--name-only", revision, ".github/workflows"],
        cwd=repo, text=True,
    ).splitlines()
    return [path for path in paths if path.endswith((".yml", ".yaml"))]


def main():
    prs = {item["number"]: item for item in MANIFEST["prs"]}
    floorp = prs[2889]
    docs = prs[2893]
    runtime83, runtime84 = prs[83], prs[84]
    retained = []
    for filename in yaml_files(floorp["reviewCheckout"], floorp["base"]):
        base = git_bytes(floorp["reviewCheckout"], floorp["base"], filename)
        current = git_bytes(floorp["reviewCheckout"], floorp["head"], filename)
        if filename.endswith(("package_and_publish_release.yml", "package_and_publish_alpha.yml")):
            a, b = yaml.load(base, Loader=GithubLoader), yaml.load(current, Loader=GithubLoader)
            b["jobs"].pop("source-qa-shadow")
            equal = a == b
            comparison = "all existing parsed keys equal after removing new shadow job"
        else:
            equal, comparison = base == current, "byte equality"
        retained.append({"file": filename, "preserved": equal,
                         "comparison": comparison,
                         "baseSha256": hashlib.sha256(base).hexdigest(),
                         "headSha256": hashlib.sha256(current).hexdigest()})
    check("Floorp 2889 preserves every pre-existing workflow", all(x["preserved"] for x in retained), retained)
    docs_equal = []
    for filename in yaml_files(docs["reviewCheckout"], docs["base"]):
        docs_equal.append({"file": filename, "equal":
                           git_bytes(docs["reviewCheckout"], docs["base"], filename) ==
                           git_bytes(docs["reviewCheckout"], docs["head"], filename)})
    check("Floorp 2893 changes no existing workflow bytes", all(x["equal"] for x in docs_equal), docs_equal)
    for pr, prior in [(runtime83, runtime83["base"]), (runtime84, runtime84["base"])]:
        comparisons = [{"file": filename, "equal":
                        git_bytes(pr["reviewCheckout"], prior, filename) ==
                        git_bytes(pr["reviewCheckout"], pr["head"], filename)}
                       for filename in yaml_files(pr["reviewCheckout"], prior)]
        check(f"Runtime {pr['number']} preserves every pre-existing workflow YAML",
              all(x["equal"] for x in comparisons), comparisons)

    ci = load("floorp-pr2889", "colocated_runner_test.yml")
    check("ordinary CI automatically covers all PRs", ci["on"].get("pull_request") is None and "pull_request" in ci["on"], ci["on"])
    check("ordinary CI has contents-read permissions", ci["permissions"] == {"contents": "read"})
    check("ordinary native artifact/browser matrix uses standard hosted labels",
          [row["runner"] for row in ci["jobs"]["native-runtime"]["strategy"]["matrix"]["include"]] ==
          ["ubuntu-24.04", "ubuntu-24.04-arm", "windows-latest", "macos-latest"])
    check("ordinary browser execution is Linux x64 only",
          [row["runner"] for row in ci["jobs"]["native-runtime"]["strategy"]["matrix"]["include"] if row["browser_suite"]] == ["ubuntu-24.04"])
    secret_steps = []
    for job_name, job in ci["jobs"].items():
        check(f"ordinary CI {job_name} has no protected environment or write permission",
              "environment" not in job and "permissions" not in job and "uses" not in job)
        for step in job.get("steps", []):
            if "secrets." in json.dumps(step):
                secret_steps.append({"job": job_name, "step": step.get("name"), "if": step.get("if")})
    check("ordinary PR CI excludes its sole declared PAT step",
          secret_steps == [{"job": "smoke", "step": "Validate locked Runtime release metadata",
                            "if": "github.event_name != 'pull_request'"}], secret_steps)
    docs_workflow = load("floorp-pr2889", "docs_pipeline.yml")
    check("docs PR verification has no declared secret", "secrets." not in json.dumps(docs_workflow["jobs"]["verify"]))
    check("docs model generation excludes PR events",
          docs_workflow["jobs"]["generate-docs-artifact"]["if"] ==
          "(github.event_name == 'workflow_dispatch' || github.event_name == 'schedule') && github.ref == 'refs/heads/main'")
    moderation = load("floorp-pr2889", "moderation.yml")
    check("existing PR moderation has separate model secrets and no test checkout or reusable publish call",
          "OPENROUTER_API_KEY" in json.dumps(moderation) and
          "contents" not in moderation["jobs"]["moderate"]["permissions"] and
          all("checkout@" not in step.get("uses", "") and not step.get("uses", "").startswith("./")
              for step in moderation["jobs"]["moderate"]["steps"]))

    release = load("floorp-pr2889", "package_and_publish_release.yml")
    alpha = load("floorp-pr2889", "package_and_publish_alpha.yml")
    shadow = load("floorp-pr2889", "qa3-source-shadow.yml")
    check("source QA intentionally remains nonblocking shadow", shadow["jobs"]["source"]["continue-on-error"] is True)
    check("source shadow receives no caller secrets", all("secrets" not in d["jobs"]["source-qa-shadow"] for d in [release, alpha]))
    check("source shadow is invoked once per orchestration",
          all(sum(job.get("uses", "").endswith("qa3-source-shadow.yml") for job in d["jobs"].values()) == 1 for d in [release, alpha]))
    check("current package jobs have no required source-shadow edge",
          all("source-qa-shadow" not in dependencies(job)
              for d in [release, alpha] for name, job in d["jobs"].items()
              if name.startswith("package-")))
    verify = [name for name in release["jobs"] if name.startswith("verify-")]
    check("stable release retains all five native verification needs before assembly",
          len(verify) == 5 and all(name in dependencies(release["jobs"]["assemble-release-bundle"]) for name in verify), verify)
    check("validation-only mode skips production publisher",
          release["jobs"]["publish"]["if"] == "${{ inputs.validation_only != true }}")
    check("stable publisher still requires exact assembled bundle",
          dependencies(release["jobs"]["publish"]) == ["assemble-release-bundle"])
    package = load("floorp-pr2889", "package.yml")
    for field in ["installer_artifact_id", "installer_artifact_digest", "mar_artifact_id", "mar_artifact_digest"]:
        check(f"macOS {field} prioritizes ticket-verified final output",
              "jobs.macos-ticket-verify.outputs." in package["on"]["workflow_call"]["outputs"][field]["value"])
    publisher = load("floorp-pr2889", "publish_release.yml")
    check("draft creation remains a draft", any(step.get("with", {}).get("draft") is True
                                               for step in publisher["jobs"]["prepare_release"]["steps"]))
    check("installer manual environment gate remains",
          publisher["jobs"]["release_check"]["environment"] == "Deploy-to-installer-release" and
          dependencies(publisher["jobs"]["release_check"]) == ["prepare_release"])
    check("updater waits on approved public-release byte comparison gate",
          dependencies(publisher["jobs"]["publish_updates"]) == ["prepare_release", "release_check"] and
          publisher["jobs"]["publish_updates"]["environment"] == "Deploy-to-updater-release")
    check("public mutation serialization remains enabled",
          publisher["concurrency"] == {"group": "publish-release-v2-${{ github.repository }}", "cancel-in-progress": False})
    finalqa = load("floorp-pr2889", "validate-final-package-qa.yml")
    check("final QA is independent manual read-only workflow",
          list(finalqa["on"]) == ["workflow_dispatch"] and finalqa["permissions"] == {"actions": "read", "contents": "read"})
    check("current publisher does not invoke final QA or require a new QA sidecar",
          not any("validate-final-package-qa" in job.get("uses", "") for job in release["jobs"].values()) and
          "sidecar" not in json.dumps(publisher).lower())
    alpha_publisher = load("floorp-pr2889", "publish_alpha.yml")
    check("legacy alpha retains distinct direct prerelease publication path",
          alpha_publisher["permissions"] == {"contents": "write"} and
          "environment" not in alpha_publisher["jobs"]["main"] and
          any(step.get("with", {}).get("draft") is False and step.get("with", {}).get("prerelease") is True
              for step in alpha_publisher["jobs"]["main"]["steps"]))

    native = load("runtime-pr84", "qa3-linux-debug-proof.yml")
    check("new native proof has reusable-only trigger", list(native["on"]) == ["workflow_call"])
    check("public native execution rejected before builder scheduling",
          dependencies(native["jobs"]["producer"]) == ["private-prerequisite"] and
          native["jobs"]["private-prerequisite"]["runs-on"] == "ubuntu-24.04" and
          any('test "$IS_PRIVATE" = true' in step.get("run", "") for step in native["jobs"]["private-prerequisite"]["steps"]))
    check("consumer requires successful producer", dependencies(native["jobs"]["consumer"]) == ["producer"] and "if" not in native["jobs"]["consumer"])
    check("new native proof has no error-tolerant job", not any(job.get("continue-on-error") for job in native["jobs"].values()))
    check("new native proof cannot write publication content", native["permissions"] == {"contents": "read", "actions": "read"})
    check("new native evidence preserves failure uploads", all(any(step.get("if") == "always()" and "upload-artifact@" in step.get("uses", "")
                                                                 for step in native["jobs"][role]["steps"]) for role in ["producer", "consumer"]))
    check("native concurrency identifies attempt and does not serialize distinct runs",
          "github.run_id" in native["concurrency"]["group"] and "github.run_attempt" in native["concurrency"]["group"],
          {"crossRunLock": False, "cancelInProgress": native["concurrency"]["cancel-in-progress"]})
    callers = []
    for label in ["floorp-pr2889", "runtime-pr84"]:
        for filename in (SOURCES / label / ".github/workflows").glob("*.yml"):
            workflow = yaml.load(filename.read_text(), Loader=GithubLoader)
            for name, job in workflow.get("jobs", {}).items():
                if "qa3-linux-debug-proof.yml" in job.get("uses", ""):
                    callers.append({"label": label, "file": filename.name, "job": name})
    check("new native reusable proof has no automatic existing caller", callers == [], callers)

    kitroot = ROOT.parent
    a = kitroot / "inputs/github-87311566/extracted/Floorp_QA_Implementation_Kit_v0.3.0"
    b = kitroot / "fixes/archive-verification/Floorp_QA_Implementation_Kit_v0.3.0"
    doc_comparisons = []
    for relative in [Path("DESIGN.md")] + [path.relative_to(a) for path in sorted((a / "docs").glob("*.md"))]:
        first, second = (a / relative).read_bytes(), (b / relative).read_bytes()
        doc_comparisons.append({"path": str(relative), "equal": first == second,
                                "sha256": hashlib.sha256(first).hexdigest()})
    check("repaired kit preserves DESIGN and all 14 design documents byte for byte",
          len(doc_comparisons) == 15 and all(x["equal"] for x in doc_comparisons), doc_comparisons)

    before_path = "docs/qa/kit-v0.3.0-review-fixes/evidence/qa307-floorp-integration-before-cancel.json"
    cancel_path = "docs/qa/kit-v0.3.0-review-fixes/evidence/qa307-floorp-integration-cancel-confirmation.json"
    before = json.loads(git_bytes(docs["reviewCheckout"], docs["head"], before_path))
    cancelled = json.loads(git_bytes(docs["reviewCheckout"], docs["head"], cancel_path))
    history = {"source": "captured historical JSON at fixed PR 2893 commit; no live API call",
               "run": {key: cancelled.get(key) for key in ["id", "path", "event", "head_sha", "status", "conclusion", "run_attempt"]},
               "beforeTopLevelKeys": sorted(before),
               "before": {"run": {key: before["run"].get(key) for key in ["id", "event", "head_sha", "status", "conclusion"]},
                          "jobs": [{"name": job.get("name"), "status": job.get("status"), "conclusion": job.get("conclusion"), "labels": job.get("labels"),
                                    "activeSteps": [step.get("name") for step in job.get("steps", []) if step.get("status") == "in_progress"]}
                                   for job in before["jobs"]["jobs"]]}}
    (ROOT / "evidence/workflow-cancelled-ci-history.json").write_text(json.dumps(history, indent=2) + "\n")

    sys.path.insert(0, str(SOURCES / "runtime-pr84/.github/workflows/scripts"))
    import qa3_native_transport as transport

    runtime = runtime84["head"]
    controller = "d" * 40
    controller_head = "e" * 40
    env = {"GITHUB_REPOSITORY": "fixture-owner/private-fixture", "GITHUB_RUN_ID": "123", "GITHUB_RUN_ATTEMPT": "2",
           "GITHUB_API_URL": transport.API, "GITHUB_WORKFLOW_SHA": controller, "GITHUB_SHA": controller_head,
           "GITHUB_TOKEN": "synthetic-not-a-credential"}
    payload = {"id": 123, "run_attempt": 2, "repository": {"full_name": env["GITHUB_REPOSITORY"], "private": True},
               "head_sha": controller_head, "created_at": "2026-10-09T00:01:02Z",
               "referenced_workflows": [{"path": transport.WORKFLOW + "@" + runtime, "sha": runtime}]}
    with patch.dict(os.environ, env, clear=True), patch("urllib.request.urlopen", side_effect=AssertionError("network prohibited")):
        context = transport.authenticated_context(runtime, controller, fetcher=lambda **kwargs: copy.deepcopy(payload))
        check("authenticated synthetic context keeps publication unauthorized", context["publicationAuthorized"] is False and context["buildID"] == "20261009000102")
        for label, mutate in [
            ("public execution repository", lambda p: p["repository"].update(private=False)),
            ("wrong execution repository", lambda p: p["repository"].update(full_name="other/repo")),
            ("wrong run", lambda p: p.update(id=124)),
            ("old attempt", lambda p: p.update(run_attempt=1)),
            ("wrong controller head", lambda p: p.update(head_sha="f" * 40)),
            ("mutable recipe ref", lambda p: p["referenced_workflows"][0].update(path=transport.WORKFLOW + "@main")),
            ("wrong recipe SHA", lambda p: p["referenced_workflows"][0].update(sha="f" * 40)),
            ("duplicate reusable recipe", lambda p: p["referenced_workflows"].append(copy.deepcopy(p["referenced_workflows"][0]))),
        ]:
            bad = copy.deepcopy(payload)
            mutate(bad)
            reject("native context rejects " + label, lambda bad=bad: transport.authenticated_context(runtime, controller, fetcher=lambda **kwargs: bad))
        with patch.dict(os.environ, {"GITHUB_WORKFLOW_SHA": "f" * 40}):
            reject("native context rejects changed W", lambda: transport.authenticated_context(runtime, controller, fetcher=lambda **kwargs: payload))
        metadata = {"id": 501, "name": "qa3-primary-123-2", "expired": False, "digest": "sha256:" + "a" * 64,
                    "size_in_bytes": 10, "workflow_run": {"id": 123, "head_sha": controller_head}}
        check("synthetic exact native artifact identity accepted",
              transport.verify_artifact_metadata(metadata, context, 501, "primary", "a" * 64) == 10)
        for label, mutate in [
            ("wrong ID", lambda p: p.update(id=502)),
            ("wrong kind", lambda p: p.update(name="qa3-support-123-2")),
            ("old attempt name", lambda p: p.update(name="qa3-primary-123-1")),
            ("expired artifact", lambda p: p.update(expired=True)),
            ("wrong digest", lambda p: p.update(digest="sha256:" + "b" * 64)),
            ("zero bytes", lambda p: p.update(size_in_bytes=0)),
            ("oversize artifact", lambda p: p.update(size_in_bytes=transport.MAX_COMPRESSED + 1)),
            ("wrong producer run", lambda p: p["workflow_run"].update(id=124)),
            ("wrong controller subject", lambda p: p["workflow_run"].update(head_sha="f" * 40)),
        ]:
            bad = copy.deepcopy(metadata)
            mutate(bad)
            reject("native artifact rejects " + label, lambda bad=bad: transport.verify_artifact_metadata(bad, context, 501, "primary", "a" * 64))

        class Response(io.BytesIO):
            status = 200

        class Opener:
            def __init__(self, raw, artifact, location):
                self.raw, self.artifact, self.location = raw, artifact, location
                self.requests = []

            def open(self, request, timeout):
                self.requests.append({"url": request.full_url, "authorized": request.get_header("Authorization") is not None})
                if request.full_url.endswith("/zip"):
                    raise urllib.error.HTTPError(request.full_url, 302, "synthetic redirect", {"Location": self.location}, None)
                if request.full_url == self.location:
                    return Response(self.raw)
                return Response(json.dumps(self.artifact).encode())

        raw = b"tiny transport fixture"
        digest = hashlib.sha256(raw).hexdigest()
        transfer_metadata = copy.deepcopy(metadata)
        transfer_metadata.update(digest="sha256:" + digest, size_in_bytes=len(raw))
        with tempfile.TemporaryDirectory(prefix="workflow-transport-", dir=ROOT / "fixtures") as directory:
            opener = Opener(raw, transfer_metadata, "https://fixture.blob.core.windows.net/tiny")
            destination = Path(directory) / "artifact"
            transport.download_artifact(context, 501, "primary", digest, destination, opener=opener)
            check("synthetic artifact bytes bind actual transferred digest", destination.read_bytes() == raw)
            check("storage redirect receives no authorization header", opener.requests[-1]["authorized"] is False and all(x["authorized"] for x in opener.requests[:2]), opener.requests)
            reject("synthetic unapproved storage origin rejected",
                   lambda: transport.download_artifact(context, 501, "primary", digest, Path(directory) / "bad",
                                                        opener=Opener(raw, transfer_metadata, "https://example.invalid/tiny")))
            reject("synthetic transferred digest mismatch rejected",
                   lambda: transport.download_artifact(context, 501, "primary", digest, Path(directory) / "changed",
                                                        opener=Opener(b"changed fixture bytes", transfer_metadata, "https://fixture.blob.core.windows.net/changed")))

    topology = {}
    for label in ["floorp-pr2889", "floorp-pr2893", "runtime-pr83", "runtime-pr84"]:
        topology[label] = {}
        for file in sorted((SOURCES / label / ".github/workflows").glob("*.yml")):
            d = yaml.load(file.read_text(), Loader=GithubLoader)
            topology[label][file.name] = {"on": d.get("on"), "permissions": d.get("permissions"),
                                         "concurrency": d.get("concurrency"),
                                         "jobs": {name: {field: job[field] for field in ["uses", "needs", "if", "runs-on", "environment", "permissions", "continue-on-error", "timeout-minutes"] if field in job}
                                                  for name, job in d.get("jobs", {}).items()}}
    check("ordinary CI completion has no workflow_run publication bridge",
          not any("workflow_run" in d["on"] for label in topology.values() for d in label.values() if isinstance(d["on"], dict)))
    (ROOT / "evidence/workflow-topology.json").write_text(json.dumps(topology, indent=2, ensure_ascii=False) + "\n")
    report = {"scope": "fixed source topology + synthetic context/transport only", "network": False,
              "nativeBuild": False, "credentials": False, "sourceMutations": False,
              "checks": RESULTS, "passed": sum(x["passed"] for x in RESULTS),
              "failed": sum(not x["passed"] for x in RESULTS)}
    (ROOT / "evidence/workflow-fixture-results.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"passed": report["passed"], "failed": report["failed"],
                      "results": str(ROOT / "evidence/workflow-fixture-results.json")}))
    return bool(report["failed"])


if __name__ == "__main__":
    sys.exit(main())

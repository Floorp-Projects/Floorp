"""Bounded QA308 data-only canary/JUnit/INCOMPLETE-path fixtures."""
import copy
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from unittest import mock
import xml.etree.ElementTree as ET

BASE=Path('/workspace/qa-review-v030')
SCRIPTS=BASE/'repos/Floorp-Runtime/.github/workflows/scripts'
sys.path.insert(0,str(SCRIPTS))
from qa3_mozlog import verify_mozlog
import qa3_native_build as build
import qa3_native_consume as consume

spec=importlib.util.spec_from_file_location('qa308_source',BASE/'repos/Floorp/tools/qa3/source.py')
source=importlib.util.module_from_spec(spec);spec.loader.exec_module(source)
out=[]
with tempfile.TemporaryDirectory(prefix='qa308-followup-') as temp:
    root=Path(temp)
    group=source.read_json(source.ROOT/'tools/qa3/source-plan.json')['groups'][1]
    suite=ET.Element('testsuite',{'tests':'28','failures':'0','errors':'0','skipped':'0'})
    for c in group['cases']:ET.SubElement(suite,'testcase',{'name':c['name'],'classname':'test'})
    body=ET.tostring(suite,encoding='unicode').replace('classname="test"','classname="&origin;"',1)
    for encoding in ('UTF-8','UTF-16','UTF-32'):
        text=f'<?xml version="1.0" encoding="{encoding}"?>\n<!DOCTYPE testsuite [<!ENTITY origin "test">]>\n'+body
        raw=text.encode(encoding)
        path=root/(encoding+'.xml');path.write_bytes(raw)
        result={'fixture':'junit-'+encoding+'-DTD-ENTITY','bytes':len(raw),'amplification':False}
        try:
            rows=source.read_junit(path,source.ROOT,source.GROUPS['node-intake'][0]);source.validate_cases(group,rows)
            result.update(outcome='ACCEPT',caseCount=len(rows),allPASS=all(x['verdict']=='PASS' for x in rows))
        except (ValueError,TypeError,ET.ParseError) as exc:result.update(outcome='REJECT',type=type(exc).__name__,reason=str(exc))
        out.append(result)

    path=root/'canary.jsonl'
    case={'suite':'xpcshell','id':'xpcom/canary.js','minimumAssertions':1}
    process={'exit':1,'stop':None,'ownedCleanupComplete':True}
    events=[{'action':'suite_start','tests':[case['id']]},{'action':'test_start','test':case['id']},
            {'action':'test_status','test':case['id'],'status':'FAIL','expected':'PASS','subtest':'QA3_EXPECTED_ASSERTION'},
            {'action':'test_end','test':case['id'],'status':'FAIL'},{'action':'suite_end'}]
    def canary(label,values,state=process):
        path.write_text(''.join(json.dumps(x)+'\n' for x in values))
        r={'fixture':label}
        try:r.update(outcome='ACCEPT',result=verify_mozlog(path,case,root,state,canary=True))
        except (ValueError,TypeError,KeyError) as e:r.update(outcome='REJECT',reason=str(e))
        out.append(r)
    canary('canary-valid-exact-reason',events)
    for reason in (None,'','   ','not QA3_EXPECTED_ASSERTION','QA3_EXPECTED_ASSERTION_WRONG',False,0):
        changed=copy.deepcopy(events);changed[2]['subtest']=reason
        canary('canary-wrong-reason-'+repr(reason),changed)
    for code in (0,2,4,-9,False,1.0):canary('canary-wrong-outer-exit-'+repr(code),events,{**process,'exit':code})
    changed=copy.deepcopy(events);changed.insert(3,copy.deepcopy(changed[2]));canary('canary-duplicate-hit',changed)
    changed=copy.deepcopy(events);changed.insert(3,{'action':'test_status','test':case['id'],'status':'FAIL','expected':'PASS','subtest':'unrelated assertion'});canary('canary-unrelated-failure',changed)
    changed=copy.deepcopy(events);changed[2]['expected']='FAIL';canary('canary-declared-expected-FAIL',changed)
    changed=copy.deepcopy(events);changed[2]['status']='SKIP';canary('canary-SKIP',changed)
    canary('canary-no-end',events[:-1])

    for label,module,target,result_name in [('producer',build,'build_proof','producer-result.json'),('consumer',consume,'consume_proof','consumer-result.json')]:
        dst=root/label
        args=['fixture']
        path_args=['source','objdir','output','state','toolchain-lock','python-environment','context'] if label=='producer' else ['recipe','inputs','output','state','toolchain-lock','context']
        for name in path_args:args += ['--'+name,str(dst if name=='output' else root/name)]
        hash_args=['runtime','controller','plan-sha256','toolchain-sha256','python-environment-sha256','context-sha256']
        if label=='consumer':hash_args+=['primary-sha256','support-sha256','builder-toolchain-sha256']
        for name in hash_args:args += ['--'+name,'a'*(40 if name in ('runtime','controller') else 64)]
        if label=='consumer':args+=['--primary-id','1','--support-id','2']
        def failure(parsed):
            parsed.output.mkdir()
            raise OSError('synthetic output collector write failure')
        with mock.patch.object(sys,'argv',args),mock.patch.object(module,target,side_effect=failure):exit_code=module.main()
        result={'fixture':label+'-outer-OSError-INCOMPLETE','exit':exit_code,'result':json.loads((dst/result_name).read_text()),'failure':json.loads((dst/'failure.json').read_text()),'nativeExecuted':False}
        assert exit_code==1
        assert result['failure']['verdict']=='INCOMPLETE'
        assert result['result']['publicationAuthorized'] is False
        out.append(result)

print(json.dumps({'schemaVersion':1,'network':False,'browser':False,'native':False,'fixtureCount':len(out),'fixtures':out},indent=2))

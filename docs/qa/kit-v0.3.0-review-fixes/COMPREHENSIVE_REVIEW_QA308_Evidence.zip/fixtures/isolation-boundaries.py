"""Small reviewed archives, material markers, environment and own-process fixtures."""

import ctypes
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import tarfile
import tempfile
import time
import uuid
import zipfile
from unittest import mock

ROOT = Path('/workspace/qa-review-v030/review-qa308')
RUNTIME = Path('/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts')
SOURCE = Path('/workspace/qa-review-v030/repos/Floorp/tools/qa3/source.py')


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (256 * 1024**2, 256 * 1024**2))
    resource.setrlimit(resource.RLIMIT_CPU, (10, 10))
    resource.setrlimit(resource.RLIMIT_FSIZE, (32 * 1024**2, 32 * 1024**2))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def proc(pid):
    try:
        fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
        return fields[0], int(fields[19])
    except (OSError, ValueError, IndexError):
        return None


def run_cases():
    sys.path.insert(0, str(RUNTIME))
    import qa3_native_io as native
    spec = importlib.util.spec_from_file_location('isolation_source', SOURCE)
    source = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(source)
    results = []
    with tempfile.TemporaryDirectory(prefix='isolation-boundaries-') as directory:
        base = Path(directory)
        for name, member, kind, target in (
            ('traversal', '../outside', tarfile.REGTYPE, None),
            ('absolute', '/outside', tarfile.REGTYPE, None),
            ('external-symlink', 'link', tarfile.SYMTYPE, '../../outside'),
            ('hardlink', 'hard', tarfile.LNKTYPE, 'fixture'),
            ('device', 'device', tarfile.CHRTYPE, None),
        ):
            archive = base / (name + '.tar')
            with tarfile.open(archive, 'w') as stream:
                item = tarfile.TarInfo(member)
                item.type = kind
                if target:
                    item.linkname = target
                if kind == tarfile.REGTYPE:
                    item.size = 1
                    stream.addfile(item, io.BytesIO(b'x'))
                else:
                    stream.addfile(item)
            try:
                native.extract_archive(archive, base / (name + '-out'), expanded=256, max_files=8)
            except (ValueError, OSError, tarfile.TarError) as exc:
                results.append({'case': name, 'rejected': True, 'error': str(exc)})
            else:
                raise AssertionError(name)
        archive = base / 'duplicate.zip'
        with zipfile.ZipFile(archive, 'w') as stream:
            stream.writestr('fixture', b'a')
            stream.writestr('./fixture', b'b')
        try:
            native.extract_archive(archive, base / 'duplicate-out', expanded=256, max_files=8)
        except ValueError as exc:
            results.append({'case': 'normalized-duplicate', 'rejected': True, 'error': str(exc)})
        else:
            raise AssertionError('duplicate')
        for index, (name, kind) in enumerate((
            ('.git', 'file'), ('.hg', 'directory'), ('mozconfig', 'broken-symlink'),
        )):
            material = base / ('material-' + str(index))
            material.mkdir()
            (material / 'fixture').write_bytes(b'x')
            marker = material / name
            if kind == 'file':
                marker.write_bytes(b'x')
            elif kind == 'directory':
                marker.mkdir()
            else:
                marker.symlink_to('missing')
            try:
                native.capture_material_tree(material)
            except ValueError as exc:
                results.append({'case': 'excluded-' + name + '-' + kind, 'rejected': True, 'error': str(exc)})
            else:
                raise AssertionError(name)
        with mock.patch.dict(os.environ, {
            'PATH': '/usr/bin:/bin', 'HOME': '/synthetic/home',
            'GITHUB_TOKEN': 'synthetic-never-sent', 'OPENAI_API_KEY': 'synthetic-never-sent',
            'PYTHONPATH': '/synthetic/injected', 'LD_PRELOAD': '/synthetic/injected',
            'BASH_ENV': '/synthetic/injected', 'GIT_CONFIG_COUNT': '1',
        }, clear=True):
            env = native.child_environment(base / 'native-state')
            source_env = source.child_environment()
        forbidden = {'GITHUB_TOKEN', 'OPENAI_API_KEY', 'PYTHONPATH', 'LD_PRELOAD', 'BASH_ENV', 'GIT_CONFIG_COUNT'}
        assert not forbidden.intersection(env) and not forbidden.intersection(source_env)
        results.append({'case': 'scrubbed-child-environments', 'passed': True, 'nativeKeys': sorted(env), 'sourceKeys': sorted(source_env), 'HOMEIsStillAPreconfiguredBoundary': True})

        # Only this fixture process adopts/reaps its own synthetic grandchild.
        assert ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0
        identifier = uuid.uuid4().hex
        record = base / 'own-grandchild.json'
        child_code = 'import time; time.sleep(8)'
        leader = (
            'import json,subprocess,sys\n'
            'from pathlib import Path\n'
            f'p=subprocess.Popen([sys.executable,"-B","-c",{child_code!r},{identifier!r}],start_new_session=True)\n'
            'fields=Path(f"/proc/{p.pid}/stat").read_text().rsplit(")",1)[1].split()\n'
            f'Path({str(record)!r}).write_text(json.dumps({{"pid":p.pid,"birth":int(fields[19]),"tag":{identifier!r}}}))\n'
        )
        code = None
        alive = False
        reaped = False
        try:
            code = source.execute([sys.executable, '-B', '-c', leader], base / 'source-command.log', base, timeout=2)
            owned = json.loads(record.read_text())
            actual = proc(owned['pid'])
            alive = bool(actual and actual[0] != 'Z' and actual[1] == owned['birth'])
        finally:
            if record.exists():
                owned = json.loads(record.read_text())
                actual = proc(owned['pid'])
                if actual and actual[1] == owned['birth']:
                    command = Path(f"/proc/{owned['pid']}/cmdline").read_bytes()
                    assert identifier.encode() in command, command
                    os.killpg(owned['pid'], signal.SIGKILL)
                deadline = time.monotonic() + 3
                while time.monotonic() < deadline:
                    pid, _ = os.waitpid(owned['pid'], os.WNOHANG)
                    if pid:
                        reaped = True
                        break
                    time.sleep(0.01)
        assert code == 0 and alive and reaped, (code, alive, reaped)
        results.append({'case': 'source-host-new-session-grandchild', 'exitCode': code, 'ownGrandchildAliveAfterExecuteReturned': alive, 'fixtureOnlyKilledOwnTaggedBirthCheckedGroup': True, 'fixtureReapedGrandchild': reaped})
    value = {
        'sourceHead': '718e688fbd7ad88a776534e7778ad8e4a7f67364',
        'runtimeHead': '460106115bc76b026c8bf8dad24df7fcb07f97c2',
        'sourceSha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        'nativeIOSha256': hashlib.sha256((RUNTIME / 'qa3_native_io.py').read_bytes()).hexdigest(),
        'cases': results, 'nativeOrBrowserExecuted': False,
        'networkOrModelCalled': False, 'credentialEnvironmentPassed': False,
    }
    print(json.dumps(value))


def main():
    if sys.argv[1:] == ['--cases']:
        run_cases()
        return
    output = ROOT / 'evidence/isolation-boundaries.raw.log'
    env = {'PATH': os.environ['PATH'], 'LANG': 'C.UTF-8', 'TMPDIR': '/tmp', 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1', 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null'}
    with output.open('xb') as log:
        child = subprocess.Popen([sys.executable, '-B', str(Path(__file__).resolve()), '--cases'], stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True, preexec_fn=limits)
        try:
            status = child.wait(timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=3)
            raise
    raw = output.read_text()
    assert status == 0, raw
    result = json.loads(raw.splitlines()[-1])
    result.update(exitCode=status, outerTimeout=False, resourceLimits={'ASMiB': 256, 'cpuSeconds': 10, 'fileMiB': 32, 'wallSeconds': 15})
    path = ROOT / 'evidence/isolation-boundaries.json'
    with path.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()

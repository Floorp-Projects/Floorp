import base64
import copy
import hashlib
import json
import os
import resource
import sys
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (256 * 1024**2, 256 * 1024**2))
resource.setrlimit(resource.RLIMIT_CPU, (20, 20))
resource.setrlimit(resource.RLIMIT_FSIZE, (8 * 1024**2, 8 * 1024**2))
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
BASE = Path(__file__).resolve().parents[1]
ROOT = Path('/workspace/qa-review-v030/repos/Floorp-Runtime')
work = BASE / 'fixtures/source-diagnostic-work'
work.mkdir(exist_ok=False)
scratch = work / 'scratch'
scratch.mkdir()
os.environ['TMPDIR'] = str(scratch)
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / '.github/workflows/scripts'))
from qa3_native_consume import verify_source_receipt


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode())


def save(root, path, data):
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return {'path': path, 'sha256': sha(data)}


def inventory(root):
    entries = []
    for target in sorted(root.rglob('*'), key=lambda p: p.relative_to(root).as_posix().encode()):
        if target.is_file():
            entries.append({'path': target.relative_to(root).as_posix(), 'type': 'file', 'executable': bool(target.stat().st_mode & 0o111), 'sha256': sha(target.read_bytes())})
    return {'scope': 'qa3-preconfigure-source-v1', 'entries': entries, 'sha256': digest(entries)}


recipe = work / 'recipe'
recipe.mkdir()
common_patches = [save(recipe, f'.github/patches/upstream/{number:02}.patch', f'common-byte-fixture-{number}\n'.encode()) for number in range(27)]
debug_patches = []
preimages = []
postimages = {}
for number in range(3):
    path = f'src/diagnostic{number}.cpp'
    before = f'enforce-{number}\n'.encode()
    after = f'diagnostic-{number}\n'.encode()
    save(recipe, path, before)
    patch = f'diff --git a/{path} b/{path}\n--- a/{path}\n+++ b/{path}\n@@ -1 +1 @@\n-{before.decode().strip()}\n+{after.decode().strip()}\n'.encode()
    debug_patches.append(save(recipe, f'.github/patches/debug/{number:02}.patch', patch))
    preimages.append({'path': path, 'sha256': sha(before), 'executable': False, 'contentBase64': base64.b64encode(before).decode()})
    postimages[path] = sha(after)
policy = {'schemaVersion': 1, 'comparisonPolicy': 'common-baseline-with-diagnostics', 'commonPatches': common_patches, 'debugPatches': debug_patches}
save(recipe, '.github/qa/source-policy.json', (json.dumps(policy, indent=2)+'\n').encode())
runtime = 'a' * 40
upstream = 'b' * 40
save(recipe, '.github/runtime-upstream.json', (json.dumps({'upstream': {'repository': 'mozilla-firefox/firefox', 'commit': upstream}})+'\n').encode())
baseline = inventory(recipe)
final = copy.deepcopy(baseline)
for entry in final['entries']:
    if entry['path'] in postimages:
        entry['sha256'] = postimages[entry['path']]
final['sha256'] = digest(final['entries'])
common = {'schemaVersion': 1, 'scope': baseline['scope'], 'U': {'vcs': 'git', 'repository': 'https://github.com/mozilla-firefox/firefox', 'fullRevision': upstream}, 'R': runtime, 'P': common_patches, 'transforms': [{'path': 'build/application.ini.in', 'sha256': 'c' * 64}], 'B': baseline['sha256']}
proof = {'preparation': {'executionKind': 'actual-source-preparation', 'common': common, 'delta': debug_patches, 'finalTree': final['sha256'], 'ingestion': {'runtime': runtime, 'upstream': upstream, 'relation': 'verified-ancestor', 'fullCheckout': True}, 'diagnosticPreimages': preimages, 'publicationAuthorized': False}}


def invoke(value, tree):
    try:
        verify_source_receipt(recipe, value, baseline, tree, runtime)
        return {'accepted': True}
    except (ValueError, TypeError, KeyError) as error:
        return {'accepted': False, 'error': str(error)}


result = {'schemaVersion': 1, 'runtimeSource': '460106115bc76b026c8bf8dad24df7fcb07f97c2', 'syntheticReceiptOnly': True, 'producerExecuted': False, 'consumerHarnessExecuted': False, 'credentialsPresent': False, 'limits': {'addressSpaceMiB': 256, 'cpuSeconds': 20, 'fileSizeMiB': 8, 'wallSeconds': 40}, 'baseline': invoke(proof, final), 'negative': []}
for name in ('unapplied-D', 'wrong-postimage', 'wrong-executable', 'wrong-kind', 'extra-source-entry', 'missing-preimage', 'bad-preimage-bytes', 'missing-diagnostic-declaration'):
    candidate = copy.deepcopy(proof)
    tree = copy.deepcopy(final)
    if name == 'unapplied-D':
        tree = copy.deepcopy(baseline)
    elif name in {'wrong-postimage', 'wrong-executable', 'wrong-kind'}:
        entry = next(x for x in tree['entries'] if x['path'] == preimages[0]['path'])
        if name == 'wrong-postimage':
            entry['sha256'] = '0' * 64
        elif name == 'wrong-executable':
            entry['executable'] = True
        else:
            entry.clear()
            entry.update(path=preimages[0]['path'], type='symlink', target=preimages[1]['path'])
    elif name == 'extra-source-entry':
        tree['entries'].append({'path': 'undeclared.txt', 'type': 'file', 'executable': False, 'sha256': '0' * 64})
        tree['entries'].sort(key=lambda x: x['path'].encode())
    elif name == 'missing-preimage':
        candidate['preparation']['diagnosticPreimages'].pop()
    elif name == 'bad-preimage-bytes':
        candidate['preparation']['diagnosticPreimages'][0]['contentBase64'] = base64.b64encode(b'unapproved\n').decode()
    else:
        candidate['preparation']['delta'].pop()
    tree['sha256'] = digest(tree['entries'])
    candidate['preparation']['finalTree'] = tree['sha256']
    result['negative'].append({'mutation': name, **invoke(candidate, tree)})
target = BASE / 'evidence/source-diagnostic-negative-results.json'
target.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'evidence': str(target), 'baselineAccepted': result['baseline']['accepted'], 'negativeRejected': sum(not x['accepted'] for x in result['negative']), 'negativeCount': len(result['negative'])}))

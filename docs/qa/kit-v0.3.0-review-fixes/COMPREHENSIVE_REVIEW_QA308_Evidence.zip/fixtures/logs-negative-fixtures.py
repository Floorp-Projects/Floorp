"""QA308 logs/provenance review fixtures: data only, no native or network."""
from __future__ import annotations
import copy
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
from unittest import mock

BASE = Path('/workspace/qa-review-v030')
KIT = BASE / 'fixes/archive-verification/Floorp_QA_Implementation_Kit_v0.3.0'
SCRIPTS = BASE / 'repos/Floorp-Runtime/.github/workflows/scripts'
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(KIT / 'tools/qa'))
sys.path.insert(0, str(KIT / 'tools/qa/tests'))
import core
import test_core
from qa3_mozlog import verify_mozlog
from qa3_native_transport import validate_context, same_execution, verify_artifact_metadata
from qa3_source_cohort import verify_subject, verify_profile, digest

source_path = BASE / 'repos/Floorp/tools/qa3/source.py'
spec = importlib.util.spec_from_file_location('qa308_floorp_source', source_path)
source = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source)
results = []

def call(name, fn):
    try:
        value = fn()
        results.append({'fixture': name, 'outcome': 'ACCEPT', 'result': value})
    except (ValueError, TypeError, KeyError, OSError) as exc:
        results.append({'fixture': name, 'outcome': 'REJECT', 'type': type(exc).__name__, 'reason': str(exc)})

with tempfile.TemporaryDirectory(prefix='qa308-logs-') as temp:
    root = Path(temp)
    path = root / 'raw.jsonl'
    case = {'suite': 'xpcshell', 'id': 'xpcom/test.js', 'minimumAssertions': 1}
    process = {'exit': 0, 'stop': None, 'ownedCleanupComplete': True}
    events = [
        {'action': 'suite_start', 'tests': ['xpcom/test.js']},
        {'action': 'test_start', 'test': 'xpcom/test.js'},
        {'action': 'test_status', 'test': 'xpcom/test.js', 'status': 'PASS', 'subtest': 'assert'},
        {'action': 'test_end', 'test': 'xpcom/test.js', 'status': 'OK'},
        {'action': 'suite_end'},
    ]
    def native(value, state=process):
        path.write_text(''.join(json.dumps(v) + '\n' for v in value))
        return verify_mozlog(path, case, root, state)
    call('runtime-valid-single-required-assertion', lambda: native(events))
    for reason in ('MISSING', None, '', '   ', False, 0, {}):
        changed = copy.deepcopy(events)
        if reason == 'MISSING': changed[2].pop('subtest')
        else: changed[2]['subtest'] = reason
        call('runtime-malformed-subtest-' + json.dumps(reason), lambda v=changed: native(v))
    for exit_code in (False, 0.0):
        call('runtime-untyped-outer-exit-' + repr(exit_code), lambda e=exit_code: native(events, {**process, 'exit': e}))
    for cleanup in ('yes', 1):
        call('runtime-untyped-cleanup-' + repr(cleanup), lambda c=cleanup: native(events, {**process, 'ownedCleanupComplete': c}))
    for bad in (
        {'action': 'process_exit', 'exitcode': False},
        {'action': 'process_exit', 'exitcode': 1},
        {'action': 'unknown'},
        {'action': 'log', 'level': 'WARNING', 'message': 'Retrying after first failure'},
        {'action': 'test_status', 'test': case['id'], 'status': 'SKIP', 'subtest': 'assert'},
    ):
        changed = copy.deepcopy(events);changed.insert(3,bad)
        call('runtime-bad-event-' + json.dumps(bad, sort_keys=True), lambda v=changed: native(v))
    truncated = events[:-1]
    call('runtime-incomplete-lifecycle', lambda: native(truncated))
    raw = b'x' * (1024**2 + 1)
    path.write_bytes(raw)
    sizes = []
    class ObservedIterator(io.BytesIO):
        def __iter__(self): return self
        def __next__(self):
            line = self.readline()
            sizes.append(len(line))
            if not line: raise StopIteration
            return line
    with mock.patch.object(Path, 'open', return_value=ObservedIterator(raw)):
        call('runtime-postallocation-line-limit', lambda: verify_mozlog(path, case, root, process))
    results[-1]['returnedLineBytesBeforeRejection'] = sizes
    results[-1]['claimedLineCap'] = 1024**2

    context = {'schemaVersion':1,'executionRepository':'owner/private','controllerHead':'a'*40,
               'controllerWorkflow':'b'*40,'runtimeRecipe':'c'*40,'run':123,'attempt':1,
               'createdAt':'2026-10-09T00:00:00Z','buildID':'20261009000000',
               'privateExecution':True,'controllerUid':1000,'publicationAuthorized':False}
    call('native-context-valid', lambda: validate_context(context))
    for field, value in [('run',False),('attempt',0),('attempt',1.0),('privateExecution','true'),
                         ('publicationAuthorized',True),('buildID','20261009000001')]:
        changed = {**context,field:value}
        call('native-context-invalid-'+field+'-'+repr(value),lambda v=changed: validate_context(v))
    call('native-context-cross-attempt',lambda: same_execution({**context,'attempt':2},context))
    call('native-context-cross-R',lambda: same_execution({**context,'runtimeRecipe':'d'*40},context))
    meta={'id':456,'name':'qa3-primary-123-1','expired':False,'digest':'sha256:'+'e'*64,
          'size_in_bytes':10,'workflow_run':{'id':123,'head_sha':'a'*40}}
    call('artifact-valid',lambda:verify_artifact_metadata(meta,context,456,'primary','e'*64))
    for field,value in [('name','qa3-primary-123-2'),('expired',True),('digest','sha256:'+'f'*64),
                        ('workflow_run',{'id':124,'head_sha':'a'*40}),('workflow_run',{'id':123,'head_sha':'f'*40})]:
        call('artifact-wrong-'+field+'-'+repr(value),lambda m={**meta,field:value}:verify_artifact_metadata(m,context,456,'primary','e'*64))

    f=test_core.KitTest();f.setUp()
    try:
        call('kit-existing-final-positive',lambda:f.evaluate())
        for status in ('FAIL','SKIP','ERROR','TIMEOUT','INCOMPLETE'):
            rows=copy.deepcopy(f.records);rows[0]['status']=status;rows.append({**copy.deepcopy(f.records[0]),'attempt':2})
            call('kit-first-'+status+'-then-PASS',lambda r=rows:f.evaluate(r))
        call('kit-attempt-hole',lambda:f.evaluate(f.records+[{**copy.deepcopy(f.records[0]),'attempt':3}]))
        call('kit-foreign-plan',lambda:f.evaluate([{**r,'planId':'sha256:'+'f'*64} for r in f.records]))
        call('kit-foreign-subject',lambda:f.evaluate([{**r,'subjectId':'sha256:'+'f'*64} for r in f.records]))
        production=core.make_plan(f.subject,f.policy,'production-package-readiness')
        rows=[core.result(production,c['id'],'PASS',c['kind'],f.evidence,{'synthetic':True}) for c in production['cases']]
        call('kit-all-planned-with-PASS-records',lambda:core.evaluate(production,f.subject,f.policy,rows,f.root))
        unknown=copy.deepcopy(f.policy)
        for row in unknown['profiles']['production-package-readiness']['cases']:row['implementation']='not-onboarded'
        p=core.make_plan(f.subject,unknown,'production-package-readiness')
        rows=[core.result(p,c['id'],'PASS',c['kind'],f.evidence,{'synthetic':True}) for c in p['cases']]
        call('kit-unknown-not-onboarded-with-PASS-records',lambda:core.evaluate(p,f.subject,unknown,rows,f.root))
    finally:f.doCleanups()

    plan=source.read_json(source.ROOT/'tools/qa3/source-plan.json')
    group=plan['groups'][1]
    def junit(xml):
        p=root/'report.xml';p.write_text(xml)
        rows=source.read_junit(p,source.ROOT,source.GROUPS['node-intake'][0])
        source.validate_cases(group,rows)
        return {'count':len(rows),'allPASS':all(v['verdict']=='PASS' for v in rows)}
    def xml_cases(patch=None):
        import xml.etree.ElementTree as ET
        suite=ET.Element('testsuite',{'tests':'28','failures':'0','errors':'0','skipped':'0'})
        for idx,c in enumerate(group['cases']):
            x=ET.SubElement(suite,'testcase',{'name':c['name'],'classname':'test'})
            if patch and idx==0:patch(x)
        return ET.tostring(suite,encoding='unicode')
    call('floorp-generic-Node-origin-valid',lambda:junit(xml_cases()))
    call('floorp-explicit-foreign-Node-file',lambda:junit(xml_cases(lambda x:x.set('file','other.js'))))
    call('floorp-explicit-empty-Node-file',lambda:junit(xml_cases(lambda x:x.set('file',''))))
    call('floorp-Node-skip',lambda:junit(xml_cases(lambda x:__import__('xml.etree.ElementTree',fromlist=['SubElement']).SubElement(x,'skipped'))))

print(json.dumps({'schemaVersion':1,'network':False,'browser':False,'native':False,
                  'fixtures':results,'fixtureCount':len(results)},ensure_ascii=False,indent=2))

# QA308 独立再レビュー — source-cohort / Debug・PGO / official Firefox

2026-10-09。対象は [frozen-inputs.json](../frozen-inputs.json) の固定点である。この担当範囲では新しい P0/P1 の実コード欠陥は確認していない。新規に確認した P2 は、build-profile 入力拒否 contract が実 setup 入口に接続されていないこと。既知の **QA306 P1-03（設計・正式 qualification 再利用前の source-cohort 規範不足）は未解消**である。未実装・未実行と現在の誤成功を分けて扱う。

Draft の shadow/限定 proof をレビュー用コードとして保持する判断は **Go with P2 open**。private native proof の運用 readiness と正式 source/Debug/PGO/product qualification は **未実証**。このレビューはその実行・昇格を認可しない。QA3 による publish-ready の判断は **No-Go**。この区分は ordinary public GitHub-hosted colocated PR CI の許可や既存公開 gate に対する一括停止判断ではない。今回は既存 public CI の再 dispatch も行っていない。

## 固定点と独立性

| 対象 | 固定 head / base | 保存した差分 |
|---|---|---|
| Runtime #83 | `81c92fc4bbbc13b4fd4c2a2adaf6a137e342bd53` / `c74fe1a545d275cdd710ab44701c1ee0dd6b0eae` | [source-runtime83.patch](source-runtime83.patch), SHA256 `7b090ce5232d45d36aa5a439b10b89a3d7d32e099bdc32a0983e7b4d861419a2` |
| Runtime #84 | `460106115bc76b026c8bf8dad24df7fcb07f97c2` / `81c92fc4bbbc13b4fd4c2a2adaf6a137e342bd53` | [source-runtime84.patch](source-runtime84.patch), SHA256 `895fc76429b134ed2f8b60bc83d780bfb62fbddf28bc204727df432608d36bee` |
| Floorp #2889 | `718e688fbd7ad88a776534e7778ad8e4a7f67364` / `013bb6c9ed19250592898ec8fbc8d7d24aa847be` | [source-floorp2889.patch](source-floorp2889.patch) |
| Floorp #2893 | `d9e03b8c4ccf84a52db8a7532fdd8e3fd1157f89` / 同上 | [source-floorp2893.patch](source-floorp2893.patch) |

[固定 file/hash/path index](source-fixed-index.json) は Runtime 24 files の `git show HEAD:path` と checkout bytes の一致、#83/#84 diff の manifest 一致を記録する。[Floorp diff index](source-floorp-diff-index.json) は #2889/#2893 の diff hash と paths を manifest に照合した。元 ZIP の SHA256 は `a4af60380399050f82465864734391227ab34024d26bdf16c31559e2824a8d50`、修正版 ZIP は `60ad9a63c9fa7e328cc2da41187c6b725a64ee6144aaac8f66c2ebc3260710f2`。この担当は指定された安全な展開を読み、ZIP safe extraction 全体の再検証は archive 担当の範囲としている。

各 repo の AGENTS.md と Runtime `.agents/skills/README.md` を確認した。担当に対応する専用 skill の実行はない。実装者の説明を acceptance 根拠にせず、固定ソースと規範を先に読み、最後に先行 source-cohort / QA303 / QA306 報告と照合した。前の PASS/Go を今回の結果として流用していない。

## P2-SOURCE-01 — profile の入力拒否 contract が実 setup で適用されない（新規確認）

**場所:** Runtime #83 `81c92fc…`、#84 `460106…` の [.github/workflows/scripts/qa3_build_profile.py](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts/qa3_build_profile.py:25) `profile` L25–51 と `main` L129–138、[setup-floorp.sh](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts/setup-floorp.sh:123) PGO 分岐 L123–139。[test_qa3_build_profile.py](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts/test_qa3_build_profile.py:128) `test_invalid_targets_modes_and_profile_inputs_are_rejected` L128–138 は `profile(*args)` のみを呼ぶ。

`profile()` は不正 target、Linux ARM PGO、非 PGO への mode/artifact、use の profile 欠落、generate への profile 指定を拒否する。一方、実 setup が呼ぶ `qa3_build_profile.main` は `--config/--debug/--pgo` しか受け取らず、tests override だけを適用する。platform/arch/mode/profile を解決して `profile()` と `verify_config()` に渡す処理はない。

**前提・再現:** 既存 reusable `common-build.yml` を不正な string input で呼ぶか、setup を直接呼ぶ。固定 setup と templates のコピーを fixture 内に置き、`sudo`/`rustup`/`mach` を exit0 の stub にして、実 browser・bootstrap・build を起動せず実 script を実行した。6 入力すべてで `profile()` は拒否し、実 setup は exit0 になった。[実行 fixture](../fixtures/source-negative.py)、[完全な観測 JSON](source-negative-results.json)、[実行 log](source-negative-run.log)。

| 入力 | 実 setup の観測 |
|---|---|
| Windows / aarch64 / opt | x86_64 target の config を生成して成功 |
| Linux / aarch64 / PGO generate | ARM template に profile-generate を加えて成功 |
| Linux x64 / Debug / PGO=false / mode=use / old-profile | 非 PGO への mode/profile を無視して成功 |
| Mac ARM / PGO use / profile 名なし | profiling flag を生成せず成功 |
| Mac x64 / PGO generate / old-profile | generate で profile 名を受理して成功 |
| Linux x64 / PGO=true / invalid-mode | profiling flag を生成せず成功 |

**影響と限定:** 想定 role と生成 config が異なっても入口で失敗せず、不要な重い build を開始し得る。`.github/qa/README.md` L17–20 の「real setup の invalid combinations 検査」は、この組合せ拒否については実入口を検査していない。通常の daily wrappers は Windows x64、Linux ARM `pgo:false`、generate/use と artifact 名を固定するため、今回の 6 入力を ordinary daily call が実際に作る証拠はない。private #84 の `prepare_source` L399–403 は固定 Linux x64 canonical-debug と `verify_config` を直接使用するため、この欠陥による limited proof の偽 PASS は示していない。

**既存との差分:** base `c74fe1…` の setup の platform/PGO 分岐は同じ挙動であり、#83 が新しい不正-input build を導入したとは主張しない。#83 は helper/contract/tests と L137–139 の接続を追加したが、入力拒否部分は接続しなかった。新規の指摘はこの契約と入口・試験範囲の不一致で、既知 QA303/QA306 の修正 4 件とは別である。

**推奨修正:** 副作用前に全 input を `profile(platform, arch, debug, pgo, mode, artifact)` で解決し、最終 generated config を同じ expectation で `verify_config` する。legacy Debug+PGO を canonical として受理しない現 policy を維持する。実 setup の不正入力が非ゼロで止まり、bootstrap/build stub に到達しない負例を追加し、generation-only と effective configure を区別する。

## P1-SOURCE-KNOWN — kit qualification 規範が exact source-cohort と未整合（既知・未解消）

**場所:** Floorp #2893 `d9e03b8…` が保存する repaired kit [docs/12-evidence-contracts.md](/workspace/qa-review-v030/fixes/archive-verification/Floorp_QA_Implementation_Kit_v0.3.0/docs/12-evidence-contracts.md:17) §2 L17–33、特に L25。同内容は DESIGN.md §12 にもある。[独立 hash 比較](source-static-summary.json) で docs/12、DESIGN、build-policy、ci-graph が元 kit から変わっていないことを確認した。

compiled upstream と production patch の比較は記述する一方、Runtime orchestration head 差を「compiled-source 非影響が認証できる場合」に許容する。最新の exact `U={vcs,repository,fullRevision}` / `R` / ordered `P` / common transforms / `B` を必須 identity とする規範になっていない。取得 source と canonical U、Git/Hg namespace、B の採取 phase、現在の common-baseline-with-diagnostics と strict-same-source の差、D/F と PGO profile edge も規範の表に十分結合されていない。

**前提・再現・影響:** この docs の許容を今後の qualification adapter に実装すると、PR83 の `same_cohort` L284–291 が拒否する R 差を許容できてしまう。まだ Debug subject/qualification validator 未実装と L9–12 に明記されているため、現在のコードで誤った資格を発行した実証ではない。正式再利用・公開 required gate の設計 blocker という P1 分類であり、review-only Draft の現在の公開 bypass と混同しない。

**推奨修正:** docs/12 と DESIGN、machine-readable design/policy/schema、QA3-01/02/08 acceptance を同じ exact common contract に揃える。Debug は同じ B + declared D の系列として記録し、relaxed security 条件を製品に流用しない。production PGO/opt と独立した product result、producer 認証・失効・再利用 edge を必須にする。元の QA306 P1-03 と同じ未解消事項で、今回の stdin/mozlog/attempt/typed-exit 4 修正には含まれない。

## U / R / P / transforms / B / D / F の追跡結果

| 観点 | 固定ソースで確認した処理 | このレビューの証拠・限界 |
|---|---|---|
| U namespace | `qa3_source_cohort.verify_common` L260–267 は canonical Git repository/full 40 SHA を要求する。preflight は pin の U を別 field に保持 | Hg namespace を含む common 差 6 負例を拒否。公式 Hg との mapping は未検証 |
| R ingestion | `verify_checkout` L144–168 は expected HEAD、nonshallow/nonsparse/skip-worktree、U ancestor、R の raw Git blobs/type/mode/path 集合を照合 | review checkout は shallow=true、U object 不在。実 R→U history relation をこの checkout で証明していない |
| P | policy の common 27 + Debug 3、`verify_patches` L71–91 は全 membership/order/bytes を確認。`prepare_source` L261–281 は実 working tree と別 cached expected index に同じ ordered P を適用 | 固定 R の P/D 30 件の hash と policy が一致。実 27 patches を full source に適用して B を作った証拠ではない |
| common transforms | `prepare_source` L282–355 は branding inputs/outputs、update URL の preimage、1 回置換、write 前の期待 bytes、別 index を記録 | fixed code を読取。独立 D fixture はこれら実 Runtime transforms の native execution ではない |
| B scope | `capture_tree` は regular bytes、executable、inside-tree symlink、untracked/ignored inputs と walk error を扱い、root `.git/.hg/mozconfig` だけを除外 | generated mozconfig は別 digest。OBJDIR/output を outside に要求。実 full Runtime B は未計算 |
| D / F | `diagnostic_expectation` は fixed D の実 replay 結果を期待 F とする。producer は適用後 F を完全比較。consumer `verify_source_receipt` L48–141 は authenticated B preimages から同じ D を再適用し全 expected F を照合 | synthetic receipt の正常基準を受理し、F=B、誤 postimage/mode/type、extra source、preimage 欠落/改変、D declaration 欠落の 8 負例を拒否。実 artifact producer 認証や native harness の結果ではない |
| exact build subject | `verify_build_subject` L412–419 は trusted expected role/target/D/F/config/toolchain/artifact/run/attempt と source を比較 | candidate JSON の self declaration だけでは build を attestation しない。actual producer/issuer は別前提 |

[source-diagnostic-negative-results.json](source-diagnostic-negative-results.json) と [fixture](../fixtures/source-diagnostic-negative.py) に D/F 8 負例を保存した。先行 QA303 の「D path whitelist だけで consumer が任意 postimage を受理する」問題を現在の source の問題として再掲しない。今回の全 F exact comparison で上記の変異を拒否した。

policy preflight は今回も `B/F=null`, `upstreamIngestion/nativeQualification=UNVERIFIED`, official `unverified/advisory`, `publicationAuthorized=false` を保持した。[成功 receipt](source-current-policy-preflight-single-thread.json)。最初の 256 MiB 上限実行では Git の threaded lstat が resource error となり FAIL receipt を保持した。[初回 receipt](source-current-policy-preflight.json), [raw log](source-current-policy-preflight.log)。同じ上限で `core.preloadIndex=false` を per-process 環境に指定すると成功した。repo config は変更していない。この制約下の Git thread error を source code defect として数えない。

## Debug と production PGO/opt、profiling edge

Runtime Debug の D3 は HTTP(S) CSP checks、SystemPrincipal remote-load restriction、CSP/about-page assertions を緩和する。`setup-floorp.sh` は Debug daylight branding/`--enable-debug`、Mac Debug content sandbox override を加える。#83 の追加は `debug && !pgo` だけで tests を明示 enable とし、production-opt/PGO/legacy Debug+PGO の既存 tests flags は維持する。Mac templates は active disable-tests、Windows/Linux templates はコメントの disable-tests であり、template 読取を effective configure と呼ばない。

generate は instrumented workload 用、use は `MOZ_LTO=cross` と cross profile-use、actual profdata/jarlog paths を消費する。flat chrome は profile-generate を除外し、Debug/production branding も異なる。Linux ARM は daily-build L79–89 と Linux wrapper L95–108 で `pgo:false`。Debug/PGO binary digest・BuildID は別 identity、Mac universal は arch ごとの native identity と merge/repack を別に保持する必要がある。Debug の D と緩和 sandbox に対する PASS は製品の該当 security path、PGO miscompile、製品 performance を証明しない。[Mozilla PGO 一次資料](https://firefox-source-docs.mozilla.org/build/buildsystem/pgo.html) も generate → binary workload → use の別段階を記述している。

`qa3_source_cohort.verify_profile` L312–353 は generating subject/artifact/run/attempt、workload digest、nonempty profdata/jarlog の実 SHA256、同じ U/R/P/transforms/B、target/toolchain/D/F を要求する。generate/use の config digest の違いは許容する。独立 miniature fixture で正常基準を受理し、foreign target/toolchain/R/role/F、producer run/attempt/subject/artifact、workload、profdata/jarlog hashes、同名ファイルの bytes 差など **15 負例を拒否**した。[結果](source-negative-results.json)。LLVM profile format の実検査や real workload の実行をこの fixture が証明することはない。

**既知の段階差:** この verifier の callsites は contract tests 内であり、既存 `common-build.yml` L144–160 と profile collection workflows は生成 package/profile を artifact 名で受け渡す。Linux/Windows/Mac の Stage1 native identity checks と raw output 取得は既存にあるが、全 cohort/profile provenance を production entrypoint で機械検証する新 contract にはまだ接続されていない。legacy `record_runtime_source.record_source` L11–43 は version 3 files と native patch 1 本の final file hashes を確認するが、P27/transforms/B/D/F/effective config/profile edge 全体を記録しない。README L80–86 が promotion 前作業として宣言するこの gap を、現在 shadow の偽 qualification 発行として分類しない。

## Floorp package/common patches との接続

Floorp #2889 の `package.yml` L639–701 は authenticated Runtime R を checkout し、Runtime upstream P を適用後、Floorp の common 8 patch を追加する。既に source build に適用された patch は exact reverse-applicable check で skip する。Mac native compositor/input patch の bytes は Runtime P、Runtime pin、現在の Floorp common patch のすべてで SHA256 `43a278bedfe0faeb9b747f47b32b9b060683ddbb2e58953d03d3b5470e47c2e8` が一致した。[独立 parity と patch target inventory](source-static-summary.json)。同一 bytes でも packaging 時の source 適用が prebuilt XUL/shim を再compile するとは扱わない。

`package.yml` L808–821 の validator は authenticated R/pin と当該 compiled native patch、Mac packaging provenance を照合する。L957–982 の Floorp branding/version/updater/config 変換と他の JS/CSS common patches は Floorp overlay/product inputs である。L966–972 の `--enable-release --disable-tests --enable-artifact-builds` はこの QA3 diff で維持される。native machine code を変更するには fresh Runtime compile が必要であり、test-support は `MOZ_ARTIFACT_FILE` の primary package から自動的に得られない。[Mozilla artifact-builds 一次資料](https://firefox-source-docs.mozilla.org/contributing/build/artifact_builds.html)。Runtime-only Debug receipt を最終 Floorp overlay の product qualification とする根拠はない。

## Official Firefox の独立再確認

保存された official Firefox 157.0.1 Linux x64/en-US tar.xz を新しい bounded subprocess で hash し直し、展開・実行せず application.ini/platform.ini の 2 member だけを stream 読取した。[新 raw metadata](source-official-metadata.json), [script](../fixtures/source-official-read.py), [log](source-official-read.log)。

| 項目 | 独立観測 |
|---|---|
| URL | `https://archive.mozilla.org/pub/firefox/releases/157.0.1/linux-x86_64/en-US/firefox-157.0.1.tar.xz` |
| サイズ / SHA256 | 88,413,848 bytes / `0d92bf39cdd174f5f361008509310bdefbce72a57ca10523a43b32d62dc699b6` |
| saved official SHA256SUMS | exact entry 1 件と一致。checksum list SHA256 `16e808f33acfacfe6922ac182f1086faeb143970d61e2a11e55c422b8b33b316` |
| application/platform SourceRepository | `https://hg.mozilla.org/releases/mozilla-release` |
| application/platform SourceStamp | Hg `737ec77d798755890b062aab541a90d6c75afd19` |
| application/platform BuildID | `20261005135250` |
| Runtime U | Git `https://github.com/mozilla-firefox/firefox` @ `0c469c2352451630bc69fc328c9f0c589c6c534d` |

canonical Git の [exact commit page](https://github.com/mozilla-firefox/firefox/commit/0c469c2352451630bc69fc328c9f0c589c6c534d) は web で読取できた。しかし Git↔Hg mapping、tag の independent resolution、Runtime R の U ingestion relation、checksum signature、source archive と他 OS の official artifacts は未検証。web の official Hg json-rev/Git API endpoints は利用不可、credential-free subprocess の同 read は connection refused だった。version/tag と別 namespace の 40 桁を同一 U として扱わない。officialMatch は advisory/unverified のまま。

## 検証範囲・残る限界

独立に実行したのは stub-only setup 6 件、common identity 差 6 件、profile 差 15 件、consumer diagnostic replay 差 8 件、policy preflight、および official archive の hash/2 metadata member 読取である。source fixtures は own subprocess、address space 256 MiB、CPU 20 秒、FSIZE 8 MiB、wall 40 秒、core dump 無効、credential-free 環境。official read は同 address space、CPU 30 秒、FSIZE 4 MiB、wall 60 秒。全 fixture outputs は source-* paths 内に保存した。native/full build、実 browser、CI dispatch、Blacksmith 登録/有料 run、sign/notarize/publish、source edits/commit/push/merge/release は行っていない。[最終3 repo状態](source-static-summary.json) は fixed heads と clean status を記録する。

[Searchfox availability](source-searchfox-availability.json) は `command -v searchfox-cli` exit1。bootstrap の依存問題は既知の前提であり、この review で再 bootstrap はしていない。上流全体への blind local rg は行わず、custom `.github` 差分の narrow search と plan/先行 raw data から判明した exact file/commit の読取に限定した。cold native/configure、実 test archives/helper capabilities、PGO profile format/workload、producer 署名・資格失効の実運用を未実証のまま「問題なし」としない。

親から依頼された mozlog formal cross-check も固定 R の known exact files の AST 読取で行った。[source-mozlog-subtest-formal.json](source-mozlog-subtest-formal.json) に hashes/functions/lines を保存した。`structuredlog.test_status` L490–531 は `Unicode("subtest")` を required とし、`log_action.convert` は missing subtest を拒否する。一方 `Unicode.convert` L165–173 は None/empty/whitespace を受理し、他 type を string 化する。したがって missing/raw nonstring event と、ordinary writer が emit できる None/empty/whitespace を別に判断すべきである。この担当は追加 strict nonempty policy を upstream 既存 contract の欠陥と分類していない。

`.git/refs/replace` / graft が Git ancestry/tree 読取へ影響する可能性は isolation 担当へ共有した。fresh clone + controller-owned readonly recipe から実際の入口で到達する証拠はこの担当で確立しておらず、confirmed finding に加えていない。

# QA308 workflow・公開ゲート独立レビュー

固定ソースでは既存の通常 PR CI、stable の provenance/native/signing/notarization ゲートと環境参照は保持されている。新しい Source QA は非必須の shadow であり、最終 QA・承認後の QA sidecar 再認証・公開必須化は未接続である。新 private native proof は公開リポジトリでは起動を拒否し、既存 pipeline からの caller もない。private proof 実行前には新規 P1 の cleanup 修正と外部 worker 境界の実証が必要である。

通常 `colocated_runner_test.yml` の Linux prebuilt browser CI を、新 private Debug build／Blacksmith／公開処理と一括して No-Go にした前段判断は是正する。取消済み run を成功扱いにはしない。本レビューでは再 dispatch・run 取消・workflow 設定変更を行っていない。

## 固定入力と検証方法

| 対象 | head | base |
|---|---|---|
| Floorp #2889 | `718e688fbd7ad88a776534e7778ad8e4a7f67364` | `013bb6c9ed19250592898ec8fbc8d7d24aa847be` |
| Floorp #2893 | `d9e03b8c4ccf84a52db8a7532fdd8e3fd1157f89` | `013bb6c9ed19250592898ec8fbc8d7d24aa847be` |
| Runtime #83 | `81c92fc4bbbc13b4fd4c2a2adaf6a137e342bd53` | `c74fe1a545d275cdd710ab44701c1ee0dd6b0eae` |
| Runtime #84 | `460106115bc76b026c8bf8dad24df7fcb07f97c2` | `81c92fc4bbbc13b4fd4c2a2adaf6a137e342bd53` |

`frozen-inputs.json` の SHA を `git show` で読む。191 個の source snapshot と SHA256 を [workflow-source-index.json](workflow-source-index.json) に保存した。以降の行番号はこの固定 head のファイルを指す。repo の AGENTS.md と関連する `.agents` skill 名一覧を確認し、対象に該当する追加 local skill はなかった。添付設計はデータとして比較した。

既存 YAML の保持検査は Floorp 20 files、Runtime #83 21 files、#84 22 files を対象にした。Floorp #2889 の orchestration 2 files は追加 `source-qa-shadow` job だけを取り除いて既存の全 parsed keys が同じであることを検査し、それ以外は byte equality を検査した。#2893 の既存 20 workflows はすべて base と byte equality。Runtime の既存 workflows も両 PR で byte equality。`on` を YAML 1.1 の boolean に誤変換しない parser を使用した。

展開済み元 ZIP と修正版 ZIP の `DESIGN.md`＋`docs/00`～`13` の 15 files はすべて byte equality。workflow 設計の説明内容は修正版でも変わっていない。これは文書一致の検証であり、設計 DAG が実 CI に適用済みであるという証明には使用していない。

## 新規 finding

### P1 — native log sink の I/O 例外が強制 cleanup と process receipt を飛ばす

- Commit: Runtime #84 `460106115bc76b026c8bf8dad24df7fcb07f97c2`。
- Location: `.github/workflows/scripts/qa3_native_io.py`, `run_owned.drain`, L352 の `key.data.write(block)`、`run_owned` の cleanup L374～416、特に L398/L416 の `drain()`。source SHA256: `d1d5e86dc8ae63977248847e1bd3192b5267966ec8011aa2390fd486f2e7bd86`。
- Repro: 独立 isolation 担当の [isolation-io-cleanup.json](isolation-io-cleanup.json) / `fixtures/isolation-io-cleanup.py`。本担当は固定 source hash と control flow を照合した。fake sink の `EDQUOT` を通常 drain と finally drain に注入し、所有・birth identity を確認した TERM 無視 child が `run_owned` の例外後も生存、process receipt は未出力となった。fixture 自身が当該 child だけを KILL/reap して最終残留ゼロ。native build/browser/network/資格情報の使用なし。
- Impact: disk/quota/log I/O failure が発生すると、finally 内のログ処理の例外で SIGKILL/reap と receipt 書き出しまで進めず、新 private builder/consumer の owned child が残る。private 有料実行では想定した停止・資源消費境界が破れる可能性がある。PASS や公開権限を作ることを示した finding ではない。
- Recommendation: sink write/flush/close failure の記録と process-group/owned-child cleanup を分離し、ログ失敗後も TERM→KILL→reap を最後まで行い、可能な場所に INCOMPLETE/cleanup failure receipt を残す。ENOSPC/EDQUOT/OSError を通常 drain と cleanup drain に入れ、TERM 無視 descendant が残らない負例を追加する。修正前の private native execution は No-Go。
- Boundary: `/opt/qa3/bin/launch-native-proof` による whole-cgroup stop は追加 mitigation の prerequisite である。未提供・未実証の launcher を、この source defect が解決済みという根拠にしない。通常 Floorp PR CI の prebuilt browser path にはこの helper の呼び出しがなく、同 CI を止める理由にはならない。

新規 P0 は検出していない。これは担当 scope 内の結論であり、全 repo の包括的な無欠陥保証ではない。

## P2 — 前段の通常 CI 取消分類を是正する

Location は両 Floorp 固定 head で base と同じ `.github/workflows/colocated_runner_test.yml`、`on` L5～12、`smoke` L16～52、`native-runtime` L54～80、locked install L109～125、browser test L267～283/L339～340。

この workflow は全 PR を受け、`contents: read`、GitHub-hosted `ubuntu-24.04`/ARM、Windows、macOS の matrix を使う。全 matrix が既成 locked Runtime asset を取得・認証・検査し、Linux x64 だけがブラウザーを実行する。唯一の実 PAT 宣言 L35～38 は `if: github.event_name != 'pull_request'` の metadata step に限定され、PR の smoke/native-runtime jobs に署名鍵・公開 token・protected environment・private proof caller はない。

ブラウザー step の実呼出先も追跡した。`tools/runtime-lock/runtime_lock_cli.ts:runRuntimeLockCli` L171～200 は locked asset の validation/install、`tools/feles-build.ts:runTest` L183～224 は default locked Runtime を利用し、`tools/src/initializer.ts:run` L1955～1972 は override がない場合 release lock を選択する。`tools/src/builder.ts:run` L94～121/L267～270 は test mode の bridge/features の Deno/Vite builds を選択する。新 Debug Runtime の native compilation ではない。

固定 #2893 内の歴史 raw JSON も確認した。[workflow-cancelled-ci-history.json](workflow-cancelled-ci-history.json) では run `37933791186` が `pull_request` / `colocated_runner_test.yml`、smoke と ARM/Windows/macOS の 3 artifact jobs は成功、Linux x64 は「Run combined browser test suite against locked Runtime」中だった。その後の captured response は `completed/cancelled`。run head は前段の `2d2be1eb…` であり、今回の固定最終 head の成功証拠には使わない。run `37934603330` の smoke 中取消は親担当から伝達された観測で、本担当は live API で再照会していない。

Impact は既存許可内の通常 CI 証拠を不要に失ったこと。native qualification や署名公開の禁止を、全 browser 実行禁止へ拡張した根拠は固定ソースにはない。Recommendation は既存通常 CI を許可対象として扱い直し、取消済みの Linux browser completion は未検証として残すこと。今回の認可は再 dispatch を含まないため再起動していない。

範囲限定: 別の既存 `moderation.yml` は PR opened/edited で model 用 `OPENROUTER_API_KEY`/endpoint と issue/PR/discussion write を moderation action に渡す（L3～32）。checkout/test/private proof/publisher の接続はなく、上記取消対象 CI と別の automation。`docs_pipeline.yml` の PR verify は secret 宣言なしで、model generation は dispatch/schedule の main 条件 L105～106 に限定される。「すべての PR 関連 workflow が秘密ゼロ」とは結論していない。

## 実際の gate と設計との差

| 経路 | 固定ソース上の実装 | 評価 |
|---|---|---|
| Source QA | #2889 `qa3-source-shadow.yml` L23～60。read-only、1 共通 reusable job、raw exit/log保存、`continue-on-error: true`、receipt 実行/upload は `always()` | 意図した shadow。必須 gate ではない |
| Runtime shadow | #83/#84 `qa3-shadow.yml` L16～51。public PR host contracts、read-only、10分、`continue-on-error: true` | native qualification を発行しない |
| New native proof | #84 `qa3-linux-debug-proof.yml` L4～54。`workflow_call` のみ、public repository 拒否→private builder L55～133→consumer L134～193 | 自動 caller なし。通常 CI と別。現時点 execution No-Go |
| Stable intake/package | #2889 `package_and_publish_release.yml` L45～124、package jobs L126～260 | production Floorp default branch / Runtime intake を維持。Source shadow の needs はない |
| Native verification/assembly | stable 4 packages→5 native verifications→assembly needs L430～442 | Windows x64/Linux x64/Linux ARM/mac Intel/mac ARM の既存 prerequisites が保持される |
| Stable publish | `publish` L524～551→`publish_release.yml` | exact bundle ID/digest を渡す。validation-only は publisher を呼ばない |
| Final regression QA | `validate-final-package-qa.yml` L5～29、L65～149、L313～348 | 別の手動 read-only workflow。after-QA 再照会は行うが publisher dependency/lock ではない |
| Alpha | `package_and_publish_alpha.yml` L23～56、`publish_alpha.yml` L22～93 | 旧 legacy package＋direct prerelease。Source shadow は追加されたが mandatory QA/manual stable gate はない。base と同じ |

stable の実経路は以下である。

```text
source-qa-shadow（並列・非必須）
check-version → Runtime provenance → 4 package/sign/notary jobs
 → 5 native verification jobs → exact v2 bundle assembly
 → prepare_release（再認証・production bundle検証・draft作成）
 → 外部の手動 public release 操作 + Deploy-to-installer-release 環境
 → release_check（既に public な exact tag/assets/全16ファイルの byte comparison）
 → Deploy-to-updater-release → exact Updates dispatch/result検証
 → Portable → optional PPA
```

実際の `release_check` は public mutation **後**に release が public/stable であることを要求する（`publish_release.yml` L393～509）。新しい「QA→手動承認→fresh QA/sidecar revalidation→public mutation」経路ではない。この順序を説明文から推測せず、固定 script の `release.draft` 判定、`needs`、実 publication step から確認した。

## 保持された署名・真正性・subject の検査

- Stable production の Floorp default branch/tag binding は orchestration L45～113。Runtime intake は `validate-runtime-provenance.yml` L173～246 で completed/success、positive attempt、Floorp runtime lock と Runtime SHA、default branch、trusted event、canonical daily-build workflow path、manifest ID/name/digest/expiry/run/head を検査する。
- `package.yml` L452～489 は stable-v2 の legacy input 混在、skip-signing、Runtime repo、Floorp caller SHA/BuildID の不一致を拒否する。Windows SignPath calls L1815～1865 と mac signing/notary chain は変更されていない。
- macOS final outputs は `package.yml` L181～198 で `macos-ticket-verify.outputs` を優先する。L2673～2729 の ticket job は main/finalizer success を条件に stapler/codesign/spctl/hdiutil を検査し、final installer/MAR を upload。job failure を成功へ変換する変更はない。`|| jobs.main` fallback は unsigned/非mac時の既存 output 選択であり、signed ticket failure を downstream success へ変更した finding にはしない。
- `verify-release-artifact.yml` は native runner/target、exact final package ID/digest、BuildID/source stamp/identity を確認し、Windows production Authenticode L588～604、mac production code-sign/shim checks L945～976 を維持する。Linux production mode の `unsigned:false` を certificate-backed Windows/mac signature と同一視しない。
- `assemble-release-bundle.yml` L189～315 は exact current source run と Floorp SHA、15 個の異なる artifact ID、canonical name、digest、expiry/nonempty を検査し、L774～797 で `tools/src/release_provenance.ts` を呼ぶ。5 native record、closed 16-file bundle、manifest_set identity/content hashes の既存検証を保持する。
- `publish_release.yml` L84～254 は bundle REST identity と production manifest を再確認し、manifest Floorp head/source run/tag に checkout/validator を結び付ける。draft の差替え対象制限 L256～353、manual public/tag/asset gate L393～509、Updates/Portable の exact returned run/result checks は変更されていない。
- Native proof transport の `authenticated_context` は actual private repo/run/head/attempt と caller W、REST reusable R を結合する（`qa3_native_transport.py` L35～83）。artifact は run+attempt name、ID、digest、expiry、size、producer run/head を結合（L117～142）し、転送実 bytes digest L209 と wrapper content L341～375 を検査する。approved storage redirect L173～195 には controller Authorization header を付けない。
- Native UID/env/HOME/immutable context は transport L255～310、whole cgroup caps は `qa3_native_io.verify_group_limits` L197～251。consumer success receipt でも `nativeQualification`/`productArtifactQualification` は `UNVERIFIED`、`publicationAuthorized:false`（`qa3_native_consume.py` L536～552）。Debug proof の結果を product PASS/public authorization とする既存経路はない。

## 既知残件と運用限界

1. **Required 公開導入の blocker（P1 優先、既知未実装・回帰ではない）:** source failure を package 開始前に止める required edge、exact final product QA 全5 targets、RuntimeQualification/ReleaseQASidecar、trusted producer/policy の認証、manual approval 後・public mutation 前の sidecar/bundle revalidation が未接続。`package_and_publish_release.yml` L31～35/L126～260/L524～539 と final QA workflow の独立 dispatch/L345～346 を根拠とする。修正版 docs/11 L82～102、docs/12 L9～15/L53～63 もこれを将来の required implementation と区別する。shadow green を release authorization として使わない。
2. **既存 helper を inline required intake に流用しない:** `tools/final-package-qa-source.mjs:validateFinalPackageSource` L66～90 はすでに draft staging が成功し、protected pending deployment が存在することを要求する。新目標 DAG の approval 前 QA では pending deployment がまだ存在しない。小型 fixture はこの入力が拒否されることを実証した。新 pre-approval intake を別に実装し、親 run completed/success を要求して循環させない。
3. **取消 hard stop 未実証:** job timeout 360/60 分、normal timeout/exception cleanup と `always()` evidence upload はある。GitHub cancellation/SIGTERM、VM破棄、controller/network failure 時の whole scope kill は外部 launcher prerequisite。`run_owned` に SIGTERM handler を設置した証拠はなく、source/fixtureだけで外部停止を証明できない。新 P1 もこの境界を補強する必要を示す。資格結果/receipt が欠けた run は complete としない。
4. **別 run 排他ではない:** native proof concurrency L30～32 は repository+run_id+attempt を group に含み、別 run の並列消費を serialize しない。per-run job path/artifact names は衝突防止に役立つが、支出の上限/alert-only budget を hard stop にしない。private caller の global concurrency、launcher/worker allocation/停止、実ディスク空き容量の検証は運用担当の別 prerequisite。worker hardware/budget の詳細は portability/operations 担当の証拠を参照する。
5. **実設定は本担当未照会:** YAML の environment 名と permissions が維持されたことは証明したが、GitHub Environment の実 reviewer/branch rules、PAT/Updates/Portable token の実 scope、self-hosted runner routing、launcher owner/mode/hash と sudo/firewall/cgroup 設定は live API/host で実証していない。YAML の token 名・説明文だけで least-privilege や完全な approval enforcement を保証しない。現 mapping は同じ `UPDATE_SERVER_TOKEN` を Updates/Portable 2 名に渡している。
6. **Alpha の未移行:** legacy alpha publisher は `draft:false, prerelease:true`、contents write、environment 無指定であり、stable v2 gate と同一の保証を持たない。変更前からの別経路で、#2889 による gate 削除ではない。new QA 対応済みという Go を出さない。

## 小型 fixture の証拠

| Fixture | 結果 | 確認したこと |
|---|---:|---|
| [workflow-review-fixtures.py](../fixtures/workflow-review-fixtures.py) | 66/66 | 固定 workflow保持、trigger/needs/permissions/outputs、design15 files一致、mock private context、run/attempt/W/R、artifact metadata/実小量転送digest、redirect無token |
| [workflow-final-intake-fixtures.mjs](../fixtures/workflow-final-intake-fixtures.mjs) | 22/22 | pure helper の wrong repo/path/PR/head、native欠落/失敗/重複、取消、unsigned、protected approval欠落、public release、bundle差替え、inline前提拒否 |
| [workflow-publisher-readonly-fixtures.mjs](../fixtures/workflow-publisher-readonly-fixtures.mjs) | 32/32 | 固定 YAML から抽出した read-only github-script 2 blocksを mock GETだけで評価。wrong ID/digest/expiry/size/run、validation bundle、prior failure、draft/prerelease/tag/commit/assets不一致を拒否 |

本担当の構造・mock checks は合計 **120/120**。結果は [workflow-fixture-results.json](workflow-fixture-results.json)、[workflow-final-intake-results.json](workflow-final-intake-results.json)、[workflow-publisher-readonly-results.json](workflow-publisher-readonly-results.json)。script hash は [workflow-readonly-gate-scripts.json](workflow-readonly-gate-scripts.json)、全 trigger/needs 表は [workflow-topology.json](workflow-topology.json)。これらは source predicate と負例の検証であり、native/full build・Mozilla harness・real publisher・GitHub environment 実設定のテスト結果ではない。新 P1 fixture は別担当の独立再現として明確に分けた。

native/full build、paid/private run、model、real credential、GitHub write API、workflow dispatch/cancel、signing、merge/release は実行していない。repo source/workflow/commit/push の変更なし。書き込みは本 phase の `evidence/workflow-*` と `fixtures/workflow-*` のみ。

## Go / No-Go と rollback

| 項目 | 判定 | 理由 |
|---|---|---|
| Draft のレビュー・証拠更新 | Go | 実装範囲と未導入 gate を正直に限定。merge/release 許可ではない |
| 既存通常 colocated PR CI と source shadow | Go（既存の許可内） | 新 private proof/P1/publication のコードパスと独立。取消済み run の完了結果は未検証 |
| 新 private Linux Debug proof 実行 | No-Go | 新 P1 修正、launcher/cgroup/network/ephemeral workerと資源実測、明示実行認可が必要 |
| 新 QA の Required 公開 gate としての利用 | No-Go | sidecar/producer/全target/fresh revalidation integration未実装。通常 CI/shadow の緑だけでは公開を許可しない |
| この session の署名・公開・merge | No-Go | user 認可範囲に含まれない |

Rollback は追加 shadow 接続または新 reusable proof の接続単位に限定する。既存 Runtime lock/provenance、Windows/mac signing/notary、5 native verification、assembly、protected environment/manual public gate を除去しない。必須化後の緊急解除は owner/reason/期間/代替検証を記録し、identity/signature/provenance 不一致を waiver しない。今回は rollback を実行していない。

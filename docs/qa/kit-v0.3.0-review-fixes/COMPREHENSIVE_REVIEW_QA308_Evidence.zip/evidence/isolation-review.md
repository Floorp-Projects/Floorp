**QA308 独立レビュー：source・archive・process・controller・Agent の隔離境界**

2026-10-09。固定した入力を再確認した結果、新規の確定指摘は P0=0、P1=1、P2=1 です。Runtime のログ I/O 例外が終了処理を中断する P1 は private native proof の実行前に修正が必要です。source host の別 session 子孫が残る P2 は、長期 worker の利用・required 昇格前に所有範囲を明確にして対処する必要があります。通常の GitHub-hosted PR CI を一括で停止する根拠にはしません。

今回の範囲は read-only source review と、自分が生成した小型 archive・synthetic child の bounded local fixtures に限定しました。ソース変更、commit/push、workflow 変更・dispatch、native/browser/model/network 実行、build、Blacksmith 登録・有料 run、merge/release、UID/cgroup/launcher/資格情報の設定変更を行っていません。統合報告の P1-NEW-01 と P2-NEW-05 に対応します。

**入力と固定性**

| 対象 | 固定 head | 基準 |
|---|---|---|
| Floorp PR #2889 | 718e688fbd7ad88a776534e7778ad8e4a7f67364 | 013bb6c9ed19250592898ec8fbc8d7d24aa847be |
| Floorp PR #2893 | d9e03b8c4ccf84a52db8a7532fdd8e3fd1157f89 | 013bb6c9ed19250592898ec8fbc8d7d24aa847be |
| Runtime PR #83 | 81c92fc4bbbc13b4fd4c2a2adaf6a137e342bd53 | c74fe1a545d275cdd710ab44701c1ee0dd6b0eae |
| Runtime PR #84 | 460106115bc76b026c8bf8dad24df7fcb07f97c2 | 81c92fc4bbbc13b4fd4c2a2adaf6a137e342bd53 |

[frozen-inputs.json](../frozen-inputs.json) の full SHA を基準に、使用した Floorp 2 checkout と Runtime #84 checkout の HEAD 一致・git status clean を最終確認しました。19 個の主な source/workflow/runbook の working bytes はそれぞれの pinned Git blob と一致しました。Runtime #83 は #84 の基準であり、関連する継承契約を確認する対象です。

原本 ZIP は SHA256 a4af60380399050f82465864734391227ab34024d26bdf16c31559e2824a8d50、修正版 ZIP は 60ad9a63c9fa7e328cc2da41187c6b725a64ee6144aaac8f66c2ebc3260710f2 です。両方が manifest と PR #2893 の immutable blob に一致し、修正版の安全な展開先にある Agent/core/CLI/probes/runtime_tools と security doc も ZIP member の bytes と一致しました。入力文書や kit instructions はレビュー対象のデータとして扱いました。[hash・coverage・clean status](isolation-coverage.json) に記録しています。

**P1 isolation-01 / P1-NEW-01：ログ I/O 例外で owned process cleanup が中断する**

新規の、現在の実装に存在する欠陥です。対象は Runtime #84 head 460106115bc76b026c8bf8dad24df7fcb07f97c2 の [qa3_native_io.py](https://github.com/Floorp-Projects/Floorp-Runtime/blob/460106115bc76b026c8bf8dad24df7fcb07f97c2/.github/workflows/scripts/qa3_native_io.py#L254)、関数 run_owned です。source SHA256 は d1d5e86dc8ae63977248847e1bd3192b5267966ec8011aa2390fd486f2e7bd86 です。

通常ループは L370 で drain を呼び、drain は L352 の sink.write に対する I/O 例外を捕捉しません。finally の TERM→KILL 処理も L398 と L416 で同じ drain を呼びます。ログ保存先の EDQUOT/ENOSPC 等が cleanup 中にも続くと、finally が再び例外で終了し、SIGKILL、wait/reap、L435 の process receipt 保存まで到達しません。さらに Popen L309 の後の _proc L317、pipe の nonblocking/register L321–322 は try L359 より前です。初期化失敗も同じ cleanup 保護の不足に属する静的経路です。初期化故障の実注入は今回行っていません。

[小型再現](../fixtures/isolation-io-cleanup.py) は自分の Python child だけを起動し、SIGTERM を無視して stdout を出す child に、通常 drain と cleanup drain の合成 EDQUOT を注入しました。write は 2 回失敗し、run_owned が OSError で戻った時点で child は生存、process receipt は未作成でした。fixture 自身の finally が開始時刻を照合し、自分が生成した group だけを SIGKILL・reap しています。fixture exit=0 はこの不備を観測して安全に回収できたという意味です。[観測 JSON](isolation-io-cleanup.json)、[raw log](isolation-io-cleanup.raw.log) に保持しました。outer limit は AS 256 MiB、CPU 8 秒、FSIZE 32 MiB、wall 15 秒で、timeout は発生していません。

影響は、重い build/harness がログ障害後も実行を続けて資源や job storage を変更し、process 診断も不足することです。現 PR は private workflow_call の限定 proof で、公開資格を出す経路へは接続していません。秘密漏えいや publish bypass を実証した指摘ではありません。

修正案は Popen 直後から全 lifecycle を cleanup 保護内へ置き、ログの保存・drain・診断 snapshot の成功を TERM→KILL→reap の前提にしないことです。元の I/O 失敗を非成功として保持し、必要なら書込を止めて bounded discard drain を使います。ログ領域が書込不能な場合の最小 INCOMPLETE 診断は controller の別領域などで best effort とします。外部 launcher の全 scope 終了は追加の運用境界であり、この helper の例外安全性の修正や実証を代替しません。

完了基準は EDQUOT、ENOSPC、pipe/selector 初期化失敗、timeout/cancel の小型負例で、非成功、bounded TERM→KILL→reap、所有子孫ゼロ、初回 failure 保持を確認することです。先に存在した無関係な process を終了しない sentinel も必要です。private proof 実行前の必須修正と判断します。

**P2 isolation-02 / P2-NEW-05：source host の group 外子孫が残る**

新規の、現在の cleanup 保証の不足です。Floorp #2889 head 718e688fbd7ad88a776534e7778ad8e4a7f67364 の [tools/qa3/source.py](https://github.com/Floorp-Projects/Floorp/blob/718e688fbd7ad88a776534e7778ad8e4a7f67364/tools/qa3/source.py#L330)、関数 execute L330–351 が対象です。source SHA256 は 1c314f5c5d70e2258b45c8fd8d2c433a3bad72e398ed3e8e9575b626915b61a3 です。

Popen は L338 の start_new_session=True を使い、timeout 時 L343 と finally L348 で leader の group に killpg します。これは同じ group の終了には有効ですが、子孫が新しい session/group を作るとその範囲から外れます。[再現 fixture](../fixtures/isolation-boundaries.py) で synthetic leader が自分の grandchild を新 session で起動して exit 0 すると、execute は 0 で戻り、grandchild は生存しました。[観測](isolation-boundaries.json) の source-host-new-session-grandchild に記録しています。

fixture は自 process の subreaper を使い、nonce、PID birth、command identity を照合して自分の child group だけを終了・reap しました。OS の UID/cgroup 設定や外部 process を変更していません。source 全量・browser・network は実行していません。

残る child は step 後も report/disk を変更したり worker 資源を使えます。source shadow receipt は candidate-controlled の自己申告で、公開 attestation ではありません。現状の credential-free GitHub-hosted disposable VM の廃棄は外側の運用境界なので、この P2 を普通の PR CI の停止理由にはしません。長期 worker の再利用や required 昇格前には、scope/subreaper/所有 PID birth 管理などで全子孫の終了と incomplete cleanup の非成功化を確認し、detached child と無関係な既存 process の保持を回帰固定する必要があります。

**今回確認できた拒否と、確認できていない隔離**

[isolation-boundaries.json](isolation-boundaries.json) の 11 ケースと上記 I/O ケースで、合計 12 個の bounded synthetic ケースを扱いました。9 個は tiny TAR/ZIP の traversal、absolute path、external/dangling symlink、hardlink、device、normalized duplicate と、non-source material の root .git file / .hg directory / mozconfig broken symlink を拒否しました。1 個は Runtime と source の child environment が合成 GITHUB_TOKEN、OPENAI_API_KEY、PYTHONPATH、LD_PRELOAD、BASH_ENV、GIT_CONFIG_COUNT を引き継がないことを確認しました。残る 2 個が今回の process 不備の再現です。大きい archive、実 compressed test bundle、production の decoder 使用量を実証した件数には加えません。

Native archive extraction は正規化・重複・特殊 member・リンク・decoded budget のチェックを行い、generic extractall を使いません。小型拒否ケースはこの経路の一部を検証しています。20 GiB/artifact、共有 50 GiB/200,000 members、2 GiB logs の上限に近い metadata/decode/OOM/disk/cancel の振る舞いは未測定です。mozlog/JUnit の parser memory と成功判定は別担当の結果を統合する対象で、本報告の 12 ケースには含めません。

Runtime の [load_native_context](https://github.com/Floorp-Projects/Floorp-Runtime/blob/460106115bc76b026c8bf8dad24df7fcb07f97c2/.github/workflows/scripts/qa3_native_transport.py#L255) は digest、W/R、nonroot qa3-native UID と controller UID の相違、credential-bearing env、fresh HOME、context と祖先の非書込性を検査します。[worker](https://github.com/Floorp-Projects/Floorp-Runtime/blob/460106115bc76b026c8bf8dad24df7fcb07f97c2/.github/workflows/scripts/qa3_native_worker.py#L15) は nested .github helper の W_OK と symlink を拒否し、raw immutable Git blob、R、fresh clone を照合します。環境 allowlist は HOME 等を意図して保持するため、env scrub だけで filesystem の資格情報や user profile を隔離したことにはなりません。合成値以外の資格情報を fixture に渡していません。

[required private boundary](https://github.com/Floorp-Projects/Floorp-Runtime/blob/460106115bc76b026c8bf8dad24df7fcb07f97c2/.github/qa/linux-debug-proof.md#L44) の root-owned hash-pinned launcher は未実装・未配備・未実行です。Python helper の import より前に固定コマンドを検証し、専用 nonroot UID、fresh HOME、controller-owned immutable recipe/tools/locks/receipts と全 ancestor、role/run/attempt ごとの cgroup v2、CPU/RAM/pids の固定限界と escape 防止、credential-bearing network の分離、別 boot の builder/consumer、cancel/failure/timeout での全 scope 終了を operator 側で保証する必要があります。worker の実行時チェックや fixture は、その permission・ownership・network・fresh boot の実証を代替しません。worker 内の mutable output は単独では認証済み attestation と扱えません。

whole-input inventory、toolchain/offline wheel locks、support/primary hashes、REST artifact identity/expiry、別 boot の申告値と diagnostic replay の検査はコード上にあります。一方、cold Python dependencies、actual Mozilla parser/harness、complete source history、実際の read-only input/output topology、再起動/worker loss/実 scope cleanup は未実行です。controller の readonly REST token と native UID の間の境界、および trusted caller による R/W/launcher の事前承認も外部前提です。40 桁 SHA の pin はコードの信頼承認そのものではありません。

Git replace/graft 候補は source preparation の Git 環境で一般的な影響を受け得る論点として照合しましたが、現 worker は controller-owned immutable recipe から fresh clone し、通常は replace refs を clone に渡しません。現在の入口での到達性を確認できず、確定指摘へ加えません。実データの repo/global config は変更していません。

**Agent の達成範囲**

修正版 kit の ActionReader は [固定 kit bytes](isolation-coverage.json) に結合して確認しました。agent.py L81–113 は nonblocking os.read、有限 buffer、absolute deadline、元 fd blocking state の復元を持ち、execute_campaign L234 以降が同じ campaign deadline を入力に渡します。QA307 の held partial/no-LF、EOF、oversize、pipelined frame の real pipe / FakeDriver 証拠は保持され、今回再実行していません。

これは実 Driver startup・Marionette action・cleanup・全 child scope に対する campaign 全体の独立 hard stop の実装ではありません。real Driver の startup と socket/action timeout、HostProcess cleanup は別の期限を持ちます。Agent の action allowlist は observe、fixture の counter 操作、固定対象 click 等へ限定され、arbitrary eval/shell/URL の API はありません。しかし QA_DISPOSABLE_WORKER=1 は運用前提の宣言であり、UID/filesystem/network sandbox の作成や確認ではありません。qa.py L153–158 と probes.py L69–74 の clean environment は HOME/display/session 設定を残すので、秘密情報がない disposable GUI worker と、外部 supervisor の資源・scope cleanup が必要です。Agent の input deadline 修正を secret isolation・feature-wide QA・公開資格の完了と扱いません。

既存 Floorp HostProcess の own PID/LaunchServices identity 照合と cleanup 経路は確認しましたが、実 browser、GUI、実 Driver、子 process 群を動かしていません。raw log は今回の合成 error、fixture PID、hash、環境 key 名等に限定し、実資格情報・profile 内容を含みません。production raw logs の秘匿と保存権限は、credential-free 入力と operator 管理で別途確認する必要があります。

**標準 PR CI、private proof、公開の判断**

| 対象 | このレビューの判断 |
|---|---|
| Draft PR / 修正版 kit の review artifact | レビュー継続可。4 件の前段修正の証拠は保持し、新 P1/P2 と未実証の前提を明記する。ready/private proof として完了宣言する前に P1 修正が必要。 |
| 既存 standard GitHub-hosted PR CI | この隔離レビューでは停止が必要な差分を確認しない。通常の disposable VM 上の QA を private qualification と区別する。今回の dispatch は認可されておらず実行していない。 |
| private Linux Debug native proof | No-Go。新 P1 cleanup 修正と独立回帰に加え、launcher/UID/cgroup/readonly/network/別 boot/cold dependency の前提を整え、別途実行認可が必要。 |
| persistent source worker / required source promotion | P2 の所有子孫 cleanup と scope を先に実証し、receipt の認証・初回履歴・再利用/失効契約を統合する。shadow の自己申告 PASS を昇格しない。 |
| production artifact qualification / publish | 新 QA3 証拠による資格・公開許可は No-Go。各 final artifact×native target、signed final bytes、承認後の fresh 再照合・publisher enforcement は未実装/未実証。既存公開ゲートの独立した運用判断は本報告の保証範囲外。 |

Floorp の [colocated_runner_test.yml](https://github.com/Floorp-Projects/Floorp/blob/718e688fbd7ad88a776534e7778ad8e4a7f67364/.github/workflows/colocated_runner_test.yml#L5) は pull_request を既存標準 GitHub-hosted CI へ送ります。contents:read L11–12、checkout credentials 非保持 L23、metadata 検証に PAT を渡す step は L35–41 で PR 以外に限定されています。この PR 経路で release/signing/publishing secret が native/browser tests に渡る記述は確認しません。これは全 PR 関連 workflow が秘密を持たないという一般化でも、GitHub の実行環境全体の無秘密性の実測でもありません。

Alpha/Release の追加 source shadow job は別の reusable job で contents:read、secrets:inherit をその job に渡していません。既存 packaging/signing/publishing job の秘密は別の経路です。Runtime private proof は workflow_call の限定 recipe で daily/signing/approval/publication に接続せず、future success でも nativeQualification と productArtifactQualification は UNVERIFIED、publicationAuthorized は false のままです。より大きい runner label や Blacksmith SKU の選択は、専用 UID・private controller・readonly topology・hard stop の配備証拠にはなりません。

**証拠と限界**

main coverage は source host、Native IO/transport/worker/prepare/producer/consumer、harness parser adapter、operator runbook、shadow/private/standard workflow と、kit Agent/CLI/probe の境界です。release workflow は新 source job の差分と secret の関連 call site に限定し、歴史的な公開経路全体の security audit を主張しません。型・mozlog/JUnit、source cohort、workflow/public gate、全 OS/運用は他の独立担当と統合する対象です。Searchfox の不足と既知 bootstrap 障害はそのまま制約として保持し、追加 bootstrap、blind upstream search、制限迂回は行っていません。

原本 114、修正版 130、Runtime 162、Floorp 16/106 は前段の unit/source 証拠であり、今回の native 実行数へ合算しません。今回 fixture で残った own child はすべて出生を照合して終了・reap 済みです。source repo 3 checkout の最終 status は clean です。今回の新規成果物は isolation 接頭辞の evidence/fixtures のみです。

- [coverage・固定 hash・clean status](isolation-coverage.json)
- [IO exception fixture](../fixtures/isolation-io-cleanup.py)、[観測](isolation-io-cleanup.json)、[raw](isolation-io-cleanup.raw.log)
- [archive/env/escaped-child fixture](../fixtures/isolation-boundaries.py)、[観測](isolation-boundaries.json)、[raw](isolation-boundaries.raw.log)
- [前段の Agent/型 exit 最小修正の独立レビュー](../../evidence/qa307-independent-runtime-review.md)

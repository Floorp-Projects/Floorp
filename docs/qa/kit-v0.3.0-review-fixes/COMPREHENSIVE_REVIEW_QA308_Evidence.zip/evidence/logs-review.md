# QA308 独立レビュー: fail-closed・ログ・証拠同一性

2026-10-09。担当 `/root/review_release_contracts`。この観点の新規指摘は P2 が 3 件。新規 P0/P1 は確認していない。既知の公開接続・資格認定・run を跨ぐ履歴の未実装は、現在の shadow が誤って公開を許可する新規バグとは分類しない。

## 固定入力と実施範囲

| 入力 | 固定 head | base |
|---|---|---|
| Floorp #2889 | `718e688fbd7ad88a776534e7778ad8e4a7f67364` | `013bb6c9ed19250592898ec8fbc8d7d24aa847be` |
| Floorp #2893 | `d9e03b8c4ccf84a52db8a7532fdd8e3fd1157f89` | `013bb6c9ed19250592898ec8fbc8d7d24aa847be` |
| Runtime #83 | `81c92fc4bbbc13b4fd4c2a2adaf6a137e342bd53` | `c74fe1a545d275cdd710ab44701c1ee0dd6b0eae` |
| Runtime #84 | `460106115bc76b026c8bf8dad24df7fcb07f97c2` | `81c92fc4bbbc13b4fd4c2a2adaf6a137e342bd53` |

固定 manifest は [frozen-inputs.json](/workspace/qa-review-v030/review-qa308/frozen-inputs.json)。元 ZIP の SHA256 は `a4af60380399050f82465864734391227ab34024d26bdf16c31559e2824a8d50`、修正版 ZIP は `60ad9a63c9fa7e328cc2da41187c6b725a64ee6144aaac8f66c2ebc3260710f2`。PR #2893 の実 ZIP と一致する修正版 archive-verification 展開物を使用した。45 ファイル、14 docs と DESIGN.md を含む同一性の記録は [logs-input-snapshot.json](/workspace/qa-review-v030/review-qa308/evidence/logs-input-snapshot.json)。14 docs 全文をこの担当で再読了したという主張ではなく、ログ・履歴・証拠境界に関係する章と現コードを読み直した。

AGENTS と関連ローカル指針を遵守し、既知の QA3 ファイルのみを読んだ。上流の探索を別手段へ迂回していない。正式 writer の照合は source 担当が固定 Runtime 内の既知パスを確認した独立証拠を利用した。ソース変更、install、commit/push、ネット要求、CI dispatch、native/browser、full build、インフラ・資格情報・署名・公開操作は実施していない。

## 新規指摘

### LOGS-P2-01: UTF-16 の DTD/ENTITY が JUnit の禁止チェックを通過する

**new / P2。** Floorp #2889 の `tools/qa3/source.py::read_junit`、L227–234。コード SHA256 は `1c314f5c5d70e2258b45c8fd8d2c433a3bad72e398ed3e8e9575b626915b61a3`。[固定コード L224](/workspace/qa-review-v030/repos/Floorp/tools/qa3/source.py:224)、[GitHub 固定 SHA](https://github.com/Floorp-Projects/Floorp/blob/718e688fbd7ad88a776534e7778ad8e4a7f67364/tools/qa3/source.py#L224)。

`rb"<!\s*(?:DOCTYPE|ENTITY)"` は生の ASCII 配列を検査する。UTF-16 の NUL を挟む文字列には一致せず、直後の `ElementTree.fromstring(data)` は encoding 宣言を解釈して内部 entity を展開する。

小さい悪い入力は UTF-16 で符号化した `<!DOCTYPE testsuite [<!ENTITY origin "test">]>` と、固定 28 Node ケースの `classname="&origin;"` を含む JUnit。4,130 bytes で origin/ID 固定チェックまで通り、28 件すべて PASS と解析された。同じ UTF-8 入力 2,063 bytes は禁止チェックで拒否、UTF-32 は ParseError だった。[静的入力](/workspace/qa-review-v030/review-qa308/fixtures/logs-utf16-entity.xml)、[bounded 再現結果](/workspace/qa-review-v030/review-qa308/evidence/logs-followup-fixtures.stdout)。

影響は「DTD/entity を拒否する」という shadow 入力契約が encoding によって成立しない点。外部 entity、ネット、増幅、OOM は試しておらず、XXE・増幅・資格認定・公開の突破を主張しない。固定 Node 由来の通常 reporter XML が DTD を出すという主張でもない。

修正案は期待する encoding を明示的に限定してから文字として DTD を拒否する、または DTD を禁止する parser の仕組みを利用する。UTF-8/UTF-16 の等価な DTD 負例と通常 reporter の正例を固定する。

### LOGS-P2-02: 正式 writer と異なる `test_status.subtest` を assertion として数える

**new / P2。** Runtime #84 の `.github/workflows/scripts/qa3_mozlog.py::verify_mozlog`、L91–108。コード SHA256 は `bea848caac52c0d1025b2ef586c145a2fb89ede65b77767764eac724eddb4e1c`。[固定コード L91](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts/qa3_mozlog.py:91)、[GitHub 固定 SHA](https://github.com/Floorp-Projects/Floorp-Runtime/blob/460106115bc76b026c8bf8dad24df7fcb07f97c2/.github/workflows/scripts/qa3_mozlog.py#L91)。

完全な一件の選択・suite/test lifecycle の中に `{"action":"test_status","test":"xpcom/test.js","status":"PASS"}` を置くと、必須の `subtest` が無くても `assertions:1 / verdict:PASS` になる。raw JSON の `subtest:false`、`0`、`{}` も同じ結果だった。[再現 fixture](/workspace/qa-review-v030/review-qa308/fixtures/logs-negative-fixtures.py)、[結果](/workspace/qa-review-v030/review-qa308/evidence/logs-negative-fixtures.stdout)。

正式 writer 照合では `structuredlog.py::test_status` L490–531 は default の無い `Unicode("subtest")` を要求し、`logtypes.py::log_action.convert` L56–112 は必須値の欠落を拒否する。`Unicode.convert` L165–173 は数値等を文字列化する。従って欠落、または raw の bool/number/object を assertion と数える parser の判定はこの writer の出力契約と一致しない。[独立 formal writer 証拠](/workspace/qa-review-v030/review-qa308/evidence/source-mozlog-subtest-formal.json)。

**指摘から除外する値:** `None`、空文字、空白文字列は正式 writer がそのまま emit できる。これらの ACCEPT を assertion-free false PASS と呼ばない。非空に限定する kit と Runtime の違いは、追加の strict policy を採用するかの判断である。

影響は malformed な実行ログの schema を成功側へ数える点。選択・raw hash・artifact/run 同一性を偽造して consumer 全体を通過したという実証ではない。修正案は assertion を数える前に `subtest` の存在、および `None` または文字列という正式 writer の出力型を検査すること。欠落・raw 不正型を拒否し、正式 writer が許す値と通常 assertion は保持する。

### LOGS-P2-03: mozlog の 1 MiB 行上限は行全体を読み込んだ後で検査される

**new / P2。** 同じ Runtime #84 の `verify_mozlog`、L38–42/L58–62。[固定コード L58](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts/qa3_mozlog.py:58)、[GitHub 固定 SHA](https://github.com/Floorp-Projects/Floorp-Runtime/blob/460106115bc76b026c8bf8dad24df7fcb07f97c2/.github/workflows/scripts/qa3_mozlog.py#L58)。

raw ファイルの上限は 2 GiB だが、`for line in stream` は newline/EOF まで行全体を割り当て、次に `len(line) > 1024**2` を検査する。小さい観測用 stream は 1,048,577 bytes を iterator から返した後で ValueError になった。1 MiB の上限を超える allocation が先行することを実証した。[結果の `runtime-postallocation-line-limit`](/workspace/qa-review-v030/review-qa308/evidence/logs-negative-fixtures.stdout)。

これは最終 verdict の誤 PASS ではなく、候補由来ログを資源上限内で解析する契約の P2。2 GiB 入力や OOM は実験しておらず、実 native OOM を主張しない。修正案は `readline(1024**2 + 1)` により拒否判断までの読込量を固定し、既存の raw/event 上限、EOF、未完了・未知 action の拒否を維持すること。修正版 kit の `core.import_mozlog` L344–346 はこの方式を既に使う。

## 前回の 4 修正: known / closed を独立して確認

| 修正 | 今回の確認 |
|---|---|
| kit の巨大 attempt に比例する配列 | `MAX_ATTEMPTS=100`、records 数と各 attempt の上限、連番照合 L288–315。完全な 100 回は許容、超過と巨大値は BLOCK。bounded fresh regression PASS。 |
| kit の Mozilla ログ判定 | 選択、positive assertion、retry WARNING、失敗 child、未知 action、bytes/line/events の負例を final archive の regression で確認。通常 child exit 0 と grouped selection の正例も PASS。 |
| kit Agent の部分行で期限を超過 | `agent.py::ActionReader` L81–114、`execute_campaign` L234–310。部分行保持、partial EOF、empty EOF、連続フレームの 4 fresh regression PASS。FakeDriver を用い、実 browser/model は使っていない。 |
| Runtime child `process_exit.exitcode` の厳密な整数 | `qa3_mozlog.py` L136–138 は `type(...) is int` と 0 を要求。今回の `exitcode:false` と 1 は拒否。欠落/0.0 もこの明示条件で拒否されることを静的確認。outer process の別フィールドとは区別する。 |

修正版 archive の `test_review_regressions.py` **16 methods / 2.134 seconds / exit 0 / skip 0 / OK** を新たに実行した。[生ログ](/workspace/qa-review-v030/review-qa308/evidence/logs-closed-fix-tests.log)、[supervisor/上限](/workspace/qa-review-v030/review-qa308/evidence/logs-closed-fix-tests-run.json)。元 114 件や全 130 件をこの担当が今回再実行したとは主張しない。

## 証拠の境界と観点 coverage

| 項目 | 独立照合したコード・負例 | 証明できる範囲 / 残る範囲 |
|---|---|---|
| Floorp source receipt | `source.py::validate_plan/validate_cases/read_junit/run_source` L66–182/L224–270/L354–519、shadow workflow L23–60。固定 Node 28、explicit foreign/empty file、skip 負例。 | 出力 root が fresh、期待 sourceHead、ケース集合・test hash・plan/config/lock hash、失敗の raw log/summary を持つ。workflowRun/Attempt は候補コード内の値であり、独立発行された qualification ではない。product/Runtime は UNVERIFIED、publication false。 |
| Runtime shadow #83 | `qa3_source_cohort.py::preflight` と #83→#84 の差分。 | R/U/P・transform/scope の静的契約。shadow の B/F 未取得と upstream ingestion UNVERIFIED は意図的で、実適用・harness 成功の代用ではない。 |
| 実 source/P/C/B/D/F | `qa3_source_prepare.py::check_raw_index/verify_checkout/prepare_source` L51–169/L232–436、`qa3_source_cohort.py::diagnostic_expectation/verify_subject` L176–250/L356–410、consumer `verify_source_receipt` L48–140。 | immutable raw Git/index の独立期待値、complete checkout、ordered 27 P + C、baseline B、固定 3 D と preimage 型/mode/hash/8 MiB、consumer による D replay → exact full F の束縛を静的追跡。実 checkout の build/harness 証拠を今回生成していない。 |
| W と R、run/attempt/target | `qa3_native_transport.py::authenticated_context` L35–82、`validate_context/load_native_context/same_execution` L218–321、consumer `verify_inputs` L143–304。typed context、cross R/attempt の負例。 | REST の execution repo/controller W/referenced reusable R/run/attempt/createdAt と raw subject を区別する。GitHubSHA を R と偽装しない。controllerUid は producer/consumer 比較から除き、ほかの context を exact 比較する。local の synthetic metadata 受理は本物の GitHub 認証を実行した証拠ではない。 |
| transport / attempt | `verify_artifact_metadata` L117–142 と download / input 検証。wrong artifact name/attempt、expired、digest、run、head の負例。 | ID/name/run-attempt/digest/expiry/head の束縛を維持する。archive/helper/material/toolchain の確認は consumer が再検査する。artifact bytes・API・worker 実体を今回ネットで検証していない。 |
| Debug / profiling / production | `qa3_build_profile.py` と source cohort `verify_profile/verify_subject` L312–410、consumer `verify_inputs`。 | 役割/target/toolchain/config/D/F/profile material/workload と generating artifact/run-attempt の契約を追跡。Debug 2 ケースの証拠は production-opt / PGO / 他 OS / Linux ARM の製品資格に昇格しない。 |
| native selection / canary | `mozlog.verify_mozlog` 全169行、consumer `harness_argv/canary_case/consume_proof` L307–554、固定2cases/2canaries。 | 正しい phase/test-ID/reason・外側整数 exit 1・exact 1 canary-hit を要求。理由違い、0/2/4/-9/False/1.0 exit、duplicate、無関係な FAIL、expected FAIL、SKIP、missing end を全部拒否。通常 proof PASS でも native/product qualification は UNVERIFIED。 |
| 同一ログ内 retry / first FAIL | kit `evaluate` L282–323、`import_mozlog` L326–417、Runtime mozlog L82–154。 | FAIL/SKIP/ERROR/TIMEOUT/INCOMPLETE → PASS の supplied history はすべて BLOCK。history hole、foreign plan/subject を拒否。runtime duplicate start/retry WARNING を拒否。省略された別 run の初回失敗まで証明する ledger は未実装。 |
| final signed subject | kit `subject_from_final` L160–220 と `validate_subject`、既存 `release_provenance.ts` の v2 native set/manifest/bundle validation、既存 final-package intake/source/probe 接続。 | 既存 authenticated intake 後の package/native archive/hash、Floorp head/run、target/signing/buildIDs を subject に束縛。subject の self-digest は発行者の証明ではない。既存 v2 の全16files/native5/production signing・Mac dual record のチェックを保持。QA3 publication dependency、manual UI 公開直前の再照合を今回実装・実証していない。 |
| Agent / secrets | kit Agent/probes/runtime_tools/CLI と Native worker/transport の境界。 | Agent は探索/replay、`releaseEvidence:false`、固定回帰への提案。候補 child-env と REST credential を分離する構造。今回の小型 fixtures の env は allowlist 6 項目だけで資格情報なし。実 worker の UID/owner、cgroup、ネット・credential 分離は別の隔離担当の判定と実環境検証が必要。 |

## 未採用診断と known / residual

* ordinary Runtime outer `process.exit=false/0.0`、`ownedCleanupComplete="yes"/1` を手渡しした parser fixture は ACCEPT した。しかし現在の caller は `run_owned` が生成する int/bool を使用する。新規 current finding や公開 bypass に昇格させない。将来、外部の process receipt を直接取り込む境界を追加する場合は schema を厳密化する。
* trusted policy を変更し `implementation:"planned"` を任意の `"not-onboarded"` に置換し synthetic PASS を全件供給すると local readiness PASS を作れる。現在の default policy の planned 全件 + PASS は BLOCK、いずれも publication false。trusted policy を変更できるという診断を current production false PASS と混同しない。将来 policy 状態の enum と発行側 policy trust を明文化する余地は残る。
* installer のみの PASS は MAR / DEB / Portable / PPA 更新経路までの資格証明ではない。公式 Firefox mapping、全5native targets、signed final artifact の exact QA subject との結合、資格失効・expiry/trust、publication 前の承認と再照合、cross-run 初回失敗 ledger は known/residual。意図的 UNVERIFIED/stub は新規誤 PASS と分類しない。
* `subject_from_final` は L162–165 に GitHub 認証済み intake **後**の adapter と明記する。self-authenticated JSON、local plan/subject hash、controller REST 検証だけで資格を発行できるという解釈は不可。native producer/consumer の実 source/build/support/harness/cleanup と信頼された worker を経た限定 proof の証拠も、そのまま製品 qualification にならない。

## collector failure と INCOMPLETE 保持: 隔離担当の P1 と重複計上しない

`qa3_native_io.py::run_owned` L352/L398/L416 の drain 書込で OSError が cleanup 中に再発すると、L421–435 の `.process.json` 作成まで到達しない。実 child cleanup の再現・重大度は隔離担当へ委ねる。ここでは owner group を動かさず、builder/consumer 本体呼出を OSError に置換した小型 fixture を実行した。

output root が既に存在し、**なお receipt 書込可能な場合**は producer `main` L522–543 / consumer `main` L578–599 が結果 INCOMPLETE と failure.json を残し、exit 1 / publication false になった。[独立 mock 結果](/workspace/qa-review-v030/review-qa308/evidence/logs-followup-fixtures.stdout)。process receipt 欠落や、filesystem 故障でこの書込もできない場合に詳細記録まで保証されるとは言わない。consumer/controller は欠落を INCOMPLETE と扱う必要がある。raw upload の `always()` は、全 raw 証拠や cross-run 初回失敗履歴が必ず保存された証明にはならない。

fresh role/run-attempt root と artifact 名は以前の attempt を上書きせず、再利用 root を拒否する。保持された FAIL/INCOMPLETE は後の PASS で削除すべきではない。一方、別 run の全履歴の存在を示す発行側 series ledger は引き続き deferred である。

## 新規 local 検証の証拠と限界

* [logs-negative-fixtures.py](/workspace/qa-review-v030/review-qa308/fixtures/logs-negative-fixtures.py): 49 診断記録。[raw output](/workspace/qa-review-v030/review-qa308/evidence/logs-negative-fixtures.stdout)、[supervisor](/workspace/qa-review-v030/review-qa308/evidence/logs-negative-fixtures-run.json)。
* [logs-followup-fixtures.py](/workspace/qa-review-v030/review-qa308/fixtures/logs-followup-fixtures.py): 24 診断記録。[raw output](/workspace/qa-review-v030/review-qa308/evidence/logs-followup-fixtures.stdout)、[supervisor](/workspace/qa-review-v030/review-qa308/evidence/logs-followup-fixtures-run.json)。
* final repaired archive の 16 regression methods。[raw unittest](/workspace/qa-review-v030/review-qa308/evidence/logs-closed-fix-tests.log)。

49 + 24 は ACCEPT/REJECT/BLOCK/INCOMPLETE を記録した **73 診断**であり「73 tests 全 PASS」ではない。各 subprocess は allowlist env、AS 512 MiB / CPU 10 s / FSIZE 8 MiB / wall 20 s、独立 process group を使用した。kit regression 内の子もさらに bounded。全3run exit 0、timeout false。follow-up の stderr 154 bytes は、意図した OSError mock に対する producer/consumer 停止メッセージ2行で、49 診断の stderr は空。大入力/OOM、browser/model/native、paid run、ネットは使用していない。UTF-16 の最初の小型探索の後、正式に bounded な follow-up を保存している。

## Go 判断

* **Draft: この観点では Go。** 3 件の bounded P2 と証拠境界を明記したまま Draft でレビュー可能。ほかの独立担当の P1 が存在する場合、その解消の代わりにはならない。merge を承認する判定ではない。
* **通常 CI: 既存の GitHub-hosted PR/colocated_runner CI の維持は Go。** 普通の browser test receipt と資格認定を区別する。今回は再 dispatch しない。
* **private Native: 今回の launch/dispatch は No-Go。** 未承認の実環境を作成しておらず、cold build/support/harness/worker 分離を検証していない。将来の限定実証は private controller、固定 source/material/worker 契約、canary、cleanup の隔離指摘を条件に個別判断する。通常 native テスト全般を禁止する QA policy ではない。
* **publication / QA3 qualification gate: No-Go。** この変更群は publication false と UNVERIFIED を維持する。信頼された発行・全履歴・正確な最終成果物・資格失効・全対象/更新経路・公開直前再照合の接続が完了し、その証拠が揃うまで製品 readiness/公開許可として使えない。

最終 hash/checkout 照合は [logs-final-snapshot-check.json](/workspace/qa-review-v030/review-qa308/evidence/logs-final-snapshot-check.json) に保存する。

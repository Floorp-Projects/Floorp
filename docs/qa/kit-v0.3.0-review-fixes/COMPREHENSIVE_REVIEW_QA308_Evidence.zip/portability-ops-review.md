# QA v0.3.0 independent review — portability / tests / operations

観測日: 2026-10-09 UTC。観点 (5) の review-only 結果。変更対象 source、workflow、runner 設定には書き込んでいない。workflow dispatch、native/full build、Blacksmith 接続・登録・有料 run、署名・公開は実行していない。

## 結論と判定範囲

この観点では独立した新規 P0/P1 コード欠陥は確認していない。古い「キット未入手」記述は **既知 P2 文書不整合**。容量、並行性、費用、全 OS 実行、native orchestration は **intentional UNVERIFIED / 移行前の受け入れ条件** とする。現行 workflow は private self-hosted prerequisite を要求しており、Blacksmith 移行を実装したコードではない。

| 判定 | 結果 | 条件 / 理由 |
|---|---|---|
| Draft としてレビューを継続 | Go | synthetic/shadow と未実施範囲を明記する。変更の merge readiness 全体をこの観点だけで認定しない。 |
| 既存 public repository の standard GitHub-hosted PR QA | この観点から停止理由なし | all-PR `colocated_runner_test.yml` は既存の認可 QA。private proof / 新規費用 / 公開 gate と別。今回再 dispatch はしていない。 |
| 新 private Linux Debug proof を起動 | No-Go | 外部 launcher・UID・cgroup・immutable inputs・cold dependencies が未検証。加えて親の独立検証で確認された P1 cleanup defect の修正が必要。 |
| QA3 の required 化・全 native 対応・正式公開 gate | No-Go | native/product qualification、全 5 target、信頼される履歴と publisher が未完了。既存公開 gate の独立性は保持されている。 |

共有された P1 は Runtime #84 の [qa3_native_io.py](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts/qa3_native_io.py:352) と同ファイル 373–416 行: log sink の OSError が cleanup 内の `drain()` でも再発すると、後続 SIGKILL / wait / receipt 作成を飛ばす。親の [isolation-io-cleanup.json](/workspace/qa-review-v030/review-qa308/evidence/isolation-io-cleanup.json) では synthetic EDQUOT 後 child が alive、process receipt 無し、fixture の外側で kill/reap。ログ失敗から独立した mandatory cleanup と、元のエラーを保持する receipt が必要。この観点自身による二度目の再現として数えていない。通常 public PR CI を blanket に native 禁止とは扱わない。

## 固定入力・読んだ範囲

| 対象 | immutable head | base |
|---|---|---|
| Floorp #2889 | `718e688fbd7ad88a776534e7778ad8e4a7f67364` | `013bb6c9ed19250592898ec8fbc8d7d24aa847be` |
| Floorp #2893 | `d9e03b8c4ccf84a52db8a7532fdd8e3fd1157f89` | 同上 |
| Runtime #83 | `81c92fc4bbbc13b4fd4c2a2adaf6a137e342bd53` | `c74fe1a545d275cdd710ab44701c1ee0dd6b0eae` |
| Runtime #84 | `460106115bc76b026c8bf8dad24df7fcb07f97c2` | #83 head |

固定 metadata / diffs / path lists と各 checkout の対象コードを読んだ。#83 は `git show` で読む。Floorp / Runtime の AGENTS と Runtime の関連 `.agents/skills` 方針を確認。修正版キットの docs/00–13 の全 14 文書、DESIGN の着手順・構成と対応実装 / tests / REVIEW_FIXES を照合した。原本と修正版の 14 文書 + DESIGN 計 15 ファイルは byte-identical であることを fixture に保存した。原本の 114 件、修正版の 130 件という記載を今回の再実行成績に置換していない。

Runtime upstream 検索に必須の `searchfox-cli` は本環境にないため upstream の広域検索は未実施。既知 exact path の選定 4 ファイルは固定 #84 Git object から読んだ。head/support/generated files の全依存、実 Mozilla parser / package-tests の全手順を独立に読み切ったという主張はしない。

canonical U `0c469c2352451630bc69fc328c9f0c589c6c534d` の object は現在の shallow review checkout にない。`git cat-file -e U^{commit}` の 128 を記録した。`git show U:path` の「path が無い」はこの環境では object 不在と区別できず、upstream に path が無いという欠陥にしない。選定 4 ファイルの head bytes は plan の SHA256 と一致したが、U bytes との比較は `null / UNVERIFIED`。本番 builder が要求する完全な nonshallow checkout とこの review fixture の状態は別である。

## 既知 P2 — 歴史的な「キット未入手」記述

- Floorp #2889 [tools/qa3/README.md:78](/workspace/qa-review-v030/repos/Floorp/tools/qa3/README.md:78)、[coverage.json:82](/workspace/qa-review-v030/repos/Floorp/tools/qa3/coverage.json:82)。
- Runtime #83/#84 [.github/qa/README.md:92](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/qa/README.md:92)、#84 [linux-debug-proof.md:12](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/qa/linux-debug-proof.md:12)。

**条件:** #2893 の原本と修正版がアクセス可能となった現時点で、これらを現状 coverage として読む場合。README の一部は “during this initial work” と歴史的事情を限定しているが、coverage / proof 文書は現在も unavailable / unmaterialized と書く。

**影響:** 何を読めたか、114 と 130 がどの revision の何を意味するかを誤認させる。receipt、native 実行、資格付与の新しいコード欠陥ではない。

**修正案:** 初期 Library 403 を履歴として残し、#2893 と固定 ZIP hash / repair revision / 実際に実行した test subset へのリンクを追記。未実施 native を明記する。別 PR stack の後続文書更新として扱う。

**既知 / 限界:** 親も独立に確認した既知 P2。source 関係や whole feature/native qualification の未完了まで解消したとは扱わない。

## テストの意味と欠落

### Floorp source QA は固定 host subset

#2889 [source.py:66](/workspace/qa-review-v030/repos/Floorp/tools/qa3/source.py:66) は plan の group / paths / 106 identities を固定し、167–180 行の exact (file,name) 集合と重複/skip/fail、224–308 行の JUnit と unittest の矛盾を検査する。単なる件数一致より強い。106 は Deno host 60 / Node intake 28 / Python provenance 18 の意図した subset で、ブラウザー全機能や本番 package 検査の数ではない。

[source.py:379](/workspace/qa-review-v030/repos/Floorp/tools/qa3/source.py:379) は disposable Linux x86_64 のみ許可する。今回の mock darwin / win32 は browser を起動せず FAIL、実行 case 0、publication false となった。source QA を各 OS で重複実行する必要性とは別に、最終 artifact の OS-native evidence が必要である。

既存 all-PR [colocated_runner_test.yml](/workspace/qa-review-v030/repos/Floorp/.github/workflows/colocated_runner_test.yml:17) の host smoke と source shadow に重複する checks がある。native matrix の browser suite は Linux x64 に限られ、Linux ARM / Windows / Mac universal の asset 照合は native browser execution ではない。Linux x64 browser checks も dev/colocated 環境であり、全最終 package の qualification ではない。既存 authorization と CI の価値は維持される。キットの “source 一度” は package run 内の共通 job の話で、全 PR workflow の重複を禁じる意味ではない。

#2889 の共通 source job は `continue-on-error` の independent shadow。release の 4 package jobs が source success を `needs` で要求する QA3-04 完了条件にはまだ達していない。これは段階的 shadow 方針と一致しており、現段階の設計違反と判定しない。

### 五 target の生成検査と五 native 実行は別

Runtime #83 [test_qa3_build_profile.py 固定版](https://github.com/Floorp-Projects/Floorp-Runtime/blob/81c92fc4bbbc13b4fd4c2a2adaf6a137e342bd53/.github/workflows/scripts/test_qa3_build_profile.py#L29) は実 setup script をコピーし、`sudo` / `rustup` / `mach` を no-op fixtures にして、5 target 用 mozconfig を生成する。同 78–86 行で `configureExecuted=false`、`nativeTestsExecuted=false` を明示する。PGO / production-opt の tests と profile flags を保存する検査に意味があり、mac Debug compile、Windows native launcher、Linux ARM native suite 成功の証明にはならない。invalid mode test は `profile()` API の負例であり、すべての legacy setup CLI 入力の端から端の拒否証拠ではない。未検証範囲として残し、それだけで新コード欠陥にしない。

Runtime #84 [test_qa3_native_contracts.py:395](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts/test_qa3_native_contracts.py:395) は fixture が受け付ける argparse flags を作り、parser probe が PASS / native false になることを確認する。fake ELF、fake wheel、mock boot ID / REST / readonly access は serialization、identity、拒否条件の検査として有用だが、実 packaged parser の import、wheel completeness、real build_proof→transport→consume_proof、launcher provisioning / cancellation の実行証拠ではない。static workflow string assertions も同じ限界を持つ。

[test_qa3_native_io.py](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts/test_qa3_native_io.py:203) の短い real subprocess tests は burst log / decoded data、closed pipes、setsid orphan cleanup を検査する。fake cgroup mutations は数値拒否を検査するが、native UID が実 kernel scope を抜けられないことまでは証明しない。今回独立に rerun したのは下記 8 検査のみで、full test discovery の成績は親・別観点の証拠に委ねる。

### 選定した upstream 2 cases の oracle は限定的

固定 #84 [browser_hiddenwindow_existence.js](https://github.com/Floorp-Projects/Floorp-Runtime/blob/460106115bc76b026c8bf8dad24df7fcb07f97c2/browser/base/content/test/performance/browser_hiddenwindow_existence.js#L6) は hidden window が macOS で true、それ以外で false の assertion を持つ。Linux proof では default 側だけで、Floorp workspace / tab / web panel や広い memory safety の oracle ではない。

固定 #84 [test_nsIMutableArray.js](https://github.com/Floorp-Projects/Floorp-Runtime/blob/460106115bc76b026c8bf8dad24df7fcb07f97c2/xpcom/tests/unit/test_nsIMutableArray.js) は append / null / insert / replace / clear / enumerate 等の XPCOM API semantics を検査する。両 manifest の default head / support を保持する recipe であることと、実 support completeness は別に扱う。

[linux-debug-proof.md:106](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/qa/linux-debug-proof.md:106) の 1 browser-chrome + 1 xpcshell、各 intentional failing canary、exact identity / exit 1 / complete mozlog、retry 4 や skip を PASS にしない条件は初期 smoke proof として妥当。ただし全 eligible manifests の被覆率や Floorp feature coverage の分母は得られない。今後 complete dependency inventory、実 parser、known-bad / fixed、profile / child cleanup、failure receipts を cold native worker で確認してから広げる。

### OS adapters と executor の保守

キット [probes.py:77](/workspace/qa-review-v030/fixes/archive-verification/Floorp_QA_Implementation_Kit_v0.3.0/tools/qa/probes.py:77) は Linux / Darwin の POSIX helper に限定し、Windows を実行前に拒否する。今回 Popen 未呼び出しを確認した。[agent.py:119](/workspace/qa-review-v030/fixes/archive-verification/Floorp_QA_Implementation_Kit_v0.3.0/tools/qa/agent.py:119) も native OS / architecture と POSIX boundary を要求する。selftests の POSIX child tests の skip は Windows backend 完了ではない。実 GUI/input permissions、macOS の child cleanup、sandbox、キャンペーン全体の hard timeout は未検証。

Floorp source `execute()`、kit probe、Runtime `run_owned()` は異なる boundary を持つ executor。コピーがあることだけで defect とはしない。修正を横展開する際は、sink EIO/EDQUOT、closed pipes、late fork/setsid、cancel、pre-existing unrelated child を共通の既知負例 corpus にし、どの adapter が何を保証するか明記する。単純に共通 executor に置換すると単体配布や Linux cgroup と POSIX helper の境界を変えるため、別変更として検証する。

## Blacksmith への移行準備: intentional UNVERIFIED

公式仕様・価格の観測は 2026-10-09。ユーザー workspace の provider 設定、組織 token、runner CLI にアクセスしていない。公式の advertised capacity / concurrency を実用上の availability、hard cap、実測性能の証拠にしない。

### ディスクにより physical runner と QA scope が違う

[公式 runner overview](https://docs.blacksmith.sh/blacksmith-runners/overview) の Ubuntu x64 既定仕様を下表で照合した。公表値は total capacity で、利用可能 free bytes ではない。公式 GB の数値は QA の GiB と同一視しない。

| role | 固定 recipe の前提 | 既定 Blacksmith candidate | 判定と必要確認 |
|---|---|---|---|
| consumer physical machine | 4 core / 16 GiB、disk ≥120 GiB、initial free ≥100 GiB、transfer 後 ≥80 GiB | 8 vCPU / 32 GB / 160 GB | 4-vCPU の 80-GB disk は total でも不足。8-vCPU は候補だが OS / locks / transfer 後の実 free を確認する。 |
| consumer bounded native scope | 4 CPU / 14 GiB / pids 1–512 | 上記 machine 内の別 scope | larger machine を買っても正確な scope は変更しない。 |
| builder physical machine | 8 core / 32 GiB、disk ≥200 GiB、initial free ≥180 GiB、source materialize 後 ≥140 GiB | 16 vCPU / 64 GB / 750 GB | 8-vCPU default 160-GB disk は documented initial reserve を満たせない。別の reviewed fresh disk を付けない場合、16-vCPU が既定候補。 |
| builder bounded native scope | 8 CPU / 28 GiB / pids 1–512 | 上記 machine 内の別 scope | `MOZ_NUM_JOBS=6` / `mach build --jobs=6` は固定。16-vCPU throughput を仮定しない。 |

根拠: #84 [linux-debug-proof.md:58](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/qa/linux-debug-proof.md:58)、76–85 行、[qa3_native_build.py:275](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts/qa3_native_build.py:275)、300 / 349 行、[qa3_native_consume.py:411](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts/qa3_native_consume.py:411)、[verify_budget():629](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts/qa3_native_io.py:629)。8-vCPU “32 GB” だけでは documented builder “32 GiB” を満たすとも断言できない。free upgrade は保証として採用しない。

**条件 / 再現:** 最小 CPU/RAM だけで 4-vCPU consumer / 8-vCPU builder を選ぶ移行案。mock resources の小検査で consumer 80 GB < post-transfer 80 GiB、generous 80 GiB < initial 100 GiB、builder generous 160 GiB < initial 180 GiB を拒否した。実ディスクの割当・巨大ファイル生成はしていない。

**影響 / 修正案:** 起動前に fail、容量不足、誤った費用見積り。physical disk/RAM と actual free の receipts を別に採る。現在の self-hosted workflow 欠陥として起票しない。consumer “4CPU/14GiB” は native scope の値であり、provider の total machine specification と分ける。

### ラベル置換だけでは external launcher を満たさない

[qa3-linux-debug-proof.yml:57](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/qa3-linux-debug-proof.yml:57)、136 行は self-hosted labels。93 / 174 行では `/opt/qa3/bin/launch-native-proof` と固定 offline Python/toolchain inputs を使う。Blacksmith action / provisioning / paid controller は実装されていない。

[linux-debug-proof.md:44](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/qa/linux-debug-proof.md:44) の fresh native UID、root-owned launcher / immutable ancestors、正確な cgroup v2 permissions、scrubbed HOME、separate boots、controller credentials を持たない network、whole-scope bounded cleanup は、provider が ephemeral VM と広告しているだけでは成立しない。各 provider image で provision と adversarial boundary tests を完了し、必要な locks / cold wheel inventory の native parser probe を採る必要がある。今は承認された provider 登録・実行に進む段階ではない。

### 全 OS 対応は worker 配置だけでは得られない

公式 [runner overview](https://docs.blacksmith.sh/blacksmith-runners/overview) では macOS は Apple Silicon M4 ARM64 で、native Intel SKU は掲載されていない。mac universal package に ARM run があるだけでは同じ bytes の native Intel run は補えない。Rosetta を native Intel 証拠にはしない。

Windows Server 2025 は Public Beta、WinAppDriver は headless VM のため非同梱。これはすべての GUI 手法が不可能という断定ではなく、desktop session / input / right-click / cleanup をまだ確認していない理由である。Linux ARM も現在の Linux x64 ELF / resource / plan 条件をそのまま流用できない。5 native targets の完了は QA3-07 の別実証。

## 並行性・timeout・費用・保存量

### cross-run concurrency は制限していない

#84 [workflow:30](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/qa3-linux-debug-proof.yml:30) の group は repository + run_id + run_attempt を含む。独立 run は別 group なので、複数 proof runs の serialize / spend cap にはならない。同じ run/attempt の衝突を避ける設計と、組織の最大 jobs / daily spend / GUI session 制約は別である。[GitHub concurrency documentation](https://docs.github.com/en/actions/how-tos/write-workflows/choose-when-workflows-run/control-workflow-concurrency) の同 group 制限と一致する。

**条件:** caller が複数 proof runs を並行投入する場合。provider 側に queue / limits があると仮定した budget。**影響:** 同時課金、disk と evidence の総量、GUI session 競合。**修正案:** 信頼される controller で cross-run concurrency / launch budget を別に設定し、必要なら共有 group を使う。GUI は 1 desktop あたり 1 session、独立 Xvfb display の並行性は実測する。現行の unique group を isolation/code bug として扱わない。

Blacksmith の [Spending Alerts](https://docs.blacksmith.sh/introduction/settings) は monthly threshold 到達で email notification を送る機能として説明される。hard stop とする根拠はない。parent の現 workspace settings 証拠とも同じ。provider が concurrency unlimited と説明していても自動 approval / cost authorization / reliable throughput の証拠ではない。

### 7h の serial timeout scenario と compute arithmetic

producer 360 分、consumer は `needs: producer` で 60 分なので timeout の和は **7h**。5 分 preflight と queue は別で、checkout / transfer / upload は各 job の予算を消費する。cancellation 後の外部 cleanup の effective bound は未測定。各 job の限界値であり、成功時実 walltime や provider job limit を測定したものではない。以前の 6h を end-to-end budget として使う場合は計算を改める。6h builder budget 自体には整合する。

[公式 pricing](https://www.blacksmith.sh/pricing) に表示される Ubuntu x64 baseline $0.004/min と、[overview](https://docs.blacksmith.sh/blacksmith-runners/overview) の CPU 比例 billing 説明から線形料金を仮定した scenario は次のとおり。8 / 16 vCPU の authenticated organization SKU quote ではない。

`builder: 360 min × ($0.004 × 16/2) = $11.52`

`consumer: 60 min × ($0.004 × 8/2) = $0.96`

**gross compute = $12.48 / proof**。free allowance、契約 discount、tax、storage、cache / static IP 等、private prerequisite の GH-hosted 使用量は未反映。合計は 3120 equivalent x64 2-vCPU minutes なので “3000 free minutes” を actual 3000 wall minutes と読めない。月内の先行使用量も不明。失敗して limit 前に止まる場合 / 実成功時間 / interruption 後 cleanup で値は変わる。

16CPU の physical builder を課金しても recipe は 8CPU quota / jobs6 を要求する。provider の 2× speed / savings 広告をこの build の実測としない。standard GitHub-hosted **public** repository CI は [GitHub billing](https://docs.github.com/en/billing/concepts/product-billing/github-actions) 上無料で、そこから Blacksmith へ移すなら compute cost が新たに発生する。重い **new private** proof の cost は別に見積もる。existing public CI の “67% saving” は根拠にしない。

### 保存上限と課金の分母

| 項目 | 固定コードの値 | 意味 |
|---|---|---|
| artifact retention | 14 days | primary / support / producer evidence / consumer evidence の workflow 値 |
| compressed input | primary + support 合計 ≤20 GiB | producer と consumer の code 制約。doc の各 artifact ≤20 に加えて合計が制限される。 |
| transport | transferred wrapper ZIP 合計 ≤20 GiB、展開 wrapper budget 20 GiB | metadata / ZIP overhead を含めた実 upload size との整合は native transfer で未測定。 |
| decoded native archives | 共有 50 GiB / 200,000 members | 資格用 native extraction の logical data budget |
| producer / consumer staging | 30 / 50 GiB | 一時処理 budget。保存 artifact のサイズと同じではない。 |
| retained diagnostic log | role 内累積 2 GiB | decoded binary data と別。2 roles の upload 合計 2 GiB と読まない。 |
| free reserve | builder20 / consumer10 GiB | 実 free-space monitor 条件。disk 全体の購入容量と別。 |

根拠: [workflow:99](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/qa3-linux-debug-proof.yml:99)、[qa3_native_io.py:20](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts/qa3_native_io.py:20)、[build.py:439](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts/qa3_native_build.py:439)、[consume.py:173](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts/qa3_native_consume.py:173)、[transport.py:339](/workspace/qa-review-v030/repos/Floorp-Runtime/.github/workflows/scripts/qa3_native_transport.py:339)。

GitHub storage は保持 bytes と保持 hours を積算し、Actions artifacts / Packages は shared allowance。超過 shared storage rate は $0.25/binary-GB-month と記載される。[公式 billing](https://docs.github.com/en/billing/concepts/product-billing/github-actions)。算術例: 20 GiB の artifact bytes を 14 日保存すると 6720 GiB-hour、30-day month 換算 9.333 GiB-month、gross $2.33。これは input だけの例で、logs / JSON / metadata / 複数 runs / included quota を含む総額見積りではない。uploaded stdout/stderr は artifact bytes に含む。workflow console logs と同一に扱わない。14d retention は既に発生した accrued cost を取り消すこともない。

Blacksmith sticky disks は optional persistent snapshots で、[公式 storage docs](https://docs.blacksmith.sh/blacksmith-caching/dependencies-sticky-disks) と [pricing](https://www.blacksmith.sh/pricing) の $0.50/GB-month は GitHub artifacts と別。cache hit は authenticated qualification の再利用ではなく、現在の fresh/cold consumer の前提との適合審査も別。sticky disk、static IP や budget 設定は追加していない。

provider/API の実 artifact-size limit、transfer p50/p95、build RAM / disk peak、reboot・cancellation の effective bound は今回測定していない。上記 20/30/50/2GiB は source の policy 値であって、provider 側が必ずその量を許すという保証ではない。

## 今回の小検査と証拠

実行した [portability-ops-negative.py](/workspace/qa-review-v030/review-qa308/fixtures/portability-ops-negative.py) は固定 modules を読み、容量 / affinity / cgroup の値を mock した小 fixture。AS 512 MiB / CPU15s / file8MiB 上限で最終実行 exit 0。

| 検査 | 結果 |
|---|---|
| 4CPU consumer total80 GB と post-transfer free80 GiB | reject |
| generous total80 GiB と initial free100 GiB | reject |
| 8CPU builder generous total160 GiB と initial free180 GiB | reject |
| physical8CPU32GiB consumer と 4CPU14GiB check | accept（mock） |
| physical16CPU64GiB builder と 8CPU28GiB check | accept（mock、jobs変更なし） |
| source plan on mock Darwin | FAIL before tests / publication false |
| source plan on mock Windows | FAIL before tests / publication false |
| kit POSIX probe on mock Windows | reject before Popen |

6 rejection / 2 acceptance の 8 checks。巨大ファイルの割当 / browser や native build / network / model / provider credentials は使わない。4 selected head inputs の plan SHA256、15 design files の原本 byte identity も保存。これで platform backend が動いたとは扱わない。

- 最終 [portability-ops-negative.json](/workspace/qa-review-v030/review-qa308/evidence/portability-ops-negative.json)、[最終 log](/workspace/qa-review-v030/review-qa308/evidence/portability-ops-negative-final.log)。
- 初回 [fixture-first-failure.json](/workspace/qa-review-v030/review-qa308/evidence/portability-ops-fixture-first-failure.json): 制限下で Git default pack mmap が失敗。review 側の Git window を 8 MiB / packed limit32 MiB にして読めた。target build / QA source defect ではない。
- 二回目 [fixture-second-failure.json](/workspace/qa-review-v030/review-qa308/evidence/portability-ops-fixture-second-failure.json)、[raw log](/workspace/qa-review-v030/review-qa308/evidence/portability-ops-negative.log): U object 不在で比較未実施。object existence を先に判定し、最終結果は equality null とした。初回・二回目の output directories を消していない。
- [公式 facts / provenance の短い summary](/workspace/qa-review-v030/review-qa308/evidence/portability-official-summary.json) に直接 URL、観測数値、算術の仮定、local raw の SHA256 を保存。長い web tool 原文は local に留め、配送 ZIP に添付しない。先行 snapshot の inaccessible settings URL も local 記録に残し、実 facts は上記直接成功した official URLs を使用する。

## QA3-01〜11 の着手順と完了条件への影響

[docs/04-work-orders.md:91](/workspace/qa-review-v030/fixes/archive-verification/Floorp_QA_Implementation_Kit_v0.3.0/docs/04-work-orders.md:91) の **01/04 → 02/03 と 05/06 → 07/08 → 09 → 10/11** を維持。実装存在と受け入れ完了を分ける。

| 作業票 | この観点で認められる進捗 | 完了前の必要証拠 |
|---|---|---|
| QA3-01 | 5-target generated config / Debug-only tests override / PGO preservation の synthetic tests | actual configure と native compile、macOS Debug を含む |
| QA3-04 | exact106 identities、Linux host subset、package run 内共通 shadow | 実 clean CI evidence / source origin ledger と、4 package jobs が成功を needs で要求する required phase |
| QA3-02 | native producer / support / inventory / compressed budget code | 実 same-build package/tests、cold dependency / physical free receipts |
| QA3-03 | 2-case + negative canary / mozlog / mock transport contracts | P1 cleanup 修正、external launcher boundary、actual packaged parser と native harness |
| QA3-05 | kit の limited 2 probes / existing-final subset adapters | 認可された exact final artifacts の Linux / Mac Intel / Mac ARM native evidence |
| QA3-06 | 設計と adapter scaffolding | 最終製品の Floorp-specific suite、tab/workspace/restart known-bad、dev-only migration inventory |
| QA3-07 | 5-target mapping の設計 | Windows、Linux x64/ARM、Mac Intel/ARM の real OS/input/cleanup、同じ universal bytes の両 native runs |
| QA3-08 | subject 分離 / UNVERIFIED 表示 | trusted controller history、expiry/revocation、厳格キーで拒否する cross-run reuse |
| QA3-09 | publication false、既存 gate を保持 | dedicated public verifier、全 target/artifact/source/qualification と manual approval の拘束 |
| QA3-10 | registered action / deterministic fixture の subset | full feature oracle / model adapter、campaign bounds、native known-bad→fixed replay |
| QA3-11 | documented caps、14d retention、算術 cost scenario | real p50/p95 time、CPU/RAM/disk/log/artifact sizes、flake/quarantine、restore drills |

全 eligible manifests の広域完走時間、跨 OS performance、Blacksmith savings を約束できる測定は無い。新 private native launch の No-Go を既存 public PR QA の停止に拡張しない。


# SPDX-License-Identifier: MPL-2.0
"""Synthetic regressions for the four review findings; no browser or network."""

from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import unittest
from unittest import mock

if os.name == "posix":
    import resource

TOOLS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TOOLS))
from core import QAError
import test_core


class ReviewRegressions(unittest.TestCase):
    def setUp(self):
        self.fixture = test_core.KitTest()
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)

    def run_child(self, mode, payload=b"", close_input=False):
        output = self.fixture.root / (mode + ".log")
        env = {
            "PATH": os.environ["PATH"],
            "LANG": "C.UTF-8",
            "TMPDIR": str(self.fixture.root),
            "PYTHONDONTWRITEBYTECODE": "1",
            "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_CONFIG_GLOBAL": "/dev/null",
        }
        with output.open("xb") as stream:
            proc = subprocess.Popen(
                [sys.executable, "-B", str(Path(__file__).resolve()), mode],
                stdin=subprocess.PIPE,
                stdout=stream,
                stderr=subprocess.STDOUT,
                env=env,
                start_new_session=True,
                preexec_fn=child_limits,
            )
            try:
                proc.stdin.write(payload)
                proc.stdin.flush()
                if close_input:
                    proc.stdin.close()
                try:
                    code = proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    code = proc.wait(timeout=3)
            finally:
                if not proc.stdin.closed:
                    proc.stdin.close()
                if proc.poll() is None:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait(timeout=3)
        raw = output.read_text()
        self.assertEqual(code, 0, raw)
        return json.loads(raw.splitlines()[-1])

    @unittest.skipUnless(os.name == "posix", "Bounded child requires POSIX rlimit")
    def test_huge_attempt_returns_block_with_bounded_memory(self):
        self.assertEqual(self.run_child("huge-attempt")["status"], "BLOCK")

    def test_attempt_cap_rejects_complete_overlarge_history(self):
        f = self.fixture
        for attempt in range(2, 102):
            row = copy.deepcopy(f.records[0])
            row["attempt"] = attempt
            f.records.append(row)
        self.assertEqual(f.evaluate()["status"], "BLOCK")

    def test_attempt_cap_accepts_complete_bounded_history(self):
        f = self.fixture
        for attempt in range(2, 101):
            row = copy.deepcopy(f.records[0])
            row["attempt"] = attempt
            f.records.append(row)
        self.assertEqual(f.evaluate()["status"], "PASS")

    def test_assertion_free_trace_cannot_pass(self):
        f = self.fixture
        good = events()
        self.assertNotEqual(f.log(good[:2] + good[3:])["status"], "PASS")

    def test_retry_warning_cannot_pass(self):
        self.assertNotEqual(
            self.with_event(
                {
                    "action": "log",
                    "level": "WARNING",
                    "message": "Retrying test after first failure",
                }
            )["status"],
            "PASS",
        )

    def test_failed_child_cannot_pass(self):
        self.assertNotEqual(
            self.with_event(
                {"action": "process_exit", "process": "fixture", "exitcode": 1}
            )["status"],
            "PASS",
        )

    def test_unknown_execution_event_cannot_pass(self):
        self.assertNotEqual(
            self.with_event({"action": "unknown_required_diagnostic"})["status"], "PASS"
        )

    def test_child_exit_requires_integer_field(self):
        for patch in (
            {},
            {"exitcode": False},
            {"exitcode": 0.0},
            {"exitcode": None},
            {"exitcode": "0"},
        ):
            with self.subTest(patch=patch), self.assertRaises(QAError):
                self.with_event(
                    {"action": "process_exit", "process": "fixture", **patch}
                )

    def test_missing_empty_duplicate_suite_selection_rejected(self):
        for selection in (None, [], ["browser_example.js", "browser_example.js"]):
            value = events()
            if selection is None:
                value[0].pop("tests")
            else:
                value[0]["tests"] = selection
            with self.subTest(selection=selection), self.assertRaises(QAError):
                self.fixture.log(value)

    def test_typed_child_zero_and_positive_assertion_pass(self):
        self.assertEqual(
            self.with_event(
                {"action": "process_exit", "process": "fixture", "exitcode": 0}
            )["status"],
            "PASS",
        )

    def test_mozlog_input_limits_reject_without_large_allocations(self):
        for name, limit in (
            ("MAX_MOZLOG_BYTES", 1),
            ("MAX_MOZLOG_LINE_BYTES", 8),
            ("MAX_MOZLOG_EVENTS", 4),
        ):
            with (
                self.subTest(limit=name),
                mock.patch("core." + name, limit),
                self.assertRaises(QAError),
            ):
                self.fixture.log(events())

    def test_grouped_suite_selection_preserves_positive_coverage(self):
        value = events()
        value[0]["tests"] = {"browser-chrome": ["browser_example.js"]}
        self.assertEqual(self.fixture.log(value)["status"], "PASS")

    @unittest.skipUnless(os.name == "posix", "Agent stdin backend is POSIX")
    def test_agent_partial_line_obeys_deadline_and_closes(self):
        value = self.run_child("fake-stdio", b"{")
        self.assertEqual(value["status"], "budget-exhausted")
        self.assertTrue(value["fakeDriverClosed"])
        self.assertTrue(value["stdinBlockingRestored"])

    @unittest.skipUnless(os.name == "posix", "Agent stdin backend is POSIX")
    def test_agent_pipelined_complete_frames_preserved(self):
        value = self.run_child(
            "fake-stdio", b'{"kind":"observe"}\n{"kind":"observe"}\n'
        )
        self.assertEqual(value["completedSteps"], 2)
        self.assertTrue(value["fakeDriverClosed"])

    @unittest.skipUnless(os.name == "posix", "Agent stdin backend is POSIX")
    def test_agent_eof_without_pending_frame(self):
        value = self.run_child("fake-stdio", close_input=True)
        self.assertEqual(value["status"], "input-ended")
        self.assertTrue(value["fakeDriverClosed"])

    @unittest.skipUnless(os.name == "posix", "Agent stdin backend is POSIX")
    def test_agent_partial_eof_records_error_and_closes(self):
        value = self.run_child("fake-stdio", b"{", close_input=True)
        self.assertEqual(value["status"], "finding-or-environment-error")
        self.assertTrue(value["fakeDriverClosed"])

    def with_event(self, event):
        good = events()
        return self.fixture.log(good[:3] + [event] + good[3:])


def events():
    return [
        {"action": "suite_start", "tests": ["browser_example.js"]},
        {"action": "test_start", "test": "browser_example.js"},
        {
            "action": "test_status",
            "test": "browser_example.js",
            "subtest": "invariant",
            "status": "PASS",
        },
        {"action": "test_end", "test": "browser_example.js", "status": "OK"},
        {"action": "suite_end"},
    ]


def child_limits():
    resource.setrlimit(resource.RLIMIT_AS, (256 * 1024**2, 256 * 1024**2))
    resource.setrlimit(resource.RLIMIT_CPU, (8, 8))
    resource.setrlimit(resource.RLIMIT_FSIZE, (8 * 1024**2, 8 * 1024**2))


def child(mode):
    if mode == "huge-attempt":
        f = test_core.KitTest()
        f.setUp()
        try:
            f.records[0]["attempt"] = 2**53 - 1
            print(json.dumps(f.evaluate()))
        finally:
            f.doCleanups()
    elif mode == "fake-stdio":
        import agent

        class FakeDriver:
            closed = False

            def __init__(self, repo, browser, output, subject):
                output.mkdir()

            def observe(self):
                return {"synthetic": True}

            def execute(self, action):
                return self.observe()

            def close(self):
                FakeDriver.closed = True

        agent.Driver = FakeDriver
        import tempfile

        original_blocking = os.get_blocking(sys.stdin.fileno())
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            value = agent.execute_campaign(
                root,
                root / "unused",
                {"id": "synthetic-review"},
                root / "out",
                None,
                2,
                1,
            )
            value.update(
                fakeDriverClosed=FakeDriver.closed,
                stdinBlockingRestored=os.get_blocking(sys.stdin.fileno())
                == original_blocking,
            )
            print(json.dumps(value))
    else:
        raise ValueError("Unknown synthetic mode")


if __name__ == "__main__":
    if len(sys.argv) == 2 and sys.argv[1] in ("huge-attempt", "fake-stdio"):
        child(sys.argv[1])
    else:
        unittest.main()

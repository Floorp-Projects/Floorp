# SPDX-License-Identifier: MPL-2.0
"""Fail-closed QA evidence primitives. Python >= 3.12, standard library only.

Hashes bind evidence, not its author. Only a separately trusted workflow may
turn the resulting verdict into a publication decision. Never run this module
from unreviewed candidate code in a credential-bearing gate job.
"""
from __future__ import annotations

import hashlib
import json
import re
import stat
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

BASELINE = "013bb6c9ed19250592898ec8fbc8d7d24aa847be"
TARGETS = {
    "windows/x86_64": ("noraneko-windows-x86_64-installer", "floorp-windows-x86_64.installer.exe"),
    "linux/x86_64": ("noraneko-linux-x86_64-installer", "floorp-linux-x86_64.tar.xz"),
    "linuxAarch64/aarch64": ("noraneko-linux-aarch64-installer", "floorp-linux-aarch64.tar.xz"),
    "mac/x86_64": ("noraneko-mac-universal-installer", "floorp-macOS-universal.dmg"),
    "mac/aarch64": ("noraneko-mac-universal-installer", "floorp-macOS-universal.dmg"),
}
SHA = re.compile(r"[0-9a-f]{40}\Z")
DIGEST = re.compile(r"sha256:[0-9a-f]{64}\Z")
ID = re.compile(r"[a-zA-Z0-9][a-zA-Z0-9._/-]{0,239}\Z")
STATUSES = {"PASS", "FAIL", "ERROR", "TIMEOUT", "CRASH", "SKIP", "INCOMPLETE"}
MAX_ATTEMPTS = 100
MAX_MOZLOG_BYTES = 128 * 1024 * 1024
MAX_MOZLOG_LINE_BYTES = 4 * 1024 * 1024
MAX_MOZLOG_EVENTS = 1_000_000


class QAError(ValueError):
    """Invalid, incomplete, ambiguous or mismatched evidence."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise QAError(message)


def obj(value: Any, required: Iterable[str], optional: Iterable[str] = ()) -> dict:
    require(type(value) is dict, "Expected JSON object")
    missing = set(required) - value.keys()
    extra = value.keys() - set(required) - set(optional)
    require(not missing and not extra, f"Schema keys: missing={sorted(missing)}, extra={sorted(extra)}")
    return value


def positive(value: Any, label: str) -> int:
    require(type(value) is int and 0 < value <= 2**53 - 1, f"Invalid positive safe integer: {label}")
    return value


def text(value: Any, label: str) -> str:
    require(type(value) is str and bool(value.strip()), f"Invalid string: {label}")
    return value


def _unique(pairs: list[tuple[str, Any]]) -> dict:
    result: dict = {}
    for key, value in pairs:
        require(key not in result, f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def loads(raw: str) -> Any:
    try:
        return json.loads(raw, object_pairs_hook=_unique,
                          parse_constant=lambda token: (_ for _ in ()).throw(QAError(f"Invalid JSON constant: {token}")))
    except (json.JSONDecodeError, UnicodeError) as exc:
        raise QAError(f"Invalid JSON: {exc}") from exc


def read_json(path: Path, max_bytes: int = 32 * 1024 * 1024) -> Any:
    require(path.is_file() and not path.is_symlink(), f"Not a regular JSON file: {path}")
    require(path.stat().st_size <= max_bytes, f"JSON too large: {path}")
    return loads(path.read_text(encoding="utf-8"))


def canonical(value: Any) -> bytes:
    # Kit-local digest format, NOT a reimplementation of release_provenance.ts.
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical(value)).hexdigest()


def file_digest(path: Path) -> str:
    require(path.is_file() and not path.is_symlink(), f"Not a regular file: {path}")
    with path.open("rb") as stream:
        return "sha256:" + hashlib.file_digest(stream, "sha256").hexdigest()


def blob_sha(path: Path) -> str:
    data = path.read_bytes()
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def write_json(path: Path, value: Any) -> None:
    # Exclusive write: never silently overwrite a previous attempt or verdict.
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def contained(root: Path, relative: str) -> Path:
    require(type(relative) is str and bool(relative), "Invalid evidence path")
    require(not Path(relative).is_absolute() and "\\" not in relative,
            "Absolute / platform-dependent paths are forbidden")
    require(all(part not in ("", ".", "..") for part in relative.split("/")), "Unsafe path component")
    root = root.resolve(strict=True)
    candidate = root
    for part in relative.split("/"):
        candidate /= part
        require(not candidate.is_symlink(), f"Symlink in evidence path: {candidate}")
    resolved = candidate.resolve(strict=True)
    require(resolved.is_relative_to(root) and resolved.is_file(), "Evidence escapes its root or is not a file")
    return resolved


def evidence_entry(root: Path, path: Path) -> dict:
    relative = path.absolute().relative_to(root.absolute()).as_posix()
    safe = contained(root, relative)
    return {"path": relative, "digest": file_digest(safe)}


def verify_evidence(root: Path, entries: Any) -> None:
    require(type(entries) is list and len(entries) > 0, "No evidence files")
    seen = set()
    for entry in entries:
        obj(entry, ("path", "digest"))
        require(entry["path"] not in seen, "Duplicate evidence path")
        seen.add(entry["path"])
        require(DIGEST.fullmatch(text(entry["digest"], "digest")) is not None, "Invalid evidence digest")
        require(file_digest(contained(root, entry["path"])) == entry["digest"], "Evidence file digest mismatch")


def _zip_member(path: Path, expected: str, max_bytes: int = 32 * 1024 * 1024) -> bytes:
    with zipfile.ZipFile(path) as archive:
        members = archive.infolist()
        require(len(members) == 1 and members[0].filename == expected, f"Unexpected ZIP contents: {path}")
        info = members[0]
        require(not stat.S_ISLNK(info.external_attr >> 16) and not info.is_dir(), "Linked/directory ZIP member")
        require(0 < info.file_size <= max_bytes, "ZIP member missing or too large")
        return archive.read(info)  # zipfile validates CRC on read.


def subject_from_final(input_data: dict, native: dict, package_zip: Path,
                       record_zip: Path) -> dict:
    """Adapt the existing final-package QA intake AFTER its GitHub checks.

    This intentionally has no GitHub credentials and cannot authenticate a
    caller-supplied input.json by itself. The trust boundary is documented.
    """
    required = ("runId", "floorpHead", "floorpVersion", "platform", "arch", "unsigned", "package", "record")
    obj(input_data, required, ("sourceEligibility", "probeHead"))
    require(SHA.fullmatch(text(input_data["floorpHead"], "floorpHead")) is not None, "Bad Floorp SHA")
    positive(input_data["runId"], "runId")
    require(type(input_data["unsigned"]) is bool, "unsigned must be boolean")
    target = f"{input_data['platform']}/{input_data['arch']}"
    require(target in TARGETS, f"Unknown target: {target}")
    artifact_name, filename = TARGETS[target]
    suffix = "-unsigned" if input_data["unsigned"] else ""
    for key, archive in (("package", package_zip), ("record", record_zip)):
        metadata = obj(input_data[key], ("id", "name", "digest"))
        positive(metadata["id"], f"{key}.id")
        require(DIGEST.fullmatch(text(metadata["digest"], "digest")) is not None, "Bad artifact digest")
        require(file_digest(archive) == metadata["digest"], f"Downloaded {key} archive digest mismatch")
    require(input_data["package"]["id"] != input_data["record"]["id"], "Package and record artifacts cannot be identical")
    require(input_data["package"]["name"] == artifact_name + suffix, "Wrong package artifact name")
    require(input_data["record"]["name"] == f"floorp-native-verification-{target.replace('/', '-')}-v2", "Wrong record artifact name")
    archived_record = loads(_zip_member(record_zip, "native-verification.json").decode("utf-8"))
    require(native == archived_record, "Native record does not equal its verified archive")
    require(native.get("schema_version") == 2 and native.get("verification", {}).get("status") == "verified", "Native verification not successful")
    require(native.get("floorp") == {"repository": "Floorp-Projects/Floorp", "head_sha": input_data["floorpHead"],
                                     "workflow_run_id": input_data["runId"]}, "Native Floorp identity mismatch")
    require(native.get("target_key") == input_data["platform"] and native.get("native_arch") == input_data["arch"], "Native target mismatch")
    require(native.get("floorp_package") == {"artifact_id": input_data["package"]["id"], "artifact_name": input_data["package"]["name"],
        "artifact_digest": input_data["package"]["digest"], "unsigned": input_data["unsigned"]}, "Native package identity mismatch")
    build_id = native.get("runtime", {}).get("expected_build_id")
    require(type(build_id) is str and re.fullmatch(r"[0-9]{14}", build_id) is not None, "Bad BuildID")
    try:
        datetime.strptime(build_id, "%Y%m%d%H%M%S")
    except ValueError as exc:
        raise QAError("BuildID is not a UTC calendar timestamp") from exc
    require(native.get("app_build_id") == native.get("platform_build_id") == build_id, "BuildIDs disagree")
    require(re.fullmatch(r"\d+\.\d+(?:\.\d+)?", text(native.get("firefox_version"), "firefox_version")) is not None, "Bad Firefox version")
    text(native.get("build_id2"), "build_id2")
    # Stream installer bytes; never extract, execute or load a large artifact into RAM.
    with zipfile.ZipFile(package_zip) as archive:
        entries = archive.infolist()
        require(len(entries) == 1 and entries[0].filename == filename, "Wrong installer ZIP member")
        info = entries[0]
        require(not stat.S_ISLNK(info.external_attr >> 16) and not info.is_dir() and info.file_size > 0, "Invalid installer member")
        with archive.open(info) as stream:
            installer_digest = "sha256:" + hashlib.file_digest(stream, "sha256").hexdigest()
    value = {"schemaVersion": 1, "authority": "stable-v2-native-record", "floorpHead": input_data["floorpHead"],
             "packageRunId": input_data["runId"], "floorpVersion": text(input_data["floorpVersion"], "floorpVersion"),
             "target": target, "unsigned": input_data["unsigned"], "package": input_data["package"],
             "installer": {"name": filename, "digest": installer_digest}, "nativeRecordDigest": digest(native),
             "runtime": native["runtime"], "firefoxVersion": native["firefox_version"], "buildID2": native["build_id2"],
             "intakeContext": {"probeHead": input_data.get("probeHead"),
                               "sourceEligibility": input_data.get("sourceEligibility")}}
    probe_head = value["intakeContext"]["probeHead"]
    require(probe_head is None or (type(probe_head) is str and SHA.fullmatch(probe_head) is not None), "Bad probe head")
    eligibility = value["intakeContext"]["sourceEligibility"]
    require(eligibility is None or type(eligibility) is dict, "Bad source eligibility context")
    return {**value, "id": digest(value)}


def validate_subject(subject: dict) -> None:
    obj(subject, ("schemaVersion", "authority", "floorpHead", "packageRunId", "floorpVersion", "target", "unsigned", "package",
                  "installer", "nativeRecordDigest", "runtime", "firefoxVersion", "buildID2", "intakeContext", "id"))
    obj(subject["intakeContext"], ("probeHead", "sourceEligibility"))
    require(subject["schemaVersion"] == 1 and subject["authority"] == "stable-v2-native-record", "Unsupported subject")
    require(subject["target"] in TARGETS and type(subject["unsigned"]) is bool, "Bad target or signing state")
    require(SHA.fullmatch(text(subject["floorpHead"], "floorpHead")) is not None, "Bad SHA")
    positive(subject["packageRunId"], "packageRunId")
    require(subject["id"] == digest({k: v for k, v in subject.items() if k != "id"}), "Subject ID mismatch")


def make_plan(subject: dict, policy: dict, profile: str) -> dict:
    validate_subject(subject)
    obj(policy, ("schemaVersion", "profiles"))
    require(policy["schemaVersion"] == 1 and profile in policy["profiles"], "Unknown policy profile")
    selected = obj(policy["profiles"][profile], ("scope", "cases"))
    cases = []
    seen = set()
    for row in selected["cases"]:
        obj(row, ("id", "layer", "targets", "kind", "implementation", "signedOnly"))
        require(row["id"] not in seen and ID.fullmatch(row["id"]) is not None, "Invalid/duplicate case ID")
        seen.add(row["id"])
        require(row["layer"] in ("L1", "L2", "L3") and type(row["signedOnly"]) is bool, "Invalid case")
        require(set(row["targets"]).issubset(TARGETS), "Unknown policy target")
        # Subject v1 binds a final PRODUCT artifact. Debug upstream evidence
        # must use its own subject/qualification, never this product plan.
        require(row["layer"] != "L1" and row["kind"] != "mozilla-harness",
                "Debug upstream evidence requires a separate Runtime qualification")
        if subject["target"] in row["targets"]:
            if row["signedOnly"] and subject["unsigned"]:
                require(selected["scope"] not in ("release-readiness", "production-package-readiness"), "Production plan cannot consume unsigned package")
                continue
            cases.append({k: row[k] for k in ("id", "layer", "kind", "implementation")})
    require(bool(cases), "Empty plan is not a successful test plan")
    value = {"schemaVersion": 1, "subjectId": subject["id"], "target": subject["target"],
             "policyDigest": digest(policy), "profile": profile, "scope": selected["scope"], "cases": cases}
    return {**value, "id": digest(value)}


def validate_plan(plan: dict) -> None:
    obj(plan, ("schemaVersion", "subjectId", "target", "policyDigest", "profile", "scope", "cases", "id"))
    require(plan["schemaVersion"] == 1 and plan["id"] == digest({k: v for k, v in plan.items() if k != "id"}), "Plan ID mismatch")
    require(type(plan["cases"]) is list and bool(plan["cases"]), "Empty plan")
    ids = [row["id"] for row in plan["cases"]]
    require(len(ids) == len(set(ids)), "Duplicate planned case")


def result(plan: dict, case_id: str, status: str, kind: str, evidence: list[dict],
           details: Any, attempt: int = 1) -> dict:
    validate_plan(plan)
    require(status in STATUSES, "Unknown result status")
    positive(attempt, "attempt")
    require(attempt <= MAX_ATTEMPTS, "Attempt limit exceeded")
    require(case_id in [row["id"] for row in plan["cases"]], "Unplanned case")
    return {"schemaVersion": 1, "planId": plan["id"], "subjectId": plan["subjectId"],
            "caseId": case_id, "status": status, "kind": kind, "attempt": attempt,
            "evidence": evidence, "details": details}


def evaluate(plan: dict, subject: dict, policy: dict, records: list[dict], evidence_root: Path) -> dict:
    """A local coverage verdict, NEVER a stand-alone publication authorization."""
    validate_subject(subject)
    validate_plan(plan)
    require(make_plan(subject, policy, plan["profile"]) == plan, "Plan was not derived from supplied trusted policy/subject")
    expected = {row["id"]: row for row in plan["cases"]}
    require(type(records) is list and len(records) <= len(expected) * MAX_ATTEMPTS,
            "Result record limit exceeded")
    by_case: dict[str, list[dict]] = {}
    failures = []
    for record in records:
        try:
            obj(record, ("schemaVersion", "planId", "subjectId", "caseId", "status", "kind", "attempt", "evidence", "details"))
            require(record["schemaVersion"] == 1 and record["planId"] == plan["id"] and record["subjectId"] == subject["id"], "Foreign result identity")
            require(record["caseId"] in expected, "Unplanned result")
            require(record["status"] in STATUSES, "Unknown result status")
            positive(record["attempt"], "attempt")
            require(record["attempt"] <= MAX_ATTEMPTS, "Attempt limit exceeded")
            require(record["kind"] == expected[record["caseId"]]["kind"], "Wrong evidence kind")
            verify_evidence(evidence_root, record["evidence"])
            existing = by_case.setdefault(record["caseId"], [])
            require(record["attempt"] not in [r["attempt"] for r in existing], "Duplicate case attempt")
            existing.append(record)
        except (QAError, OSError, KeyError, TypeError) as exc:
            failures.append(f"Rejected record: {exc}")
    for case_id, case in expected.items():
        attempts = by_case.get(case_id, [])
        if not attempts:
            failures.append(f"Missing: {case_id}")
        else:
            numbers = sorted(r["attempt"] for r in attempts)
            if any(number != index for index, number in enumerate(numbers, 1)):
                failures.append(f"Missing attempt history: {case_id}")
            if any(r["status"] != "PASS" for r in attempts):
                failures.append(f"Non-PASS (retries do not erase failures): {case_id}")
        if case["implementation"] == "planned":
            failures.append(f"Not onboarded: {case_id}")
    return {"schemaVersion": 1, "planId": plan["id"], "subjectId": subject["id"], "scope": plan["scope"],
            "status": "PASS" if not failures else "BLOCK", "reasons": failures,
            "expectedCases": len(expected), "reportedCases": len(by_case),
            "publicationAuthorized": False,
            "note": "Local evidence verdict only; existing provenance, protected approval and publisher binding are still required."}


def import_mozlog(path: Path, planned_tests: list[str], evidence_root: Path) -> dict:
    """Validate ONE non-repeat mozlog suite. Test IDs are exact harness IDs.

    Repeat/--verify runs need a separate cycle-aware adapter. Reject duplicate
    starts rather than silently flattening them. Harness-produced resolved IDs
    (not guessed filenames) are the input; empty discovery never passes.
    """
    require(planned_tests and len(planned_tests) == len(set(planned_tests)), "Empty or duplicate Mozilla test plan")
    expected = set(planned_tests)
    assertions = {name: 0 for name in expected}
    started, ended = set(), set()
    suite_started = suite_ended = False
    issues: list[str] = []
    count = 0
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= MAX_MOZLOG_BYTES,
            "Missing, linked or oversized mozlog")
    with path.open("rb") as stream:
        index = 0
        while raw := stream.readline(MAX_MOZLOG_LINE_BYTES + 1):
            index += 1
            require(len(raw) <= MAX_MOZLOG_LINE_BYTES, "Oversize mozlog event")
            if not raw.strip():
                continue
            event = loads(raw.decode("utf-8"))
            require(type(event) is dict and type(event.get("action")) is str, f"Invalid mozlog event at {index}")
            action = event["action"]
            count += 1
            require(count <= MAX_MOZLOG_EVENTS, "Mozlog event limit exceeded")
            if suite_ended:
                require(action in ("log", "process_output"), "Execution event after suite end")
            if action == "suite_start":
                require(not suite_started, "Repeated suite_start is unsupported")
                selected = event.get("tests")
                if type(selected) is dict and all(type(v) is list for v in selected.values()):
                    selected = [name for group in selected.values() for name in group]
                require(type(selected) is list and selected and all(type(name) is str for name in selected),
                        "Missing or empty suite-start selection")
                require(len(selected) == len(set(selected)), "Duplicate suite-start test ID")
                if set(selected) != expected:
                    issues.append("Suite-start selection differs from resolved plan")
                suite_started = True
            elif action == "suite_end":
                require(suite_started and not suite_ended, "Out-of-order suite_end")
                require(started == ended, "suite_end before test completion")
                suite_ended = True
            elif action in ("test_start", "test_status", "test_end"):
                require(suite_started and not suite_ended, "Test event outside suite")
                name = event.get("test")
                require(type(name) is str and name in expected, f"Unplanned Mozilla test ID: {name}")
                if action == "test_start":
                    require(name not in started, "Duplicate test_start; repeat/verify needs cycle-aware adapter")
                    started.add(name)
                else:
                    require(name in started and name not in ended, "Test result without live test")
                    status = event.get("status")
                    if action == "test_status":
                        require(status in ("PASS", "FAIL", "TIMEOUT", "NOTRUN", "SKIP", "PRECONDITION_FAILED"), "Unknown subtest status")
                        text(event.get("subtest"), "subtest")
                        assertions[name] += 1
                    else:
                        require(status in ("OK", "PASS", "FAIL", "ERROR", "TIMEOUT", "CRASH", "SKIP", "EXTERNAL-TIMEOUT", "PRECONDITION_FAILED"), "Unknown test status")
                        ended.add(name)
                    # This baseline policy accepts no expected failures or silent skips.
                    if status not in ("PASS", "OK") or ("expected" in event and event["expected"] != status):
                        issues.append(f"{name}: {status}, expected={event.get('expected')}")
            elif action == "crash":
                issues.append("Harness crash event")
            elif action == "process_exit":
                require(type(event.get("exitcode")) is int, "Missing or non-integer child exitcode")
                if event["exitcode"] != 0:
                    issues.append(f"Unexpected child exit: {event['exitcode']}")
            elif action == "log":
                message = event.get("message", "")
                require(type(message) is str, "Non-string harness log message")
                if event.get("level") in ("ERROR", "CRITICAL", "FATAL"):
                    issues.append(f"Harness {event['level']}: {message}")
                if re.search(r"retry|rerun|TEST-UNEXPECTED", message, re.IGNORECASE):
                    issues.append("First failure or internal retry recorded")
            elif action in ("valgrind_error", "lsan_leak", "mozleak_total", "mozleak_object", "assertion_count"):
                # Do not implement Mozilla's threshold semantics incorrectly.
                issues.append(f"Diagnostic requires upstream policy adapter: {action}")
            elif action not in ("process_output", "process_start", "group_start", "group_end", "shutdown"):
                issues.append(f"Unsupported Mozilla event: {action}")
    if not suite_started or not suite_ended:
        issues.append("Incomplete suite lifecycle")
    if ended != expected:
        issues.append(f"Missing tests: {sorted(expected - ended)}")
    if any(assertions[name] == 0 for name in expected):
        issues.append("Required test has no assertions")
    return {"status": "PASS" if not issues else "INCOMPLETE" if not suite_ended else "FAIL",
            "issues": issues, "planned": len(expected), "started": len(started), "ended": len(ended),
            "events": count, "evidence": [evidence_entry(evidence_root, path)]}

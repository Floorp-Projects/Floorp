# v0.3.0 review-fixes.1

これは元設計 0.3.0 の限定修正版キットです。Floorp 本体へ導入した実装ではありません。元の `DESIGN.md` と 14 文書は byte 単位で保持しています。これらの設計・作業指示はレビュー対象の資料として扱い、利用者の承認や実環境の隔離に代わるものにはしません。

元入力は Floorp commit `87311566a225936fbe7948db142bce3f1d3379d8` の `docs/Floorp_QA_Implementation_Kit_v0.3.0.zip`、150471 bytes、Git blob `e688e2725ce502f36c600cfec88060e7954b30e2`、SHA256 `a4af60380399050f82465864734391227ab34024d26bdf16c31559e2824a8d50` です。この修正版 ZIP は別の hash を持ちます。元 ZIP はそのまま保持し、差分を別途提出します。

|指摘|変更と回帰|
|---|---|
|KIT-P1-01|`evaluate` の最大 attempt に比例する配列生成を廃止し、実際の履歴だけを検査する。attempt は整数 1～100、総 record 数は計画 case 数×100 に制限し、result 生成と schema も一致させる。2^53-1 は 256 MiB の子プロセスで BLOCK、100 の全履歴は PASS、101 は BLOCK。|
|KIT-P1-02|suite-start の非空・重複なし selection と resolved plan の一致、各必須 test の正の subtest assertion、整数の child exitcode 0 を要求する。retry/rerun/TEST-UNEXPECTED と未知 event は成功にしない。元の zero-assertion、retry warning、child exit 1、unknown-action の 4 誤受理を拒否する。|
|KIT-P1-03|Agent の stdin は非 blocking の `os.read` と絶対 deadline で収集する。改行なしの部分入力でも期限に戻り、複数行の buffer を維持し、最後に元の fd blocking flag を復元する。FakeDriver で deadline、EOF、部分 EOF、連続 2 action、cleanup を検証する。|

mozlog の取り込みは最大 128 MiB、1 行 4 MiB、100 万 event に制限します。診断 event の独自 threshold 判定を追加せず、未対応診断は引き続き拒否します。repeat/verify や assertion-free の試験には別のレビュー済み adapter が必要です。attempt 上限はローカル実装の資源 ceiling であり、retry の実施を許可しません。初回失敗を後の成功で消さない既存判定を維持します。

元の 114 tests を再実行して成功しました。追加 16 tests を含む計 130 tests は Linux x86_64、Python 3.12.14 で成功し、skip は 0 です。5 件の子プロセス試験は POSIX 専用なので、他 OS の skip を実機成功として数えてはいけません。これらは合成 fixture の host 検査であり、Mozilla harness、Floorp browser、メモリ安全性、署名された製品の実機結果ではありません。修正前の失敗ログも外側の証拠一式に保持しています。

Runtime PR84 の `process_exit.exitcode` も、欠落・bool・float を拒否する最小変更と 1 test/8 invalid values を別途提出します。Runtime の変更はこのキットに含めません。

## 残る条件

Agent の実 Driver 起動・action・shutdown には既存の独立 timeout が残っています。今回直した stdin の期限だけで、実ブラウザーを含む campaign 全体の hard timeout、全子プロセスの終了、OOM、log/disk 上限を保証しません。専用 worker、外部 supervisor、秘密情報のない HOME、UID/権限/通信の隔離を別途配備・実証する必要があります。Windows Agent は引き続き未対応です。

source の同一 U だけで実行証拠を再利用できるとは扱いません。U/R/P、適用 transform、native browser tree B、実 build/target/run/attempt、診断 D/F、producer/controller、first-failure history の結合と認証は未完の設計・実装残件です。元の `docs/12-evidence-contracts.md` はこの残件を修正した規範文書ではありません。

Debug qualification と製品 artifact の証拠を分離し、全 OS/native target、Linux ARM production-opt、Mac universal の両 native 実行、MAR/DEB/Portable/stub の変換後 bytes と最終署名 artifact の検証が必要です。`bundle → final QA → manual approval → 証拠再照合 → publish` と既存公開 gate を維持します。今回の修正から qualification や publish の権限は発生せず、native は UNVERIFIED のままです。

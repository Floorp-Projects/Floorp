# Floorp QA Design & Implementation Kit

**版 0.3.0 / 2026-10-09 / Desktop**

このアーカイブは **review-fixes.1** です。元 ZIP、14 文書、設計版 0.3.0 と区別し、3 件の限定コード修正と追加回帰を含みます。[修正内容・検証範囲・残件](REVIEW_FIXES.md)を先に確認してください。`validation/` の元の報告は歴史的な記録であり、今回の結果は `validation/review-fixes.json` に記録しています。

**Debug Runtimeで上流テストを実行し、製品Runtimeは既存のPGO/opt構成を維持。Floorpのソース検査は共通で１回、実ブラウザーのテストは最終Package×native targetごとに実行する。** この方針に設計書類一式を改訂しました。

設計・作業票は0.3.0が正本です。既存CLIの限定機能を維持し、製品planへのL1混入を除き、設計契約の静的検査を追加しています。Debug CI/全Floorp packaged runner/正式publisher gateまで実装済みという意味ではありません。実行済みと未実施は[検証報告](docs/07-validation-report.md)に分けています。

[総合設計書を１ファイルで読む](DESIGN.md)

## 読む順序

| 文書 | 用途 |
|---|---|
| [00 採用方針](docs/00-design-decisions.md) | 判断の正本・旧方針からの変更 |
| [01 現行構成](docs/01-current-architecture.md) | 実ソース、Runtime/Package/署名の境界 |
| [10 ビルドprofile](docs/10-build-profiles.md) | DEBUG/PGO/tests flagの真理値と変更箇所 |
| [02 ３層設計](docs/02-three-layer-design.md) | L1/L2/L3の実行・観測・判定 |
| [11 CIと公開](docs/11-ci-topology.md) | source-once、target別、循環を作らないgate |
| [12 証拠契約](docs/12-evidence-contracts.md) | Debug資格と製品artifactの別Subject接続 |
| [03 Runbook](docs/03-integration-runbook.md) | 同梱CLIの実行・既存probe接続 |
| [04 作業票](docs/04-work-orders.md) | QA3-01～11の実装/依存/受け入れ |
| [05 受け入れ](docs/05-acceptance-matrix.md) | target別状態とA01～A24の負例 |
| [06 運用](docs/06-security-operations.md) | sandbox、権限、失敗、コスト |
| [08 Agent引き継ぎ](docs/08-agent-handoff.md) | 実装Agentに渡せる指示 |
| [13 移行](docs/13-migration.md) | 旧版との差分と互換性 |
| [07 検証報告](docs/07-validation-report.md) / [09 出典](docs/09-sources.md) | 実施範囲と根拠 |

## オフライン検証

Python 3.12以上とGit。CLI実行の追加pip依存はありません。

```bash
cd Floorp_QA_Implementation_Kit_v0.3.0
python3 -m unittest discover -s tools/qa/tests -v
python3 tools/qa/design_contract.py
python3 tools/qa/qa.py --help
```

`design_contract.py` はbuild-policy/依存DAG/製品planの整合検査で、Runtime設定を変更せずブラウザーも起動しません。`qa/design/*.json`はレビュー可能な設計入力であり、実workflowを動かす設定ではありません。

## 導入

```bash
# 新規追加予定だけ表示。既存ソースやworkflowsを書き換えない。
python3 install.py --repo /path/to/Floorp
# 明示的に新規追加するときだけ使用する。
# python3 install.py --repo /path/to/Floorp --apply
```

0.2.0を導入済みのcheckoutは上書き拒否します。新旧を別worktreeで比較し、[移行手順](docs/13-migration.md)に従って必要な変更をレビューしてください。`propose_integration.py`は旧来の２probeをadvisory接続する差分生成器で、新しいDebug/PGO分離を自動実装しません。

## 実装範囲

| 実装 | 状態 |
|---|---|
| `doctor / bind-final / plan / collect-final / collect-probe / gate` |既存source pin、exact artifact、限定probe、欠落/改変/retry検査を維持 |
| `inventory-runtime / pack-test-bundle / check-mozlog` |台帳/資材結合/単一cycleログ検査。native build・全suite producerは未実装 |
| `run-probe` |既存Linux/macOS helper呼び出し。実機受け入れ未実施 |
| `check-actions / replay / agent-stdio` |制限付きpilot。外部LLM接続/全feature探索は未実装 |
| `design_contract.py` |新profile/CI依存/製品L1誤用を静的検査 |
| Runtime Debug変更 / 共通source job / 全packaged suite / publisher verifier |設計と作業票。リポジトリ未変更 |

`existing-final`はUA/Fluent-Flascoの２probeのsubset。`production-package-readiness`は全targetの将来必須L2を計画し、未実装ならBLOCK。旧名`release-readiness`も同じL2-only範囲の互換aliasですが、plan IDは別です。これらは全体release authorizationではなく、`publicationAuthorized:false`は維持します。

## 前提

Floorp: `013bb6c9ed19250592898ec8fbc8d7d24aa847be`。Runtime観測head: `c74fe1a545d275cdd710ab44701c1ee0dd6b0eae`。実際に選ぶrelease Runtimeは既存run/manifestで認証し、開発用lockや表示versionで代用しません。

旧ソース/バイナリ/認証情報/実ユーザーprofileを同梱していません。新規コードはMPL-2.0のSPDXを付しています。リポジトリへの書込、CI起動、署名、公証、公開承認、定期通知は行っていません。

add-if-not from partial file

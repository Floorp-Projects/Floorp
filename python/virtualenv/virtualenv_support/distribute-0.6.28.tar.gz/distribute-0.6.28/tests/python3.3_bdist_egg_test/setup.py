from setuptools import setup

setup(
    name='python3.3_bdist_egg_test',
    version='0.0.0',
    description='Test',
    license='BSD',
    py_modules=['module'],
    author='Marc Abramowitz',
    author_email='marc@marc-abramowitz.com',
    url='https://bitbucket.org/msabramo/python3.3_bdist_egg_test',
    # zip_safe=False,
)

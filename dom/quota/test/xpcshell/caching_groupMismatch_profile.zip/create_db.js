/*
  Any copyright is dedicated to the Public Domain.
  http://creativecommons.org/publicdomain/zero/1.0/
*/

async function testSteps()
{
  const principal = getPrincipal("https://foo.bar.mozilla-iot.org");
  const name = "data";
  const bufferSize = 100;

  let database = getSimpleDatabase(principal);

  let request = database.open(name);
  await requestFinished(request);

  let buffer = getBuffer(bufferSize);

  request = database.write(buffer);
  await requestFinished(request);

  request = database.close();
  await requestFinished(request);
}

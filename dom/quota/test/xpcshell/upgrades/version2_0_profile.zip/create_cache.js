/**
 * Any copyright is dedicated to the Public Domain.
 * http://creativecommons.org/publicdomain/zero/1.0/
 */

var testGenerator = testSteps();

function* testSteps()
{
  const cachesName = "create_cache";

  info("Clearing");

  clear(continueToNextStepSync);
  yield undefined;

  caches.open(cachesName).then(continueToNextStepSync);
  yield undefined;

  finishTest();
}

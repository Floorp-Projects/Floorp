var casper = require('casper').create({
});

casper.start('../index.html', function() {
})

casper.then(function() {
    var t = this.test;
    t.assertTitle('Stopwatch');
});

casper.run(function() {
    this.exit();
});

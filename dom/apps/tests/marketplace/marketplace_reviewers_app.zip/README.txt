A simple packaged app for Firefox OS.

Icon from: http://commons.wikimedia.org/wiki/File:HILLGIALLO_orologio.png under
the Creative Commons Attribution 3.0 Unported license.

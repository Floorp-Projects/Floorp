elements
========

elements is a minimal DOM Library for [prime](https://github.com/mootools/prime).

Read the [documentation](https://github.com/mootools/elements/blob/master/doc/elements.md).

[![Build Status](https://secure.travis-ci.org/mootools/elements.png?branch=master)](http://travis-ci.org/mootools/elements)

navigator.getCurrentPosition();

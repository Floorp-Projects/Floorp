document.addEventListener("DOMContentLoaded", function() {
  var head = document.getElementById("header2");
  head.innerHTML = "Customized content";
}, false);
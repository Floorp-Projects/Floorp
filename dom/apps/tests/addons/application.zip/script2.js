// Simple script that changes an element's content.

var head = document.getElementById("header2");
head.innerHTML = "Customized content";



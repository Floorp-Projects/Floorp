// Simple script that changes an element's content.

var head = document.getElementById("header");
head.innerHTML = "Hello World!";


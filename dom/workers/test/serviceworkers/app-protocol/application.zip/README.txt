application.zip contains foo.txt, index.html, sw.js and manifest.webapp.
Any change to one of these three files should be added to application.zip as well.

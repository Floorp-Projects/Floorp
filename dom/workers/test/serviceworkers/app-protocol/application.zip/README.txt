application.zip contains:

- controlled.html
- foo.txt
- index.html
- manifest.webapp
- sw.js
- test.js
- test_doc_load_interception.js

Any change to one of these three files should be added to application.zip as well.

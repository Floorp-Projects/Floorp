alert('KO: Should not load this file, but the sw modified version instead');

/**
 * Any copyright is dedicated to the Public Domain.
 * http://creativecommons.org/publicdomain/zero/1.0/
 */

async function run_test()
{
  const cachesName = "create_cache";

  do_test_pending();
  do_get_profile();

  await caches.open(cachesName);

  do_test_finished();
}

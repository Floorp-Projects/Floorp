/*
  Any copyright is dedicated to the Public Domain.
  http://creativecommons.org/publicdomain/zero/1.0/
*/

async function testSteps()
{
  const url = "http://example.com";

  const data = {
    key: "foo",
    value: "bar"
  };

  function getLocalStorage(principal) {
    return Services.domStorageManager.createStorage(null, principal, "");
  }

  info("Getting storage");

  let storage = getLocalStorage(getPrincipal(url));

  info("Adding data");

  storage.setItem(data.key, data.value);
}

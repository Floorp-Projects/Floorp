"""poster module

Support for streaming HTTP uploads, and multipart/form-data encoding"""
import poster.streaminghttp
import poster.encode
